<aside class="sidebar-wrapper" data-simplebar="true">
	<div class="sidebar-header">
		<div class="main-logo">
			<img src="{{ url('storage/' . config('setting.logo')) }}"  class="logo-icon" alt="logo icon">
		</div>
		<div class="toggle-icon ms-auto"> <i class="bi bi-list"></i>
		</div>
	</div>
	<!--navigation-->
	<ul class="metismenu" id="menu">
		<li>
			<a href="{{ url('home') }}">
				<div class="parent-icon">
					<img class="in-svg" src="{{ url('front/images/custom-image/sidebar-icon1.svg') }}" alt="">
				</div>
				<div class="menu-title">Dashboard</div>
			</a>
		</li>
		<li>
			<a href="{{ url('investment-list') }}">
				<div class="parent-icon">
					<img class="in-svg" src="{{ url('front/images/custom-image/sidebar-icon2.svg') }}" alt="">
				</div>
				<div class="menu-title">Investment</div>
			</a>
		</li>
		<li>
			<a href="{{ url('wallet-list') }}">
				<div class="parent-icon">
					<img class="in-svg" src="{{ url('front/images/custom-image/sidebar-icon3.svg') }}" alt="">
				</div>
				<div class="menu-title">Wallets</div>
			</a>
		</li>
		<li class="{{( request()->is('education/trading') || request()->is('education/rehab') || request()->is('education/business')) ? 'mm-active':'' }}">
			<a href="{{ url('educations') }}">
				<div class="parent-icon educations-menu">
					<img class="in-svg" src="{{ url('front/images/custom-image/sidebar-icon4.svg') }}" alt="">
				</div>
				<div class="menu-title">Educations</div>
			</a>
		</li>
		<li>
			<a href="{{ url('ai-bots') }}">
				<div class="parent-icon educations-menu">
					<img class="in-svg" src="{{ url('front/images/custom-image/sidebar-icon5.svg') }}" alt="">
				</div>
				<div class="menu-title">Ai & Bots</div>
			</a>
		</li>
		<li>
			<a href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
				<div class="parent-icon educations-menu">
					<img class="in-svg" src="{{ url('front/images/custom-image/logout.svg') }}" alt="">
				</div>
				<div class="menu-title">Logout</div>
			</a>
		</li>
	</ul>
	<form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
		@csrf
	</form>
	<!--end navigation-->
</aside>