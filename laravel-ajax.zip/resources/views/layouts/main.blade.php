<!doctype html>
<html lang="en" class="semi-dark">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<title>@yield('title','Clarus Ventures')</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="{{ url('storage/' . config('setting.fevicon_icon')) }}">
		
		@stack('before-css')
		<link href="{{ url('front/plugins/vectormap/jquery-jvectormap-2.0.2.css') }}" rel="stylesheet" />
		<link href="{{ url('front/plugins/simplebar/css/simplebar.css') }}" rel="stylesheet" />
		<link href="{{ url('front/plugins/perfect-scrollbar/css/perfect-scrollbar.css') }}" rel="stylesheet" />
		<link href="{{ url('front/plugins/metismenu/css/metisMenu.min.css') }}" rel="stylesheet" />
		
		<link href="{{ url('admin/libs/select2/select2.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{url('admin/libs/sweetalert2/sweetalert2.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{url('admin/libs/jquery-toast/jquery.toast.min.css') }}" rel="stylesheet" type="text/css" />
		
		<link href="{{ url('front/plugins/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
		 
		<!-- Bootstrap CSS -->
		<link href="{{ url('front/css/bootstrap.min.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/bootstrap-extended.css') }}" rel="stylesheet" />
		
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
		<link href="{{ url('front/plugins/smart-wizard/css/smart_wizard_all.min.css') }}" rel="stylesheet" type="text/css" />
		
		<!--Theme Styles-->
		<link href="{{ url('front/css/dark-theme.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/light-theme.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/semi-dark.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/header-colors.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/style.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/icons.css') }}" rel="stylesheet">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
				
		@stack('after-css')
		<!-- loader-->
		<!-- <link href="assets/css/pace.min.css" rel="stylesheet" /> -->
	</head>
	<body>
		<!--start wrapper-->
		<div class="wrapper">
			<img class="fix-bg" src="{{ url('front/images/custom-image/bg-top-left.png') }}" alt="">
			<img class="fix-bg-right" src="{{ url('front/images/custom-image/bg-top-right.png') }}" alt="">
			<!--start top header-->
			@include('layouts.partials.topbar')
			
			<!--end top header-->
			<!--start sidebar -->
			@include('layouts.partials.left-sidebar')
			
			<!--end sidebar -->
			<div class="mob-footer">
				<ul class="navbar-nav align-items-center">
					<li class="nav-item mob-none">
						<a class="nav-link" href="#">
							<div class="header-menu" style="background: #0B2C32;">
								<img src="{{ url('front/images/custom-image/header-icon1.svg') }}" alt="">
							</div>
						</a>
					</li>
					<li class="nav-item mob-none">
						<a class="nav-link" href="#">
							<div class="header-menu" style="background: #273710;">
								<img src="{{ url('front/images/custom-image/header-icon2.svg') }}" alt="">
							</div>
						</a>
					</li>
					<li class="nav-item mob-none">
						<a class="nav-link" href="#">
							<div class="header-menu" style="background: #402902;">
								<img src="{{ url('front/images/custom-image/header-icon3.svg') }}" alt="">
							</div>
						</a>
					</li>
					<li class="nav-item mob-none">
						<a class="nav-link" href="#">
							<div class="header-menu" style="background: #311F2B;">
								<img src="{{ url('front/images/custom-image/header-icon4.svg') }}" alt="">
							</div>
						</a>
					</li>
				</ul>
			</div>
			<!--start content-->
			@yield('content')
			<!--end page main-->
			<!--start overlay-->
			<?php
				$check_premium_d = App\Models\UserWallet::where('user_id', Auth::id())
					->where('transaction_type', 'Premium Subscription')
					->orderBy('id','DESC')
					->where('is_status',2)
					->first();
			?>
			<div class="overlay nav-toggle-icon"></div>
			<!--end overlay-->
			<!--Start Back To Top Button-->
			<a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
			<div class="modal fade" id="purchase-modal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
				<div class="modal-dialog modal-xl modal-dialog-centered">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title">Purchase now 99</h5>
							<a href="{{route('logout')}}" class="btn-close" onclick="event.preventDefault();
							document.getElementById('logout-form').submit();">Logout</a>
						</div>
						<div class="modal-body">
							<div class="purchase-modal-deta">
								<div class="purchase-modal-head">
									<img src="{{ url('front/images/purchase-img.png') }}" alt="">
									<h3>Go Premium <span>₹99</span> </h3>
									<p>& get full support on your</p>
								</div>
								<div class="purchase-modal-footer">
									<h6>Improve You Investment  Portfolio </h6>
									@if($check_premium_d)
										<p class="text-danger">Your Premium request has been rejected by admin.. Please contact admin or make repayment</p>
									@else
										<p>Stay on top of your life time activity receive personalized daily portfolio suggestions for optimal with gentler</p>
									@endif
									<a href="{{ url('premium-subscription') }}" class="comm-btn action-btn spin-btn" style="margin: 0 auto;">₹ 99 /- Purchase now</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="modal fade" id="purchase-modal-history" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
				<div class="modal-dialog modal-xl modal-dialog-centered">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title">Your premium subscription request has been sent successfully.</h5>
							<a href="{{route('logout')}}" class="btn-close" onclick="event.preventDefault();
							document.getElementById('logout-form').submit();">Logout</a>
						</div>
						<div class="modal-body">
							<div class="purchase-modal-deta">
								<div class="purchase-modal-head">
									<img src="{{ url('front/images/purchase-img.png') }}" alt="">
									<h3>Go Premium <span>₹99</span> </h3>
									<p>& get full support on your</p>
								</div>
								<div class="purchase-modal-footer">
									<h6>Improve You Investment  Portfolio </h6>
									<p>Your premium subscription request has been sent successfully. Please wait for the admin to approve your request, after which you will be able to use all the functionalities.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--End Back To Top Button-->
		</div>
		
		<!-- Bootstrap bundle JS -->
		<script src="{{ url('front/js/bootstrap.bundle.min.js') }}"></script>
		<!--plugins-->
		<script src="{{ url('front/js/jquery.min.js') }}"></script>
		
		<script src="{{ url('admin/libs/select2/select2.min.js') }}"></script>
		<script src="{{url('admin/libs/sweetalert2/sweetalert2.min.js') }}"></script>
		<script src="{{url('admin/libs/jquery-toast/jquery.toast.min.js') }}"></script>
		
		
		<script src="{{ url('front/plugins/simplebar/js/simplebar.min.js') }}"></script>
		<script src="{{ url('front/plugins/metismenu/js/metisMenu.min.js') }}"></script>
		<script src="{{ url('front/plugins/perfect-scrollbar/js/perfect-scrollbar.js') }}"></script>
		<script src="{{ url('front/js/pace.min.js') }}"></script>
		<script src="{{ url('front/plugins/chartjs/js/Chart.min.js') }}"></script>
		<script src="{{ url('front/plugins/chartjs/js/Chart.extension.js') }}"></script>
		<script src="{{ url('front/plugins/apexcharts-bundle/js/apexcharts.min.js') }}"></script>
		<!-- Vector map JavaScript -->
		<script src="{{ url('front/plugins/vectormap/jquery-jvectormap-2.0.2.min.js') }}"></script>
		<script src="{{ url('front/plugins/vectormap/jquery-jvectormap-world-mill-en.js') }}"></script>
		
		<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
		
		<script src="{{ url('front/plugins/smart-wizard/js/jquery.smartWizard.min.js') }}"></script>
		
		<script src="{{ url('front/plugins/datatable/js/jquery.dataTables.min.js') }}"></script>
		<script src="{{ url('front/plugins/datatable/js/dataTables.bootstrap5.min.js') }}"></script>
		<script src="{{ url('front/js/table-datatable.js') }}"></script>
		
		<!--app-->
		<script src="{{ url('front/js/app.js') }}"></script>
		<script src="{{ url('front/js/index.js') }}"></script>
		@if(Auth::check() && Auth::user()->is_premium_member == 0)
			@if(url()->current() != url('premium-subscription'))
				<?php
					$check_premium = App\Models\UserWallet::where('user_id', Auth::id())
						->where('transaction_type', 'Premium Subscription')
						->where('is_status','!=',2)
						->first();
				?>

				@if($check_premium)
					<script>
						document.addEventListener('DOMContentLoaded', function() {
							$("#purchase-modal-history").modal('show');
							$("#purchase-modal").modal('hide');
						});
					</script>
				@else
					<script>
						document.addEventListener('DOMContentLoaded', function() {
							$("#purchase-modal").modal('show');
							$("#purchase-modal-history").modal('hide');
						});
					</script>
				@endif
			@endif
		@endif
		<script>
			$('.select2').select2({
				placeholder: 'Select an option',
				allowClear: true
			});
			
			 let modalOpen = false;
            function closemodal()
            {
                setTimeout(function()
                {
                    modalOpen = false;
				},1000)
			}
			
			function getStateData()
			{
				var country_id = $('#country_id').val();
				var _token = $('input[name="_token"]').val();
				
				$.ajax({
					url:"{{ url('get-state-data') }}",
					method:"POST",
					data:{country_id:country_id, _token:_token},
					success:function(result)
					{
						$('#state_id').html(result);
					}
				})
			}
			
			function getCityData()
			{
				var state_id = $('#state_id').val();
				var _token = $('input[name="_token"]').val();
				
				$.ajax({
					url:"{{ url('get-city-data') }}",
					method:"POST",
					data:{state_id:state_id, _token:_token},
					success:function(result)
					{
						$('#city_id').html(result);
					}
				})
			}
			
			function toastrMsg(type,msg)
			{
				$.toast({
					text: msg, 
					position: "top-right",
					loaderBg: "#da8609",
					icon: type,
					hideAfter: 3e3,
					stack: 1
				})
			}
			
			new PerfectScrollbar(".review-list")
			new PerfectScrollbar(".chat-talk")
		</script>
		@stack('js')
		
		<div id="modal-view-render"> </div> 
	</body>
</html>