@extends('layouts.main')

@section('content')
<main class="page-content">
	<div class="dashbord-main">
		<div class="karma-pick-main">
			<div class="karma-pick-deta">
				<div class="karma-pick-box">
					<a href="{{ url('view-basket')}}">
						<img src="{{ url('front/images/custom-image/dash-ico1.gif')}}" alt="">
						<h4>Baskets</h4>
					</a>
				</div>
				<div class="karma-pick-box">
					<img src="{{ url('front/images/custom-image/dash-ico2.gif')}}" alt="">
					<h4>Screeners</h4>
				</div>
				<div class="karma-pick-box">
					<a href="{{ url('ai-bots')}}">
						<img src="{{ url('front/images/custom-image/dash-ico3.gif')}}" alt="">
						<h4>Trades</h4>
					</a>
				</div>
				<div class="karma-pick-box">
					<img src="{{ url('front/images/custom-image/dash-ico4.gif')}}" alt="">
					<h4>IPO</h4>
				</div>
				<div class="karma-pick-box">
					<a href="{{ url('educations')}}">
						<img src="{{ url('front/images/custom-image/dash-ico5.gif')}}" alt="">
						<h4>Academy</h4>
					</a>
				</div>
				<div class="karma-pick-box">
					<a href="{{ url('view-health')}}">
						<img src="{{ url('front/images/custom-image/dash-ico6.gif')}}" alt="">
						<h4>Health</h4>
					</a>
				</div>
				<!--<div class="karma-pick-box">-->
				<!--    <img src="{{ url('front/images/custom-image/dash-ico7.gif')}}" alt="">-->
				<!--    <h4>Watchlist</h4>-->
				<!--</div>-->
				<!--<div class="karma-pick-box">-->
				<!--    <img src="{{ url('front/images/custom-image/dash-ico8.gif')}}" alt="">-->
				<!--    <h4>Result</h4>-->
				<!--</div>-->
				<!--<div class="karma-pick-box">-->
				<!--    <img src="{{ url('front/images/custom-image/dash-ico9.gif')}}" alt="">-->
				<!--    <h4>News</h4>-->
				<!--</div>-->
				<!--<div class="karma-pick-box">-->
				<!--    <img src="{{ url('front/images/custom-image/dash-ico10.gi')}}f" alt="">-->
				<!--    <h4>Ask Clarus</h4>-->
				<!--</div>-->


				<!--@foreach($get_categorys as $get_category)-->
				<!--            <div class="karma-pick-box" onclick="viewContentData('{{ addslashes($get_category->title) }}', '{{ addslashes($get_category->description) }}');">-->
				<!--	<img src="{{ url('public/storage/'.$get_category->image) }}" alt="">-->
				<!--	<h4>{{ $get_category->title }}</h4>-->
				<!--</div>-->
				<!--@endforeach-->
			</div>
		</div>
		<div class="dash-video-sec">
			<div class="row">
				@if(count($get_videos) > 0)
				<div class="col-xl-5">
					<div class="video-card-main">
						<h4>{{ $get_videos[0]->title }}.....</h4>
						<div class="video-slider">
							<div class="swiper videoslider">
								<div class="swiper-wrapper">
									@foreach($get_videos as $get_video)
									<div class="swiper-slide">
										<div class="dash-video">
											<video controls autoplay loop>
												<source src="{{ url('public/storage/'.$get_video->video) }}" type="video/mp4">
												<source src="{{ url('public/storage/'.$get_video->video) }}" type="video/ogg">
											</video>
										</div>
									</div>
									@endforeach
								</div>
								<div class="swiper-button-next"></div>
								<div class="swiper-button-prev"></div>
							</div>
						</div>
						<div class="video-card-footer">
							<a href="#">
								<h5>Track Mutual Funds</h5>
								<img src="{{ url('front/images/custom-image/arrow.svg') }}" alt="">
							</a>
						</div>
					</div>
				</div>
				@endif
				<div class="col-xl-7">
					<div class="video-card-main past-trade">
						<div class="past-trade-head">
							<h4>{{ config('setting.past_top_trade_title')}} <span>{{ config('setting.past_top_trade_title_percentag')}}%</span></h4>
						</div>
						<div class="past-trade-deta">
							<h3>Past Trade Performance</h3>
							<div class="past-card-main">
								<div class="swiper mySwiper">
									<div class="swiper-wrapper">
										@foreach($get_past_trades as $get_past_trade)
										<div class="swiper-slide">
											<div class="past-card">
												<img src="{{ url('public/storage/'.$get_past_trade->icon) }}" alt="">
												<h5> {{ $get_past_trade->title }} </h5>
												<h6><span><img src="{{ url('front/images/custom-image/ai-head1.png') }}" alt=""></span>{{ $get_past_trade->trade_percentage }} %</h6>
												<p>{{ $get_past_trade->sub_title }}</p>
											</div>
										</div>
										@endforeach
									</div>
									<div class="swiper-button-next"></div>
									<div class="swiper-button-prev"></div>
								</div>
								<hr>
								<div class="past-trade-footer">
									<a href="javascript:void(0)" class="dash-btn" data-bs-toggle="modal" data-bs-target="#exampleVerticallycenteredModal">Get Clarus One</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="live-trade-main">
			<div class="row">
				<div class="col-xl-5">
					<div class="live-trade-card" style="height: auto;">
						<h5>Investment Suggestions</h5>
						<div class="live-trade-slider">
							<div class="swiper live-trade">
								<div class="swiper-wrapper">
									@foreach($get_live_trades as $get_live_trade)
									<div class="swiper-slide">
										<a href="{{ url('view-basket')}}">
											<div class="live-slider-card">
												<img src="{{ url('public/storage/'.$get_live_trade->icon) }}" alt="">
												<div class="live-blur-text">
													<h4> {{ $get_live_trade->title }} </h4>
												</div>
												<div class="live-blur-footer">
													<h5>{{ $get_live_trade->live_percentage }}%</h5>
													<h6>{{ $get_live_trade->sub_title }}</h6>
												</div>
											</div>
										</a>
									</div>
									@endforeach
								</div>
								<div class="swiper-button-next"></div>
								<div class="swiper-button-prev"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-7">
					<div class="row">
						<div class="col-md-6">
							<div class="dash-stoke-card">
								<div class="live-trade-card">
									<h5> Portfolio In Buzz </h5>
									<div class="live-trade-slider stoke-buzz-slider">
										<div class="swiper stoke">
											<div class="swiper-wrapper">
												@foreach($get_stock_buzzs as $get_stock_buzz)
												<div class="swiper-slide">
													<div class="dash-stoke-img">
														<a href="{{ url('view-portfolio-buzz')}}">
															<img src="{{ url('public/storage/'.$get_stock_buzz->image) }}" alt="">
														</a>
													</div>
												</div>
												@endforeach
											</div>
											<div class="swiper-button-next"></div>
											<div class="swiper-button-prev"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="live-trade-card title-box">
								<img src="{{ url('storage/' . config('setting.explore_the_exclusive_banner')) }}" alt="">
							</div>
						</div>
					</div>
					<div class="news-main">
						<div class="live-trade-card">
							<h5>News That Moves</h5>
							<div class="live-trade-slider">
								<div class="swiper news-move">
									<div class="swiper-wrapper">
										@foreach($get_newss as $get_news)
										<div class="swiper-slide">
											<a href="{{ $get_news->news_url }}" target="_blenk">
												<div class="news-slide-card">
													<img src="{{ url('public/storage/'.$get_news->image) }}" alt="">
													<p>{{ substr($get_news->title, 0, 80) }}..</p>
													<h6>{{ substr($get_news->trade_title, 0, 12) }}..<span><i class="fadeIn animated bx bx-caret-up"></i> {{ $get_news->trade_percentage }}%</span></h6>
												</div>
											</a>
										</div>
										@endforeach
									</div>
									<div class="swiper-button-next"></div>
									<div class="swiper-button-prev"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>

<div class="modal fade" id="topCategoryContentViewModal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="top_category_title"></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<div id="top_category_content"></div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="exampleVerticallycenteredModal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Past Trade Information</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<?php echo config('setting.past_top_trade_information'); ?>
			</div>
		</div>
	</div>
</div>

@endsection
@push('js')
<script>
	function viewContentData(title_top, category_content) {
		$("#top_category_title").text(title_top);
		$("#top_category_content").html(category_content);
		$("#topCategoryContentViewModal").modal('show');
	}

	function viewContentDataPast(title, content) {
		$("#top_category_title").text(title);
		$("#top_category_content").html(content);
		$("#topCategoryContentViewModal").modal('show');
	}
</script>
@endpush