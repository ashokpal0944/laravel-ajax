@extends('layouts.main')

@section('content')
<main class="page-content">
    <div class="wallet-page-main">
        <div class="wallet-page-deta">
           <!-- <div class="stoke-idea-head">
                <a href="javascript:void(0);" class="wallet-btn">Find your credit limit</a>
            </div>-->
            <div class="wallet-page-deta">
                <div class="row">
                    <div class="col-xl-3 col-md-4 col-sm-6">
                        <a href="{{ url('top-plan') }}">
                            <div class="wallet-page-card">
                                <img src="{{ url('front/images/custom-image/wallet-ico1.svg') }}" alt="">
                                <h5>Grab your plan</h5>
                            </div>
                        </a>
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-6">
                        <a href="{{ url('deposit') }}">
                            <div class="wallet-page-card">
                                <img src="{{ url('front/images/custom-image/wallet-ico2.svg') }}" alt="">
                                <h5>Deposit</h5>
                            </div>
                        </a>
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-6">
                        <a href="{{ url('withdrawal') }}">
                            <div class="wallet-page-card">
                                <img src="{{ url('front/images/custom-image/wallet-ico3.svg') }}" alt="">
                                <h5>Withdrawal</h5>
                            </div>
                        </a>
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-6">
                        <a href="{{ url('deposit-history') }}">
                            <div class="wallet-page-card">
                                <img src="{{ url('front/images/custom-image/wallet-ico4.svg') }}" alt="">
                                <h5>Deposit History</h5>
                            </div>
                        </a>
                    </div>
					<div class="col-xl-3 col-md-4 col-sm-6">
                        <a href="{{ url('withdrawal-history') }}">
                            <div class="wallet-page-card">
                                <img src="{{ url('front/images/custom-image/wallet-ico4.svg') }}" alt="">
                                <h5>Withdrawal History</h5>
                            </div>
                        </a>
                    </div>
                    <div class="col-xl-3 col-md-4 col-sm-6">
                        <a href="{{ url('purchase-history') }}">
                            <div class="wallet-page-card">
                                <img src="{{ url('front/images/custom-image/wallet-ico4.svg') }}" alt="">
                                <h5>Purchase History</h5>
                            </div>
                        </a>
                    </div>
					<div class="col-xl-3 col-md-4 col-sm-6">
                        <a href="{{ url('investment-history') }}">
                            <div class="wallet-page-card">
                                <img src="{{ url('front/images/custom-image/wallet-ico4.svg') }}" alt="">
                                <h5>Investment History</h5>
                            </div>
                        </a>
                    </div>
					<div class="col-xl-3 col-md-4 col-sm-6">
                        <a href="{{ url('ai-bot-purchase-history') }}">
                            <div class="wallet-page-card">
                                <img src="{{ url('front/images/custom-image/wallet-ico4.svg') }}" alt="">
                                <h5>Ai Bot Purchase History</h5>
                            </div>
                        </a>
                    </div>
					<div class="col-xl-3 col-md-4 col-sm-6">
                        <a href="javascript:void(0);">
                            <div class="wallet-page-card" data-bs-toggle="modal" data-bs-target="#exampleVerticallycenteredModal">
                                <img src="{{ url('front/images/custom-image/wallet-ico4.svg') }}" alt="">
                                <h5>Fees & Taxes</h5>
                            </div>
                        </a>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="exampleVerticallycenteredModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Fees & Taxes</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="add-deposite-main">
                    <div class="row withdrawal-fees">
                        <ul>
							<li><span>{{ config('setting.crypto_tax_percentage')}}%</span> Crypto tax</li>
							<li><span>{{ config('setting.cess_tax_percentage')}}%</span> CESS</li>
							<li><span>{{ config('setting.tds_tax_percentage')}}%</span> TDS</li>
							<li><span>{{ config('setting.wc_tax_percentage')}}%</span> WC</li>
							<li><span>{{ config('setting.maintenance_tax_percentage')}}%</span> Maintenance</li>
						</ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end page main-->
@endsection
