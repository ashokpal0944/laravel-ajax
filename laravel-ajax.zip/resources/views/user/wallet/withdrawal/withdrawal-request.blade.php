@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="top-plan-page wallet-payment">
        <div class="inner-page-head">
            <h3><span><img src="{{url('front/images/custom-image/payment-ico.png') }}" alt=""></span> Withdrawal {{ $wallet_details['title'] }} Wallet Balance </h3>
		</div>
        <div class="wallet-payment-main">
            <div class="row">
                <div class="col-xxl-6 col-lg-8">
                    <div class="wallet-payment-deta">
						@if($wallet_details['title'] == "Bank Account")
						<div class="bank-detials">
                            <p>Bank Account Type: <b>{{ $wallet_details['account_type'] }}</b></p>
                            <p>Bank Name: <b>{{ $wallet_details['bank_name'] }}</b></p>
                            <p>Account Number: <b>{{ $wallet_details['account_number'] }}</b></p>
                            <p>IFSC Code: <b>{{ $wallet_details['ifsc_code'] }}</b></p>
						</div>	
						@endif
                        <div class="wallet-payment-form">
                            <form id="sendWithdrawalRequest" action="{{ url('send-withdrawal-request')}}" method="post">
								@csrf
                                <div class="row">
									@if($wallet_details['title'] != "Bank Account")
                                    <div class="col-lg-12">
                                        <label class="label-main" for="">Withdrawal address</label>
										<div class="copy-field">
											<input class="input-main" type="text" id="wallet_address" value="{{ $wallet_details['address'] }}" readonly>
											<a href="javascript:void(0)" class="copy-img" onclick="copyToClipboard()"><img src="{{url('front/images/custom-image/copy.svg') }}" alt=""></a>
										</div>
									</div>
									@endif
									<input class="input-main" type="hidden" name="transaction_method" id="transaction_method" value="{{ $wallet_details['title'] }}">
									<input class="input-main" type="hidden" name="transaction_wallet_address" id="transaction_wallet_address" value="{{ $wallet_address }}">
                                    <div class="col-lg-12">
                                        <label class="label-main" for="">Withdrawal Amount</label>
                                        <input class="input-main" type="text" name="amount" id="amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
									</div>
                                    <div class="col-lg-12">
                                        <label class="label-main" for="">Withdrawal Transaction Id</label>
                                        <input class="input-main" type="text" name="transaction_id" id="transaction_id">
									</div>
									<div class="col-lg-12">
                                        <label class="label-main" for="">Transaction Image</label>
                                        <input class="input-main" type="file" name="transaction_image" id="transaction_image">
									</div>
                                    <div class="col-lg-12">
                                        <div class="form-term d-flex align-items-center">
                                            <input class="form-check-input" type="checkbox" name="" id="" required>
                                            <label class="label-main m-0" for="">Agree Terms & Conditions</label>
										</div>
									</div>
                                    <div class="col-lg-12">
                                        <button type="submit" class="comm-btn action-btn spin-btn">Withdrawal</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>
@endsection
@push('js')
<script>
	$('#sendWithdrawalRequest').submit(function(event) {
		event.preventDefault();
		
		var $form = $(this);
		var $submitButton = $form.find('button');
		var $spinButton = $form.find('button.spin-button');
		
		$submitButton.prop('disabled', true);
		$spinButton.addClass('loading');
		
		var formData = new FormData(this);
		formData.append('_token', "{{ csrf_token() }}");
		
		$.ajax({
			async: true,
			type: $form.attr('method'),
			url: $form.attr('action'),
			data: formData,
			cache: false,
			processData: false,
			contentType: false,
			dataType: 'Json',
			success: function(res) {
				
				if (res.status === "error") 
				{
					toastrMsg(res.status, res.msg);
					$submitButton.prop('disabled', false);
					$spinButton.removeClass('loading');
				}
				else if (res.status === "validation")
				{
					$submitButton.prop('disabled', false);
					$spinButton.removeClass('loading');
					
					$('.error').remove(); // Clear previous error messages
					
					$.each(res.errors, function(key, value) {
						var inputField = $('#' + key);
						var errorSpan = $('<span>')
						.addClass('error text-danger')
						.attr('id', key + 'Error')
						.text(value[0]);
						inputField.parent().append(errorSpan);
						});
				} 
				else 
				{
					toastrMsg(res.status, res.msg);
					$('body').css({'overflow': 'auto'});
					$('.error').remove();
					
					setTimeout(function() {
						location.href = "{{ url('withdrawal-history') }}"; 
					}, 2000);
				}
			}
		});
	});
	
	function copyToClipboard() {
		// Get the referral code text
		var codeText = document.getElementById("wallet_address").value;
		
		// Create a temporary input element to hold the text
		var tempInput = document.createElement("input");
		document.body.appendChild(tempInput);
		tempInput.value = codeText;
		tempInput.select();
		tempInput.setSelectionRange(0, 99999); // For mobile devices
		
		// Copy the text to clipboard
		document.execCommand("copy");
		
		// Remove the temporary input element
		document.body.removeChild(tempInput);
		
		// Optionally, display a message to the user
		alert("Address copied to clipboard: " + codeText);
	}
</script>
@endpush
