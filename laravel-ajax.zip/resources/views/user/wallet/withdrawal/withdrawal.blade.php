@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="top-plan-page wallet-payment">
        <div class="wallet-payment-main">
            <div class="row">
                <div class="col-xxl-6 col-lg-8">
                    <div class="wallet-payment-deta">
                        <div class="wallet-payment-form">
                            <form id="sendWithdrawalRequest" method="post" action="{{ url('send-withdrawal-request') }}">
								@csrf
								
								<input class="input-main" type="hidden" id="wallet_type" name="wallet_type" value="">
								
                                <div class="row">
									<div class="col-lg-12">
										<div class="deposite-deta">
											<div class="deposite-radio">
												<div class="form-check custom-radio">
												</div>
											</div>
											<div class="deposite-field">
												<h6>Amount</h6>
												<input class="input-main" type="text" id="amount" name="amount">
											</div>
										</div>
									</div>
									@foreach($user_wallet_address as $key => $user_wallet_addres)
									<div class="col-lg-12">
										<div class="deposite-deta">
											<div class="deposite-radio">
												<div class="form-check custom-radio">
													<input class="form-check-input {{ $user_wallet_addres['wallet_kye'] }}" type="radio" name="wallet_address" id="wallet_{{ $user_wallet_addres['wallet_address'] }}" value="{{ $user_wallet_addres['wallet_address'] }}"  data-wallet-type="{{ $key }}" onclick="setWalletType(this)">
													<label class="form-check-label" for="wallet_{{ $user_wallet_addres['wallet_address'] }}"></label>
												</div>
											</div>
											<div class="deposite-field">
												<h6>{{ $key }}</h6>
												<input class="input-main" type="text" id="{{ $user_wallet_addres['wallet_kye'] }}" onkeyup="updateWalletAddress(this);" value="{{ $user_wallet_addres['wallet_address'] }}" >
											</div>
										</div>
									</div>
									@endforeach
									
									@if($check_user_kyc->account_number)
                                    <div class="col-lg-12">
                                        <label class="label-main" for="">INR method</label>
									</div>
									<div class="col-lg-12">
										<div class="deposite-deta">
											<div class="deposite-radio">
												<div class="form-check custom-radio">
													<input class="form-check-input" type="radio" name="wallet_address" id="wallet_bank" value="{{ $check_user_kyc->account_number }}"data-wallet-type="Bank Account" onclick="setWalletType(this)">
													<label class="form-check-label" for="wallet_bank"></label>
												</div>
											</div>
											<div class="deposite-field">
												<div class="select-btn" data-bs-toggle="modal" data-bs-target="#bank-details">
													<label for="wallet_bank">Bank Details</label>
												</div>
											</div>
										</div>
									</div>
									@endif
									<div class="col-lg-12">
										<div class="deposite-deta">
											<div class="deposite-radio">
												<div class="form-check custom-radio">
													<input class="form-check-input upi_address" type="radio" name="wallet_address" id="wallet_upi_address" value="{{ $check_user_kyc->upi_address }}"  data-wallet-type="UPI Address" onclick="setWalletType(this)">
													<label class="form-check-label" for="wallet_upi_address"></label>
												</div>
											</div>
											<div class="deposite-field">
												<h6>UPI Address</h6>
												<input class="input-main" type="text" id="upi_address" onkeyup="updateWalletAddress(this);" value="{{ $check_user_kyc->upi_address }}" >
											</div>
										</div>
									</div>
                                    <div class="col-lg-12">
                                        <button type="submit" class="comm-btn" style="margin: 0 auto;">Submit</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>
<!--end page main-->

<!-- bank details modal -->
<div class="modal fade" id="bank-details" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Bank details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
            <div class="modal-body">
                <div class="add-deposite-main">
                    <form id="updateBankAccounDetail" method="post" action="{{ url('update-bank-account-details') }}">
                        @csrf
                        <div class="row">
                            <div class="col-lg-12">
                                <label class="label-main" for="bank_name">Bank name</label>
                                <input class="input-main" type="text" value="{{ $check_user_kyc->bank_name }}" name="bank_name" id="bank_name">
							</div>
                            <div class="col-lg-12">
                                <label class="label-main" for="account_number">Account No.</label>
                                <input class="input-main" type="text" value="{{ $check_user_kyc->account_number }}" name="account_number" id="account_number">
							</div>
                            <div class="col-lg-12">
                                <label class="label-main" for="confirmation_account_number">Confirm Account No.</label>
                                <input class="input-main" type="text" name="confirmation_account_number" id="confirmation_account_number">
							</div>
                            <div class="col-lg-12">
                                <label class="label-main" for="ifsc_code">IFSC Code</label>
                                <input class="input-main" type="text" value="{{ $check_user_kyc->ifsc_code }}" name="ifsc_code" id="ifsc_code">
							</div>
                            <div class="col-lg-12">
                                <label class="label-main" for="account_type">Account Type</label>
                                <select class="input-main" name="account_type" id="account_type">
                                    <option value="Current account" {{ $check_user_kyc && $check_user_kyc->account_type == "Current account" ? 'selected' : '' }}>Current account</option>
                                    <option value="Savings account" {{ $check_user_kyc && $check_user_kyc->account_type == "Savings account" ? 'selected' : '' }}>Savings account</option>
                                    <option value="Salary account" {{ $check_user_kyc && $check_user_kyc->account_type == "Salary account" ? 'selected' : '' }}>Salary account</option>
                                    <option value="Fixed deposit account" {{ $check_user_kyc && $check_user_kyc->account_type == "Fixed deposit account" ? 'selected' : '' }}>Fixed deposit account</option>
                                    <option value="Recurring deposit account" {{ $check_user_kyc && $check_user_kyc->account_type == "Recurring deposit account" ? 'selected' : '' }}>Recurring deposit account</option>
								</select>
							</div>
                            <div class="col-lg-12">
                                <button type="submit" class="comm-btn w-100">Update Bank Account Details</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- bank details modal -->

<!-- upi modal -->
<div class="modal fade" id="upi-details" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">UPI method</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
            <div class="modal-body">
                <div class="add-deposite-main">
                    <div class="row">
                        <div class="col-lg-12">
                            <label class="label-main" for="">Add image</label>
                            <input class="input-main" type="file">
						</div>
                        <div class="col-lg-12">
                            <label class="label-main" for="">Add UPI ID</label>
                            <input class="input-main" type="text">
						</div>
                        <div class="col-lg-12">
                            <a href="#" class="comm-btn w-100">Add Bank Details</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
@push('js')
<script>
	
	$(document).ready(function() {
        $('#sendWithdrawalRequest').on('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
            
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to Withdrawal this amount!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, Withdrawal it!"
				}).then((result) => {
				
				//console.log('Swal result:', result); // Check the entire result object
                if (result.value) {
                    
                    var $form = $(this);
					var $submitButton = $form.find('button');
					var $spinButton = $form.find('button.spin-button');
					
					$submitButton.prop('disabled', true);
					$spinButton.addClass('loading');
					
					var formData = new FormData(this);
					formData.append('_token', "{{ csrf_token() }}");
					
					$.ajax({
						async: true,
						type: $form.attr('method'),
						url: $form.attr('action'),
						data: formData,
						cache: false,
						processData: false,
						contentType: false,
						dataType: 'Json',
						success: function(res) {
							
							if (res.status === "error") 
							{
								toastrMsg(res.status, res.msg);
								$submitButton.prop('disabled', false);
								$spinButton.removeClass('loading');
							}
							else if (res.status === "validation")
							{
								$submitButton.prop('disabled', false);
								$spinButton.removeClass('loading');
								
								$('.error').remove(); // Clear previous error messages
								
								$.each(res.errors, function(key, value) {
									var inputField = $('#' + key);
									var errorSpan = $('<span>')
									.addClass('error text-danger')
									.attr('id', key + 'Error')
									.text(value[0]);
									inputField.parent().append(errorSpan);
								});
							} 
							else 
							{
								toastrMsg(res.status, res.msg);
								$('body').css({'overflow': 'auto'});
								$('.error').remove();
								
								setTimeout(function() {
									location.href = "{{ url('withdrawal-history') }}"; 
								}, 2000);
							}
						}
					});
				}
			});
		});
	});
	
	$(document).ready(function() {
		function handleFormSubmission(formId) {
			$(formId).submit(function(event) {
				event.preventDefault();
				
				var $form = $(this);
				var $submitButton = $form.find('button');
				
				// Disable the button and show loading spinner
				$submitButton.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Saving...');
				
				var formData = new FormData(this);
				formData.append('_token', "{{ csrf_token() }}");
				
				// Perform AJAX request
				$.ajax({
					type: $form.attr('method'),
					url: $form.attr('action'),
					data: formData,
					cache: false,
					processData: false,
					contentType: false,
					dataType: 'json',
					success: function(res) 
					{
						$submitButton.prop('disabled', false).html('Update Bank Account Details');
						
						if (res.status === "error") 
						{
							toastrMsg(res.status, res.msg);
						} 
						else if (res.status === "validation") 
						{
							$('.error').remove(); // Clear previous error messages
							$.each(res.errors, function(key, value) {
								var inputField = $('#' + key);
								var errorSpan = $('<span>')
								.addClass('error text-danger')
								.text(value[0]);
								inputField.after(errorSpan); // Append error span right after the input field
							});
						} 
						else 
						{
							toastrMsg(res.status, res.msg);
							$('#bank-details').modal('hide');
							$('#bank-details').remove();
							$('.modal-backdrop').remove();
							 
							$('body').css({
								'overflow': 'auto'
							});
							setTimeout(function() {
								location.reload();
							}, 1000);
						}
					}
				});
			});
		}
		
		// Attach the form submission handler to the form
		handleFormSubmission('#updateBankAccounDetail');
	});
	
	function updateWalletAddress(input) {
		
		var walletKey = input.id;
		var walletAddress = input.value;
		var radioButton = document.querySelector('.' + walletKey);
		
		if (radioButton) {
			radioButton.value = walletAddress;
		}
	}
	
	function setWalletType(input)
	{
		var walletType = $(input).data('wallet-type');
		document.getElementById('wallet_type').value = walletType;
	}
</script>
@endpush
