<div class="modal fade" id="edit_withdrawal_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Withdrawal Data</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
            <div class="modal-body">
                <div class="add-deposite-main">
					<form id="updateWithdrawal" class="parsley-examples" action="{{ url('update-withdrawal',$get_user_wallet->id) }}" method="post">
						@csrf
						<div class="row">
							<div class="col-lg-12">
								<label class="label-main" for="">Transaction Method</label>
								<input class="input-main" type="text" value="{{ $get_user_wallet->transaction_method }}" disabled>
							</div>
							<div class="col-lg-12">
								<label class="label-main" for="">
									{{ $get_user_wallet->transaction_method != "Bank Account" ? 'Transaction Wallet Address' : 'Bank Account Number' }}
								</label>
								<input class="input-main" type="text" value="{{ $get_user_wallet->transaction_wallet_address }}" disabled>
							</div>
							<div class="col-lg-12">
								<label class="label-main" for="">Amount</label>
								<input class="input-main" type="text" name="amount" id="amount" value="{{ $get_user_wallet->amount }}">
							</div>
							@if($get_user_wallet->transaction_note)
							<div class="col-lg-12">
								<label class="label-main" for="">Transaction Note</label>
								<textarea class="input-main" type="text"  disabled>{{ $get_user_wallet->transaction_note }}</textarea>
							</div>
							@endif
							
							@if($get_user_wallet->transaction_image)
							<div class="col-lg-12">
								<label class="label-main" for="">Transaction Image</label>
								<img src="{{ url('public/storage/'.$get_user_wallet->transaction_image) }}" class="img-fluid mt-2" width="100px"/>
							</div>
							@endif
							<div class="col-lg-12">
								<button type="submite" class="comm-btn w-100">Save</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<script>
        $('#updateWithdrawal').submit(function(event) {
			event.preventDefault();
			
			$(this).find('button').prop('disabled', true);
			$(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
			
			var formData = new FormData(this);
			formData.append('_token', "{{csrf_token()}}");
			
			$.ajax({
				async: true,
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: formData,
				cache: false,
				processData: false,
				contentType: false,
				dataType: 'Json',
				success: function(res) {
					$('#updateWithdrawal').find('button').prop('disabled', false);
					$('#updateWithdrawal').find('button.spin-button').removeClass('loading').html('Save');
					if (res.status == "error") {
						toastrMsg(res.status, res.msg);
						} else if (res.status == "validation") {
						$('.error').remove();
						$.each(res.errors, function(key, value) {
							var inputField = $('#' + key);
							var errorSpan = $('<span>')
							.addClass('error text-danger')
							.attr('id', key + 'Error')
							.text(value[0]);
							inputField.parent().append(errorSpan);
						});
						} else {
						toastrMsg(res.status, res.msg);
						$('#edit_withdrawal_modal').modal('hide');
						$('#edit_withdrawal_modal').remove();
						$('.modal-backdrop').remove();
						$('body').css({
							'overflow': 'auto'
						});
						DataTable.draw();
					}
				}
			});
		});
	</script>
</div>