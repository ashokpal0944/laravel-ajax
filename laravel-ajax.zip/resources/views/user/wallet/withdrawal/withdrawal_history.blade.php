@extends('layouts.main')

@section('content')
<main class="page-content">
    <div class="wallet-balance-main">
        <div class="table-main">
            <h4>Withdrawal history</h4>
            <div class="table-responsive">
				<table id="withdrawal_history_list_data" class="table" style="width:100%">
					<thead>
						<tr>
							<th>Id</th>
							<th>Withdrawal Method</th>
							<th>Amount</th>
							<th>Wallet Address</th>
							<th>Status</th>
							<th>Created Date</th>
							<th>Action</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</main>
@endsection
@push('js')
<script>
	var DataTable = $('#withdrawal_history_list_data').DataTable({
		processing:true,
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': 'Loading...'
		},
		serverSide:true,
		bLengthChange: true,
		searching: true,
		bFilter: true,
		bInfo: true,
		iDisplayLength: 25,
		order: [[0, 'desc'] ],
		bAutoWidth: false,			 
		"ajax":{
			"url": "{{ url('get-withdrawal-history-data-ajax') }}",
			"dataType": "json",
			"type": "POST",
			"data": function (d) {
				d._token   = "{{csrf_token()}}";
				d.search   = $('input[type="search"]').val(); 
				d.filter_name   = $('#filter_name').val(); 
			}
		},
		"columns": [
		{ "data": "id" },
		{ "data": "transaction_method" },
		{ "data": "amount" },
		{ "data": "transaction_wallet_address" },
		{ "data": "is_status" },
		{ "data": "created_at" },
		{ "data": "action" }
		]
	});
	
	function editWithdrawal(obj,event)
	{  
		event.preventDefault(); 
		if (!modalOpen)
		{
			modalOpen = true;
			closemodal();
			$.get(obj, function(res)
			{
				$('body').find('#modal-view-render').html(res.view); 
				$('#edit_withdrawal_modal').modal('show');  
			}); 
		}
	}
	
	function deleteWithdrawal(obj,event)
	{	 
		event.preventDefault();
		Swal.fire({
			title:"Are you sure?",
			text:"You won't be able to revert this!",
			type:"warning",
			showCancelButton:!0,
			confirmButtonColor:"#3085d6",
			cancelButtonColor:"#d33",
			confirmButtonText:"Yes, delete it!"
		}).then(function(t)
		{
			t.value&&
			
			$.post(obj,{_token:"{{csrf_token()}}"},function(res)
			{ 
				if(res.status == "error")
				{
					Swal.fire("Error!",res.msg,"error")
				}
				else
				{ 
					Swal.fire("Deleted!",res.msg,"success")
					 DataTable.draw();
				}
			});
		}) 
	}
</script>
@endpush
