@extends('layouts.main')

@section('content')
<main class="page-content wallet-pakage-bg">
    <div class="top-plan-page select-plan">
        <div class="inner-page-head">
            <h3>Investment package </h3>
            <p>Select Plan Price</p>
		</div>
        <div class="wallet-page-cards">
			<form id="payInvestmentAmount" action="{{ url('pay-investment-amount')}}" method="post">
				@csrf
				<div class="row">
					@foreach($get_investment_plans as $key => $get_investment_plan)
					
					@php
					$check_val = $key + 1;
					@endphp
					
					<div class="col-xl-3 col-sm-4">
						<input type="radio" name="investment_plan_id" id="investment_plan_id_{{ $get_investment_plan->id }}" value="{{ $get_investment_plan->id }}"/>
						<label for="investment_plan_id_{{ $get_investment_plan->id }}">
							<div class="wallet-page-box wallet-color{{ $check_val }}">
								<h4>₹ {{ number_format($get_investment_plan->investment_amount, 2) }}</h4>
							</div>
						</label>
					</div>
					@endforeach
				</div>
				
				@if($total_investment == 0)
				<div class="main-btn">
					<button type="submit" class="comm-btn action-btn spin-btn">Select & Pay</button>
				</div>
				@else
				<div class="main-btn">
					<button type="button" onclick="investmentPlanActive()" class="comm-btn action-btn spin-btn">Select & Pay</button>
				</div>
				@endif
			</form>
		</div>
	</div>
</main>
@endsection
@push('js')
<script>
    $(document).ready(function() {
        $('#payInvestmentAmount').on('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
            
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to purchase this Investment package!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, purchase it!"
				}).then((result) => {
				
				//console.log('Swal result:', result); // Check the entire result object
                if (result.value) {
					
					var $form = $(this);
					var $submitButton = $form.find('button');
					var $spinButton = $form.find('button.spin-btn');
					
					// Disable the submit button and show the loading spinner
					$submitButton.prop('disabled', true);
					$spinButton.addClass('loading');
					
					// Serialize form data
					var formData = $form.serialize();
					
					$.ajax({
						type: $form.attr('method'),
						url: $form.attr('action'),
						data: formData,
						success: function(res) {
							// Re-enable the submit button and remove the loading spinner
							
							if (res.status === "error") 
							{
								$submitButton.prop('disabled', false);
								$spinButton.removeClass('loading');
								
								Swal.fire("Error!", res.msg, "error");
							} 
							else if (res.status === "validation") 
							{
								$submitButton.prop('disabled', false);
								$spinButton.removeClass('loading');
								
								$('.error').remove(); // Clear previous error messages
								
								Swal.fire("Error!", res.errors, "error");
								
								/* $.each(res.errors, function(key, value) {
									var inputField = $('#' + key);
									var errorSpan = $('<span>')
									.addClass('error text-danger')
									.attr('id', key + 'Error')
									.text(value[0]);
									inputField.parent().append(errorSpan);
								}); */
							} 
							else 
							{
								toastrMsg(res.status, res.msg);
								
								setTimeout(function() {
									location.href = "{{ url('investment-history') }}"; 
								}, 2000);
							}
						},
						error: function(err) 
						{
							// Re-enable the submit button and remove the loading spinner
							$submitButton.prop('disabled', false);
							$spinButton.removeClass('loading');
							
							// Display an error message
							Swal.fire("Error!", "An error occurred. Please try again.", "error");
							console.error('AJAX error:', err);
						}
					});
				}
			});
		});
	});
	
	function investmentPlanActive() {
		Swal.fire({
			title: "Investment",
			text: "Your investment package is already active. Please wait for your package to stop before buying another package.",
			icon: "warning",
			showCancelButton: false,
			confirmButtonColor: "#3085d6",
			cancelButtonColor: "#d33",
			confirmButtonText: "Ok",
		});
	}
	
</script>

@endpush
