@extends('layouts.main')

@section('content')
<main class="page-content">
    <div class="top-plan-page">
        <div class="wallet-page-cards">
            <div class="row">
                <div class="col-xxl-2 col-sm-4">
                    <a href="{{ url('investment-price') }}">
                        <div class="wallet-page-box">
                            <h4>Investment
							package </h4>
                            <img class="in-svg" src="{{ url('front/images/custom-image/wallet-arrow.svg') }}" alt="">
						</div>
					</a>
				</div>
                <div class="col-xxl-2 col-sm-4">
                    <a href="javascript:void(0);">
                        <div class="wallet-page-box wallet-color2">
                            <h4>short term
							investment</h4>
                            <img class="in-svg" src="{{ url('front/images/custom-image/wallet-arrow.svg') }}" alt="">
						</div>
					</a>
				</div>
                <div class="col-xxl-2 col-sm-4">
                    <a href="{{ url('educations') }}">
                        <div class="wallet-page-box wallet-color3">
                            <h4>Educational
							InvestmentI</h4>
                            <img class="in-svg" src="{{ url('front/images/custom-image/wallet-arrow.svg') }}" alt="">
						</div>
					</a>
				</div>
                <div class="col-xxl-2 col-sm-4">
                    <a href="{{ url('ai-bots') }}">
                        <div class="wallet-page-box wallet-color5">
                            <h4>AI & BOTS </h4>
                            <img class="in-svg" src="{{ url('front/images/custom-image/wallet-arrow.svg') }}" alt="">
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</main>
@endsection
