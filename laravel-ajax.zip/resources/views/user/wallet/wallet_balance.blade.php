@extends('layouts.main')

@section('content')
<main class="page-content">
    <div class="wallet-balance-main">
        <div class="row">
            <div class="col-xl-2 col-sm-4">
                <a href="{{ url('top-plan') }}">
                    <div class="wallet-balance-card active">
                        <img src="{{ url('front/images/custom-image/wallet-icons1.png') }}" alt="">
                        <h5>Top Tier Plans</h5>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-sm-4">
                <a href="javascript:void(0)">
                    <div class="wallet-balance-card">
                        <img src="{{ url('front/images/custom-image/wallet-icons2.png') }}" alt="">
                        <h5>Deposit</h5>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-sm-4">
                <a href="javascript:void(0)">
                    <div class="wallet-balance-card">
                        <img src="{{ url('front/images/custom-image/wallet-icons3.png') }}" alt="">
                        <h5>Withdrawal</h5>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-sm-4">
                <a href="deposit-history.php">
                    <div class="wallet-balance-card">
                        <img src="{{ url('front/images/custom-image/wallet-icons4.png') }}" alt="">
                        <h5>Deposit History</h5>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-sm-4">
                <a href="withdrawal-history.php">
                    <div class="wallet-balance-card">
                        <img src="{{ url('front/images/custom-image/wallet-icons4.png') }}" alt="">
                        <h5>Withdrawal History</h5>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-sm-4">
                <a href="purchase-history.php">
                    <div class="wallet-balance-card">
                        <img src="{{ url('front/images/custom-image/wallet-icons4.png') }}" alt="">
                        <h5>Purchase History</h5>
                    </div>
                </a>
            </div>
        </div>
        <div class="table-main">
            <h4>Transaction History</h4>
            <div class="table-responsive">
                <table class="table mb-0">
                    <tbody>
                        <tr>
                            <td><span><img class="me-3" src="{{ url('front/images/custom-image/arrow-green.svg') }}" alt=""></span> ia123Dsjksbcia123Dsjksbc </td>
                            <td class="text-end">$ 124</td>
                        </tr>
                        <tr>
                            <td><span><img class="me-3" src="{{ url('front/images/custom-image/arrow-red.svg') }}" alt=""></span> ia123Dsjksbcia123Dsjksbc </td>
                            <td class="text-end">$ 124</td>
                        </tr>
                        <tr>
                            <td><span><img class="me-3" src="{{ url('front/images/custom-image/arrow-green.svg') }}" alt=""></span> ia123Dsjksbcia123Dsjksbc </td>
                            <td class="text-end">$ 124</td>
                        </tr>
                        <tr>
                            <td><span><img class="me-3" src="{{ url('front/images/custom-image/arrow-red.svg') }}" alt=""></span> ia123Dsjksbcia123Dsjksbc </td>
                            <td class="text-end">$ 124</td>
                        </tr>
                        <tr>
                            <td><span><img class="me-3" src="{{ url('front/images/custom-image/arrow-green.svg') }}" alt=""></span> ia123Dsjksbcia123Dsjksbc </td>
                            <td class="text-end">$ 124</td>
                        </tr>
                        <tr>
                            <td><span><img class="me-3" src="{{ url('front/images/custom-image/arrow-red.svg') }}" alt=""></span> ia123Dsjksbcia123Dsjksbc </td>
                            <td class="text-end">$ 124</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
@endsection
