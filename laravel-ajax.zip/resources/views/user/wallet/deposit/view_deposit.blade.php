<div class="modal fade" id="view_deposit" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Deposit History View</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="add-deposite-main">
                    <div class="row">
                        <div class="col-lg-12">
                            <label class="label-main" for="">Transaction Method</label>
                            <input class="input-main" type="text" value="{{ $get_user_wallet->transaction_method }}" disabled>
                        </div>
						<div class="col-lg-12">
							<label class="label-main" for="">
								{{ $get_user_wallet->transaction_method != "Bank Account" ? 'Transaction Wallet Address' : 'Bank Account Number' }}
							</label>
							<input class="input-main" type="text" value="{{ $get_user_wallet->transaction_wallet_address }}" disabled>
						</div>
						<div class="col-lg-12">
                            <label class="label-main" for="">Amount</label>
                            <input class="input-main" type="text" value="{{ $get_user_wallet->amount }}" disabled>
                        </div>
						<div class="col-lg-12">
                            <label class="label-main" for="">Transaction Id</label>
                            <input class="input-main" type="text" value="{{ $get_user_wallet->transaction_id }}" disabled>
                        </div>
						@if($get_user_wallet->transaction_note)
						<div class="col-lg-12">
                            <label class="label-main" for="">Transaction Note</label>
                            <textarea class="input-main" type="text"  disabled>{{ $get_user_wallet->transaction_note }}</textarea>
                        </div>
						@endif
						@if($get_user_wallet->transaction_image)
						<div class="col-lg-12">
                            <label class="label-main" for="">Transaction Image</label>
							<img src="{{ url('public/storage/'.$get_user_wallet->transaction_image) }}" class="img-fluid mt-2" width="100px"/>
                        </div>
						@endif
						<div class="col-lg-12">
                            <label class="label-main" for="">Transaction Status</label>
							<select class="input-main" disabled>
								<option value="">Select Status</option>
								<option value="0" {{ $get_user_wallet->is_status == 0 ? 'selected' : '' }}>Pending</option>
								<option value="1" {{ $get_user_wallet->is_status == 1 ? 'selected' : '' }}>Approve</option>
								<option value="2" {{ $get_user_wallet->is_status == 2 ? 'selected' : '' }}>Rejected</option>
							</select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>