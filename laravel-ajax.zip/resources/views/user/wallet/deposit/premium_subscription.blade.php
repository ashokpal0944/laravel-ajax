@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="top-plan-page wallet-payment">
        <div class="wallet-payment-main">
            <div class="row">
                <div class="col-xxl-6 col-lg-8">
                    <div class="wallet-payment-deta">
                        <div class="wallet-payment-form">
                            <form id="sendDepositeData" method="post" action="{{ url('premium-subscription') }}">
								@csrf
                                <div class="row"> 
									@foreach($admin_wallet_address as $key => $admin_wallet_addres)
                                    <div class="col-lg-12">
                                        <div class="deposite-deta">
                                            <div class="deposite-radio">
                                                <div class="form-check custom-radio">
                                                    <input class="form-check-input" type="radio" name="wallet_address" id="wallet_{{ $admin_wallet_addres['wallet_address'] }}" value="{{ $admin_wallet_addres['wallet_address'] }}">
                                                    <label class="form-check-label" for="flexRadioDefault1"></label>
                                                </div>
                                            </div>
                                            <div class="deposite-field">
                                                <h6>{{ $key }}</h6>
                                                <!--<label class="label-main" for="">Add withdrawal address</label>-->
                                                <input class="input-main" type="text" value="{{ $admin_wallet_addres['wallet_address'] }}" disabled>
                                            </div>
                                        </div>
                                    </div>
									@endforeach
									
									@if(config('setting.account_number') != '' && config('setting.upi_address') != '')
										<div class="col-lg-12">
											<label class="label-main" for="">INR method</label>
										</div>
										@if(config('setting.account_number') != '')
										<div class="col-lg-12">
											<div class="deposite-deta">
												<div class="deposite-radio">
													<div class="form-check custom-radio">
														<input class="form-check-input" type="radio" name="wallet_address" id="wallet_bank" value="{{ config('setting.account_number') }}">
														<label class="form-check-label" for="wallet_bank"></label>
													</div>
												</div>
												<div class="deposite-field">
												   <div class="select-btn" data-bs-toggle="modal" data-bs-target="#bank-details">
														<label for="wallet_bank">Bank Details</label>
													</div>
												</div>
											</div>
										</div>
										@endif
										
										@if(config('setting.upi_address') != '')
										<div class="col-lg-12">
											<div class="deposite-deta">
												<div class="deposite-radio">
													<div class="form-check custom-radio">
														<input class="form-check-input" type="radio" name="wallet_address" id="wallet_upi" value="{{ config('setting.upi_address') }}">
														<label class="form-check-label" for="wallet_upi"></label>
													</div>
												</div>
												<div class="deposite-field">
												   <div class="select-btn" data-bs-toggle="modal" data-bs-target="#upi-details">
														<label for="wallet_upi">UPI</label>
													</div>
												</div>
											</div>
										</div>
										@endif
									@endif
                                    <div class="col-lg-12">
                                        <button type="submit" class="comm-btn action-btn spin-btn" style="margin: 0 auto;">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!--end page main-->

<!-- bank details modal -->
<div class="modal fade" id="bank-details" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Bank details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="add-deposite-main">
                    <div class="row">
                        <div class="col-lg-12">
                            <label class="label-main" for="">Bank account name</label>
                            <input class="input-main" type="text" value="{{ config('setting.bank_holder_name') }}" disabled>
                        </div>
                        <div class="col-lg-12">
                            <label class="label-main" for="">Bank name</label>
                            <input class="input-main" type="text" value="{{ config('setting.bank_name') }}" disabled>
                        </div>
                        <div class="col-lg-12">
                            <label class="label-main" for="">Confirm Account No.</label>
                            <input class="input-main" type="text" value="{{ config('setting.account_number') }}" disabled>
                        </div>
                        <div class="col-lg-12">
                            <label class="label-main" for="">IFSC Code</label>
                            <input class="input-main" type="text" value="{{ config('setting.ifsc_code') }}" disabled>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- bank details modal -->

<!-- upi modal -->
<div class="modal fade" id="upi-details" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">UPI method</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="add-deposite-main">
                    <div class="row">
                        <div class="col-lg-12">
                            <img src="{{ url('storage/'.config('setting.qr_code')) }}" alt="" style="width:100px;">
                        </div>
                        <div class="col-lg-12">
                            <label class="label-main" for="">Add UPI ID</label>
                            <input class="input-main" type="text" value="{{ config('setting.upi_address') }}" disabled>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- upi details modal -->
@endsection
@push('js')
<script>
	
</script>
@endpush
