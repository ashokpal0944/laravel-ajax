@extends('layouts.main')

@section('content')
<main class="page-content">
    <div class="wallet-balance-main">
        <div class="table-main">
            <h4>Deposit history</h4>
            <div class="table-responsive">
				<table id="deposit_history_list_data" class="table" style="width:100%">
					<thead>
						<tr>
							<th>Id</th>
							<th>Deposit Method</th>
							<th>Amount</th>
							<th>Transaction Id</th>
							<th>Status</th>
							<th>Created Date</th>
							<th>Action</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</main>
@endsection
@push('js')
<script>
	var DataTable = $('#deposit_history_list_data').DataTable({
		processing:true,
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': 'Loading...'
		},
		serverSide:true,
		bLengthChange: true,
		searching: true,
		bFilter: true,
		bInfo: true,
		iDisplayLength: 25,
		order: [[0, 'desc'] ],
		bAutoWidth: false,			 
		"ajax":{
			"url": "{{ url('get-deposit-history-data-ajax') }}",
			"dataType": "json",
			"type": "POST",
			"data": function (d) {
				d._token   = "{{csrf_token()}}";
				d.search   = $('input[type="search"]').val(); 
				d.filter_name   = $('#filter_name').val(); 
			}
		},
		"columns": [
		{ "data": "id" },
		{ "data": "transaction_method" },
		{ "data": "amount" },
		{ "data": "transaction_id" },
		{ "data": "is_status" },
		{ "data": "created_at" },
		{ "data": "action" }
		]
	});
	
	function viewDeposit(obj,event)
	{  
		event.preventDefault(); 
		if (!modalOpen)
		{
			modalOpen = true;
			closemodal();
			$.get(obj, function(res)
			{
				$('body').find('#modal-view-render').html(res.view); 
				$('#view_deposit').modal('show');  
			}); 
		}
	}
</script>
@endpush
