@extends('layouts.main')

@section('content')
<main class="page-content">
    <div class="wallet-balance-main">
        <div class="table-main">
            <h4>Purchase history</h4>
            <div class="table-responsive">
				<table id="purchase_history_list_data" class="table" style="width:100%">
					<thead>
						<tr>
							<th>Id</th>
							<th>Course Name</th>
							<th>Course Type</th>
							<th>Course Price</th>
							<th>Start Date</th>
							<th>Expire Date</th>
							<th>Status</th>
							<th>Created Date</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</main>
@endsection
@push('js')
<script>
	var DataTable = $('#purchase_history_list_data').DataTable({
		processing:true,
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': 'Loading...'
		},
		serverSide:true,
		bLengthChange: true,
		searching: true,
		bFilter: true,
		bInfo: true,
		iDisplayLength: 25,
		order: [[0, 'desc'] ],
		bAutoWidth: false,			 
		"ajax":{
			"url": "{{ url('get-purchase-history-data-ajax') }}",
			"dataType": "json",
			"type": "POST",
			"data": function (d) {
				d._token   = "{{csrf_token()}}";
				d.search   = $('input[type="search"]').val(); 
				d.filter_name   = $('#filter_name').val(); 
			}
		},
		"columns": [
		{ "data": "id" },
		{ "data": "course_name" },
		{ "data": "course_type" },
		{ "data": "course_price" },
		{ "data": "start_date" },
		{ "data": "expire_date" },
		{ "data": "is_status" },
		{ "data": "created_at" }
		]
	});
</script>
@endpush
