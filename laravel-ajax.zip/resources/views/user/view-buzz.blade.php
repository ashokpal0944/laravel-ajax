@extends('layouts.main')

@section('content')

<main class="page-content">
    <div class="view-buzz-deta">
		<div class="liquid-basket">
            <div class="investment-head">
                <h4>Stock Highlights</h4>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="liquid-basket-card">
                        <div class="liquid-basket-head">
                            <h4>Stock Sentiment</h4>
                            <!--<h6>Free</h6>-->
                        </div>
                        <div class="liquid-basket-footer">
                            <a href="javascript:void(0);">Buyers are optimistic about the price rise, stock in uptrend</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="liquid-basket-card">
                        <div class="liquid-basket-head">
                            <h4>Market pricing</h4>
                            <h6>Fairly valued </h6>
                        </div>
                        <div class="liquid-basket-footer">
                            <a href="javascript:void(0);">stock is trending at reasonable price</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="liquid-basket-card">
                        <div class="liquid-basket-head">
                            <h4>Profits</h4>
                            <h6>192.8%</h6>
                        </div>
                        <div class="liquid-basket-footer">
                            <a href="javascript:void(0);">profit increases as compared to last quater</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="liquid-basket-card">
                        <div class="liquid-basket-head">
                            <h4>Weekly Momentum</h4>
                            <h6>Positive</h6>
                        </div>
                        <div class="liquid-basket-footer">
                            <a href="javascript:void(0);">profit increases as compared to last quater</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="liquid-basket">
            <div class="investment-head">
                <h4>SWOT analysis</h4>
            </div>
            <div class="view-buzz-analys">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="buzz-analys-card">
                            <h5>Strength</h5>
                            <h6>7</h6>
                            <span>S</span>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="buzz-analys-card buzz-analys-card2">
                            <h5>Weakness</h5>
                            <h6>1</h6>
                            <span>W</span>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="buzz-analys-card buzz-analys-card3">
                            <h5>Opportunity</h5>
                            <h6>0</h6>
                            <span>O</span>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="buzz-analys-card buzz-analys-card2">
                            <h5>Weakness</h5>
                            <h6>1</h6>
                            <span>T</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="liquid-basket">
            <div class="investment-head">
                <h4>Price Volatility</h4>
            </div>
            <div class="buzz-analys-img">
                <img src="{{url('front/images/custom-image/price-img.png') }}" alt="">
            </div>
        </div>
        <div class="liquid-basket">
            <div class="investment-head">
                <h4>Performance</h4>
            </div>
            <div class="buzz-analys-img">
                <img src="{{url('front/images/custom-image/performance-img.png') }}" alt="">
            </div>
        </div>
        <div class="liquid-basket">
            <div class="investment-head">
                <h4>Fundamentals</h4>
            </div>
            <div class="buzz-analys-img">
                <img src="{{url('front/images/custom-image/fundamentals-img.png') }}" alt="">
            </div>
        </div>
        <div class="liquid-basket">
            <div class="investment-head">
                <h4>Price  & Volume</h4>
            </div>
            <div class="buzz-analys-img">
                <img src="{{url('front/images/custom-image/volume-img.png') }}" alt="">
            </div>
        </div>
        <div class="liquid-basket">
            <div class="investment-head">
                <h4>Financial</h4>
            </div>
            <div class="buzz-analys-img">
                <img src="{{url('front/images/custom-image/financial-img.png') }}" alt="">
            </div>
        </div>
        <div class="liquid-basket">
            <div class="investment-head">
                <h4>Shareholding</h4>
            </div>
            <div class="buzz-analys-img">
                <img src="{{url('front/images/custom-image/shareholding-img.png') }}" alt="">
            </div>
        </div>
        <div class="main-btn">
				<a href="javascript:void(0)" class="comm-btn">comming Soon</a>
			</div>
    </div>
</main>

@endsection
@push('js')

@endpush																																																																																																										