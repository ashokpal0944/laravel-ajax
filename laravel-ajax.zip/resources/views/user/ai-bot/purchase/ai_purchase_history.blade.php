@extends('layouts.main')

@section('content')
<main class="page-content">
    <div class="wallet-balance-main">
        <div class="table-main">
            <h4>Ai Bot Purchase History</h4>
            <div class="table-responsive">
				<table id="main_data" class="table" style="width:100%">
					<thead>
						<tr>
							<th>Id</th>
							<th>Bot Type</th>
							<th>Purchase Amount</th>
							<th>Account Holder Name</th>
							<th>Email</th>
							<th>Server Name</th>
							<th>Account Number</th>
							<th>Main Password</th>
							<th>Investor Password</th>
							<th>Status</th>
							<th>Created Date</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</main>
@endsection
@push('js')
<script>
	var DataTable = $('#main_data').DataTable({
		processing:true,
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': 'Loading...'
		},
		serverSide:true,
		bLengthChange: true,
		searching: true,
		bFilter: true,
		bInfo: true,
		iDisplayLength: 25,
		order: [[0, 'desc'] ],
		bAutoWidth: false,			 
		"ajax":{
			"url": "{{ url('get-ai-bot-purchase-history-data-ajax') }}",
			"dataType": "json",
			"type": "POST",
			"data": function (d) {
				d._token   = "{{csrf_token()}}";
				d.search   = $('input[type="search"]').val(); 
				d.filter_name   = $('#filter_name').val(); 
			}
		},
		"columns": [
		{ "data": "id" },
		{ "data": "ai_bot_id" },
		{ "data": "amount" },
		{ "data": "account_holder_name" },
		{ "data": "email" },
		{ "data": "server_name" },
		{ "data": "account_number" },
		{ "data": "main_password" },
		{ "data": "investor_password" },
		{ "data": "is_status" },
		{ "data": "created_at" }
		]
	});
	
</script>
@endpush
