@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="ai-tab-main strategies-page">
        <div class="ai-tab-head">
            <ul class="nav nav-pills nav-pills-warning mb-3" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" data-bs-toggle="pill" href="#warning-pills-home" role="tab" aria-selected="true">
                        <div class="tab-title">Strategy</div>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" data-bs-toggle="pill" href="#warning-pills-profile" role="tab" aria-selected="false">
                        <div class="tab-title">Copying</div>
                    </a>
                </li>
            </ul>
            <div class="ai-head-right">
                <h4>Min : <span>{{ $get_ai_strategy->min_amount }}</span></h4>
                <h4>Max : <span>{{ $get_ai_strategy->max_amount }}</span></h4>
            </div>
        </div>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="warning-pills-home" role="tabpanel">
                <div class="strategies-tab-main">
                    <div class="row">
						@foreach($get_ai_strategy->aiStrategies as $ai_strategy_val)
                        <div class="col-lg-3">
                            <div class="strategies-tab-card">
                                <div class="strategies-card-head">
                                    <a href="strategies-inner.php">
                                        <h4><span>Live</span> {{ $ai_strategy_val->title }}....</h4>
                                    </a>
                                    <div class="strategies-card-ico">
                                        <a href="#"><img src="assets/images/custom-image/strategies-star.svg" alt=""></a>
                                        <a href="#"><img src="assets/images/custom-image/strategies-share.svg" alt=""></a>
                                    </div>
                                </div>
                                <div class="strategies-card-name">
                                    <h5><span>{{ substr($ai_strategy_val->title, 0, 1) }}</span>{{ $ai_strategy_val->title }}</h5>
                                    <h6>ROI Over all time : <span>+{{ $ai_strategy_val->return_of_intrest }}%</span></h6>
                                </div>
                                <div class="strategies-card-value">
                                    <h4>M : 0.00%</h4>
                                    <h4>V : $0</h4>
                                    <h4>P : 15.00%</h4>
                                    <h4>Min inv : $ 1000.00</h4>
                                </div>
                                <div class="strategies-card-chart">
                                    <div id="line-chart-strategy-{{ $ai_strategy_val->id }}"></div>
                                </div>
                            </div>
                        </div>
						@endforeach
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="warning-pills-profile" role="tabpanel">
                tab2
            </div>
        </div>
    </div>
</main>
@endsection
@push('js')
<script>
<?php
// Prepare data for all charts at once to reduce PHP-JS mixing
$chartConfigs = [];
foreach ($get_ai_strategy->aiStrategies as $ai_strategy_val) {
    $chartConfigs[] = [
        'id' => $ai_strategy_val->id,
        'data' => explode(",", $ai_strategy_val->chart_data),
        'categories' => explode(",", $ai_strategy_val->chart_label),
    ];
}
?>

document.addEventListener("DOMContentLoaded", function () {
    // Loop through all chart configurations
    var chartConfigs = <?php echo json_encode($chartConfigs); ?>;

    chartConfigs.forEach(function(config) {
        var options = {
            series: [{
                name: 'series1',
                data: config.data
            }],
            chart: {
                height: 200,
                type: 'area'
            },
            dataLabels: {
                enabled: false,
            },
            stroke: {
                curve: 'smooth',
                width: 2
            },
            xaxis: {
                type: 'datetime',
                categories: config.categories,
                labels: {
                    style: {
                        colors: '#FFFFFF'
                    }
                }
            },
            yaxis: {
                labels: {
                    style: {
                        colors: '#FFFFFF'
                    }
                }
            },
            colors: ["#01C32C"],
            grid: {
                borderColor: '#2C2602'
            },
            tooltip: {
                x: {
                    format: 'dd/MM/yy HH:mm'
                },
            },
        };

        var chart = new ApexCharts(document.querySelector("#line-chart-strategy-" + config.id), options);
        chart.render();
    });
});
</script>

@endpush
