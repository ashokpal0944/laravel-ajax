@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="ai-bots-main">
        <div class="row">
            <div class="col-xxl-3 col-md-4 col-6">
                <div class="ai-bots-card">
                    <a href="{{ url('view-ai-boat/Forex') }}">
                        <div class="ai-bots-head">
                            <img src="{{ url('front/images/custom-image/ai-head1.png') }}" alt="">
                            <h5>Forex</h5>
                        </div>
                        <div class="ai-bots-img">
                            <img src="{{ url('front/images/custom-image/bot-img.png') }}" alt="">
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-xxl-3 col-md-4 col-6">
                <div class="ai-bots-card">
                    <a href="{{ url('view-ai-boat/Crypto') }}">
                        <div class="ai-bots-head">
                            <img src="{{ url('front/images/custom-image/ai-head2.png') }}" alt="">
                            <h5>Crypto</h5>
                        </div>
                        <div class="ai-bots-img">
                            <img src="{{ url('front/images/custom-image/bot-img.png') }}" alt="">
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-xxl-3 col-md-4 col-6">
                <div class="ai-bots-card">
                    <a href="{{ url('view-ai-boat/Stock') }}">
                        <div class="ai-bots-head">
                            <img src="{{ url('front/images/custom-image/ai-head3.png') }}" alt="">
                            <h5>Stock</h5>
                        </div>
                        <div class="ai-bots-img">
                            <img src="{{ url('front/images/custom-image/bot-img.png') }}" alt="">
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection
