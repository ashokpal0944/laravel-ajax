@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="ai-tab-main">
        <div class="ai-tab-head">
            <ul class="nav nav-pills nav-pills-warning mb-3" role="tablist">
				@foreach($get_aibots as $key => $get_aibot)
				
				<?php
				$check_purchase_ai = App\Models\AiBotPurchase::where('user_id',Auth::user()->id)->where('ai_bot_id',$get_aibot->id)->count();
				?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link {{ empty($risk_type) && $key == 0 ? 'active' : ($risk_type == $get_aibot->risk_type ? 'active' : '') }}" data-purchase-ai="{{ $check_purchase_ai }}" data-risk-type="{{ $get_aibot->risk_type }}" data-ai-bot-id="{{ $get_aibot->id }}" data-bs-toggle="pill" data-min-val="{{ $get_aibot->min_amount }}" data-max-val="{{ $get_aibot->max_amount }}" href="#{{ $get_aibot->currency_type }}_{{ $get_aibot->id }}" role="tab" aria-selected="true">
                        <div class="tab-title">{{ $get_aibot->risk_type }} Risk</div>
					</a>
				</li>
				@endforeach
			</ul>
            <div class="ai-head-right">
                <h4>Min : <span id="min_val">0</span></h4>
                <h4>Max : <span id="max_val">0</span></h4>
			</div>
		</div>
        <div class="tab-content">
			@foreach($get_aibots as $key => $get_aibot)
            <div class="tab-pane fade @if($key == 0) {{ 'show active' }} @endif" id="{{ $get_aibot->currency_type }}_{{ $get_aibot->id }}" role="tabpanel">
				@php
				$detaClass = 'low-deta'; // Default class
				$textColor = 'text-green'; // Default color
				
				if ($get_aibot->risk_type == "High") 
				{
				$detaClass = 'low-deta'; // Use the default class
				$textColor = 'text-green';
				} elseif ($get_aibot->risk_type == "Low") {
				$detaClass = 'low-deta low-deta-row';
				$textColor = 'text-red';
				} else {
				$detaClass = 'low-deta low-deta-yellow';
				$textColor = 'text-green';
				}
				@endphp
				<div class="col-md-4 col-sm-6 mb-3">
					<div class="liquid-basket-card">
						<div class="liquid-basket-head">
							<h4><span><img src="{{ url('public/storage/'.$get_aibot->icon) }}" alt=""></span> {{ $get_aibot->title }}</h4>
							<!--<h6>Free</h6>-->
						</div>
						<div class="liquid-basket-text">
							<h5>Min Amount <br><span>₹ {{ $get_aibot->min_amount }}</span></h5>
							<h5>1 y return <br><span class="text-green">{{ $get_aibot->yearly_return }} %</span></h5>
							
							<h5 class="{{ $detaClass }}">Validity <br>
								<span class="{{ $textColor }}">
									<img class="in-svg" src="{{ url('front/images/custom-image/speedometer.svg') }}" alt=""> 
									{{ $get_aibot->risk_type }}
								</span>
							</h5>
						</div>
						<div class="liquid-basket-footer">
							<a href="javascript:void(0);"><?php //echo substr($get_aibot->description, 0, 50)?> Evergreen Solution for all market conditions <span><img src="{{ url('front/images/custom-image/arrow.svg') }}" alt=""></span></a>
						</div>
					</div>
				</div>
                <?php echo $get_aibot->description ?>
			</div>
			@if(count($get_aibot->aiStrategies) > 0)
			<div class="ai-btn">
				<a href="{{ url('view-strategy',$get_aibot->id) }}" class="comm-btn">Start Strategies</a>
			</div>
			@endif
			@endforeach
		</div>
		<div class="ai-btn">
			<a href="{{ url('view-strategy',$get_aibot->id) }}" id="start_strategies_show" style="display:none;" class="comm-btn">Start Strategies</a>
			<button type="button" class="comm-btn" onclick="showPurchaseStrategies();">Purchase Strategies</button>
		</div>
	</div>
</main>

<div class="modal fade" id="show_purchase_strategies" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Purchase Strategies</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<form id="purchaseForm" method="post" action="{{ url('purchase-ai-bot') }}">
					@csrf
					<input type="hidden" id="ai_bot_id" name="ai_bot_id" value="">
					<div class="add-deposite-main">
						<div class="row">
							<div class="col-lg-12">
								<label class="label-main" for="">Amount</label>
								<input class="input-main" id="amount" name="amount" min="500" max="1000" type="number" onchange="validateAmount(this)">
							</div>
							<div class="col-lg-12">
								<label class="label-main" for="account_holder_name">Account Holder Name</label>
								<input class="input-main" id="account_holder_name" name="account_holder_name" type="text">
							</div>
							<div class="col-lg-12">
								<label class="label-main" for="email">Email</label>
								<input class="input-main" id="email" name="email" type="email">
							</div>
							<div class="col-lg-12">
								<label class="label-main" for="server_name">Server Name</label>
								<input class="input-main" id="server_name" name="server_name" type="text">
							</div>
							<div class="col-lg-12">
								<label class="label-main" for="account_number">Account Number</label>
								<input class="input-main" id="account_number" name="account_number" type="text">
							</div>
							<div class="col-lg-12">
								<label class="label-main" for="main_password">Main Password</label>
								<input class="input-main" id="main_password" name="main_password" type="text">
							</div>
							<div class="col-lg-12">
								<label class="label-main" for="investor_password">Investor Password</label>
								<input class="input-main" id="investor_password" name="investor_password" type="text">
							</div>
							<div class="col-lg-12">
								<button type="submit" class="comm-btn w-100 spin-button">Purchase</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>


@endsection
@push('js')
<script>
    $(document).ready(function(){
		// On click of the nav link (tab), update min_val and max_val
		$('.nav-link').on('click', function() {
			// Get the min and max values from data attributes
			var minVal = $(this).data('min-val');
			var maxVal = $(this).data('max-val');
			
			
			var aiBoatId = $(this).data('ai-bot-id');
			$('#ai_bot_id').val(aiBoatId);
			
			var purchaseAi = $(this).data('purchase-ai');
			
			if(purchaseAi != 0)
			{
				$("#start_strategies_show").show();
			}
			else
			{
				$("#start_strategies_show").hide();
			}
			
			// Update the span tags with the new values
			$('#min_val').text(minVal);
			$('#max_val').text(maxVal);
			
			
			const amountInput = document.getElementById('amount');
			
			amountInput.setAttribute('min', minVal);
			amountInput.setAttribute('max', maxVal); 
		});
		
		// Optional: trigger click on the first active tab on page load
		$('.nav-link.active').trigger('click');
	});
	
	function showPurchaseStrategies() {
		var $form = $('#purchaseForm');  // Replace #purchaseForm with the actual ID or selector of your form
		
		if ($form.length) {
			$form[0].reset();  // Reset the form
		}
		
		$('#show_purchase_strategies').modal('show');
	}
	
	function validateAmount(input) {
		let value = parseFloat(input.value);
		let min = parseFloat(input.min);
		let max = parseFloat(input.max);
	
		if (isNaN(value)) {
			return;
		}
		
		if (value < min) {
			input.value = min;
			} else if (value > max) {
			input.value = max;
		}
	}
	
	$('#purchaseForm').submit(function(event) {
        event.preventDefault();
        $(this).find('button').prop('disabled', true);
        $(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
        var formData = new FormData(this);
        formData.append('_token', "{{csrf_token()}}");
        $.ajax({
            async: true,
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            dataType: 'Json',
            success: function(res) {
                $('#purchaseForm').find('button').prop('disabled', false);
                $('#purchaseForm').find('button.spin-button').removeClass('loading').html(
                'Save');
                if (res.status == "error") 
				{
                    toastrMsg(res.status, res.msg);
                } 
				else if(res.status == "validation")
				{
					$('.error').remove();  
					$.each(res.errors, function(key, value) {
						var inputField = $('#' + key);
						var errorSpan = $('<span>')
						.addClass('error text-danger') 
						.attr('id', key + 'Error')
						.text(value[0]);  
						inputField.parent().append(errorSpan);
					});
				}
				else
				{
                    toastrMsg(res.status, res.msg);
                    $('#show_purchase_strategies').modal('hide');
                    $('#show_purchase_strategies').remove();
                    $('.modal-backdrop').remove();
                    $('body').css({
                        'overflow': 'auto'
                    });
					
                    setTimeout(function() {
						location.reload();
					}, 2000);
                }
            }
        });
    });
</script>
@endpush