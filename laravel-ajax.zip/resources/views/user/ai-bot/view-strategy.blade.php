@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="ai-tab-main strategies-page">
        <div class="ai-tab-head">
            <ul class="nav nav-pills nav-pills-warning mb-3" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" data-bs-toggle="pill" href="#warning-pills-home" role="tab" aria-selected="true">
                        <div class="tab-title">Strategy</div>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" data-bs-toggle="pill" href="#warning-pills-profile" role="tab" aria-selected="false">
                        <div class="tab-title">Copying</div>
                    </a>
                </li>
            </ul>
            <div class="ai-head-right">
                <h4>Min : <span>5000</span></h4>
                <h4>Max : <span>1000000</span></h4>
            </div>
        </div>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="warning-pills-home" role="tabpanel">
                <div class="strategies-tab-main">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="strategies-tab-card">
                                <div class="strategies-card-head">
                                    <a href="strategies-inner.php">
                                        <h4><span>Live</span> Put the bunny back....</h4>
                                    </a>
                                    <div class="strategies-card-ico">
                                        <a href="#"><img src="assets/images/custom-image/strategies-star.svg" alt=""></a>
                                        <a href="#"><img src="assets/images/custom-image/strategies-share.svg" alt=""></a>
                                    </div>
                                </div>
                                <div class="strategies-card-name">
                                    <h5><span>B</span>Binomial Rough</h5>
                                    <h6>ROI Over all time : <span>+646.57%</span></h6>
                                </div>
                                <div class="strategies-card-value">
                                    <h4>M : 0.00%</h4>
                                    <h4>V : $0</h4>
                                    <h4>P : 15.00%</h4>
                                    <h4>Min inv : $ 1000.00</h4>
                                </div>
                                <div class="strategies-card-chart">
                                    <div id="line-chart"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="strategies-tab-card">
                                <div class="strategies-card-head">
                                    <h4><span>Live</span> Put the bunny back....</h4>
                                    <div class="strategies-card-ico">
                                        <a href="#"><img src="assets/images/custom-image/strategies-star.svg" alt=""></a>
                                        <a href="#"><img src="assets/images/custom-image/strategies-share.svg" alt=""></a>
                                    </div>
                                </div>
                                <div class="strategies-card-name">
                                    <h5><span>B</span>Binomial Rough</h5>
                                    <h6>ROI Over all time : <span>+646.57%</span></h6>
                                </div>
                                <div class="strategies-card-value">
                                    <h4>M : 0.00%</h4>
                                    <h4>V : $0</h4>
                                    <h4>P : 15.00%</h4>
                                    <h4>Min inv : $ 1000.00</h4>
                                </div>
                                <div class="strategies-card-chart">
                                    <div id="line-chart"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="strategies-tab-card">
                                <div class="strategies-card-head">
                                    <h4><span>Live</span> Put the bunny back....</h4>
                                    <div class="strategies-card-ico">
                                        <a href="#"><img src="assets/images/custom-image/strategies-star.svg" alt=""></a>
                                        <a href="#"><img src="assets/images/custom-image/strategies-share.svg" alt=""></a>
                                    </div>
                                </div>
                                <div class="strategies-card-name">
                                    <h5><span>B</span>Binomial Rough</h5>
                                    <h6>ROI Over all time : <span>+646.57%</span></h6>
                                </div>
                                <div class="strategies-card-value">
                                    <h4>M : 0.00%</h4>
                                    <h4>V : $0</h4>
                                    <h4>P : 15.00%</h4>
                                    <h4>Min inv : $ 1000.00</h4>
                                </div>
                                <div class="strategies-card-chart">
                                    <div id="line-chart"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="strategies-tab-card">
                                <div class="strategies-card-head">
                                    <h4><span>Live</span> Put the bunny back....</h4>
                                    <div class="strategies-card-ico">
                                        <a href="#"><img src="assets/images/custom-image/strategies-star.svg" alt=""></a>
                                        <a href="#"><img src="assets/images/custom-image/strategies-share.svg" alt=""></a>
                                    </div>
                                </div>
                                <div class="strategies-card-name">
                                    <h5><span>B</span>Binomial Rough</h5>
                                    <h6>ROI Over all time : <span>+646.57%</span></h6>
                                </div>
                                <div class="strategies-card-value">
                                    <h4>M : 0.00%</h4>
                                    <h4>V : $0</h4>
                                    <h4>P : 15.00%</h4>
                                    <h4>Min inv : $ 1000.00</h4>
                                </div>
                                <div class="strategies-card-chart">
                                    <div id="line-chart"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="strategies-tab-card">
                                <div class="strategies-card-head">
                                    <h4><span>Live</span> Put the bunny back....</h4>
                                    <div class="strategies-card-ico">
                                        <a href="#"><img src="assets/images/custom-image/strategies-star.svg" alt=""></a>
                                        <a href="#"><img src="assets/images/custom-image/strategies-share.svg" alt=""></a>
                                    </div>
                                </div>
                                <div class="strategies-card-name">
                                    <h5><span>B</span>Binomial Rough</h5>
                                    <h6>ROI Over all time : <span>+646.57%</span></h6>
                                </div>
                                <div class="strategies-card-value">
                                    <h4>M : 0.00%</h4>
                                    <h4>V : $0</h4>
                                    <h4>P : 15.00%</h4>
                                    <h4>Min inv : $ 1000.00</h4>
                                </div>
                                <div class="strategies-card-chart">
                                    <div id="line-chart"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="strategies-tab-card">
                                <div class="strategies-card-head">
                                    <h4><span>Live</span> Put the bunny back....</h4>
                                    <div class="strategies-card-ico">
                                        <a href="#"><img src="assets/images/custom-image/strategies-star.svg" alt=""></a>
                                        <a href="#"><img src="assets/images/custom-image/strategies-share.svg" alt=""></a>
                                    </div>
                                </div>
                                <div class="strategies-card-name">
                                    <h5><span>B</span>Binomial Rough</h5>
                                    <h6>ROI Over all time : <span>+646.57%</span></h6>
                                </div>
                                <div class="strategies-card-value">
                                    <h4>M : 0.00%</h4>
                                    <h4>V : $0</h4>
                                    <h4>P : 15.00%</h4>
                                    <h4>Min inv : $ 1000.00</h4>
                                </div>
                                <div class="strategies-card-chart">
                                    <div id="line-chart"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="strategies-tab-card">
                                <div class="strategies-card-head">
                                    <h4><span>Live</span> Put the bunny back....</h4>
                                    <div class="strategies-card-ico">
                                        <a href="#"><img src="assets/images/custom-image/strategies-star.svg" alt=""></a>
                                        <a href="#"><img src="assets/images/custom-image/strategies-share.svg" alt=""></a>
                                    </div>
                                </div>
                                <div class="strategies-card-name">
                                    <h5><span>B</span>Binomial Rough</h5>
                                    <h6>ROI Over all time : <span>+646.57%</span></h6>
                                </div>
                                <div class="strategies-card-value">
                                    <h4>M : 0.00%</h4>
                                    <h4>V : $0</h4>
                                    <h4>P : 15.00%</h4>
                                    <h4>Min inv : $ 1000.00</h4>
                                </div>
                                <div class="strategies-card-chart">
                                    <div id="line-chart"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="strategies-tab-card">
                                <div class="strategies-card-head">
                                    <h4><span>Live</span> Put the bunny back....</h4>
                                    <div class="strategies-card-ico">
                                        <a href="#"><img src="assets/images/custom-image/strategies-star.svg" alt=""></a>
                                        <a href="#"><img src="assets/images/custom-image/strategies-share.svg" alt=""></a>
                                    </div>
                                </div>
                                <div class="strategies-card-name">
                                    <h5><span>B</span>Binomial Rough</h5>
                                    <h6>ROI Over all time : <span>+646.57%</span></h6>
                                </div>
                                <div class="strategies-card-value">
                                    <h4>M : 0.00%</h4>
                                    <h4>V : $0</h4>
                                    <h4>P : 15.00%</h4>
                                    <h4>Min inv : $ 1000.00</h4>
                                </div>
                                <div class="strategies-card-chart">
                                    <div id="line-chart"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="warning-pills-profile" role="tabpanel">
                tab2
            </div>
        </div>
    </div>
</main>
@endsection
@push('js')
<script>

</script>

@endpush
