@extends('layouts.main')

@section('content')

<main class="page-content">
    <div class="health-deta">
		<div class="liquid-basket">
            <div class="investment-head">
                <h4>My Activities</h4>
            </div>
            <div class="row">
                <div class="col-xxl-3 col-md-4 col-sm-6">
                    <div class="liquid-basket-card">
                        <div class="health-img">
                            <img src="{{url('front/images/custom-image/health1.png') }}" alt="">
                        </div>
                        <div class="health-text">
                            <h6>75</h6>
                            <h5>BPM</h5>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-3 col-md-4 col-sm-6">
                    <div class="liquid-basket-card">
                        <div class="health-img">
                            <img src="{{url('front/images/custom-image/health2.png') }}" alt="">
                        </div>
                        <div class="health-text">
                            <h6>3.5</h6>
                            <h5>Miles</h5>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-3 col-md-4 col-sm-6">
                    <div class="liquid-basket-card">
                        <div class="health-img">
                            <img src="{{url('front/images/custom-image/health3.png') }}" alt="">
                        </div>
                        <div class="health-text">
                            <h6>120/80</h6>
                            <h5>Blood Pressure</h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="main-btn">
				<a href="javascript:void(0)" class="comm-btn">comming Soon</a>
			</div>
        </div>
    </div>
</main>

@endsection
@push('js')

@endpush	