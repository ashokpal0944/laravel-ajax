<div class="modal fade" id="view_investment_return" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Return Of Interest List</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
            <div class="modal-body">
				<div class="liquid-basket">
					<div class="row mb-3">
						<div class="col-md-6 col-sm-8">
							<div class="liquid-basket-card">
								<div class="liquid-basket-head">
									<h4>Total Return Of Interest :- {{ number_format($get_user_interests->total_recived_amount,2)}}</h4>
								</div>
								<div class="liquid-basket-head">
									<h4>Total Income :- {{ number_format($get_user_interests->total_payable_amount,2)}}</h4>
								</div>
								<div class="liquid-basket-head">
									<h4>Total Pending Balance :- {{ number_format(round($get_user_interests->total_recived_amount - $get_user_interests->total_payable_amount),2)}}</h4>
								</div>
								<div class="liquid-basket-head">
									<h4>Estimated Time :- {{ $get_user_interests->estimated_time }}</h4>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="table-responsive">
					<table id="main_data_table" class="table" style="width:100%">
						<thead>
							<tr>
								<th>Id</th>
								<th>Interest(%)</th>
								<th>Interest Amount</th>
								<th>Create Data</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							@foreach($get_user_return_of_interests as $key=>$value)
							<tr>
								<td>{{ $key + 1 }}</td>
								<td>{{ number_format($value->total_return_of_interest,2) }}</td>
								<td>{{ $value->total_payable_amount}}</td>
								<td>{{ $value->created_at}}</td>
								<td>
									@if($value->is_status == 1)
									<span class="badge badge-success badge-pill">Approved</span>
									@else
									<span class="badge badge-warning badge-pill">Pending</span>
									@endif
									</td>
								</tr>
								@endforeach
							</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<script>
		var DataTable = $('#main_data_table').DataTable({});
	</script>
</div>