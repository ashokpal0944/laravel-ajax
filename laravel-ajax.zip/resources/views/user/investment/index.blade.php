@extends('layouts.main')

@section('content')
<main class="page-content">
    <div class="investment-page-main">
        <div class="row">
            <div class="col-xxl-9">
                <div class="investment-head">
                    <h4>Learn about Liquide baskets</h4>
				</div>
				<?php
					// Decode JSON settings into arrays
					$investment_banner_first = [];
					if (config('setting.investment_banner_first')) {
						$investment_banner_first = json_decode(config('setting.investment_banner_first'), true); // Ensure array return
					}
					
					$investment_banner_second = [];
					if (config('setting.investment_banner_second')) {
						$investment_banner_second = json_decode(config('setting.investment_banner_second'), true); // Ensure array return
					}
				?>
				<div class="investment-card-main">
					<div class="row">
						@foreach($investment_banner_first as $investment_banner)
						<div class="col-md-4 col-6">
							<div class="investment-card">
								<img src="{{ url('storage/' . $investment_banner) }}" alt="Investment Banner First">
							</div>
						</div>
						@endforeach
						
						@foreach($investment_banner_second as $investment_s_banner)
						<div class="col-xl-8">
							<div class="investment-liquid-img">
								<img src="{{ url('storage/' . $investment_s_banner) }}" alt="Investment Banner Second">
							</div>
						</div>
						@endforeach
					</div>
				</div>
				@foreach($get_ai_bots_array as $key => $get_ai_bot)
                <div class="liquid-basket">
                    <div class="investment-head">
                        <h4>{{ $get_ai_bot['currency_type']}}</h4>
					</div>
                    <div class="row">
						@foreach($get_ai_bot['all_currency_data'] as $sub_key => $all_ai_currency_data)
						
						@php
						$detaClass = 'low-deta'; // Default class
						$textColor = 'text-green'; // Default color
						
						if ($all_ai_currency_data->risk_type == "High") {
						$detaClass = 'low-deta'; // Use the default class
						$textColor = 'text-green';
						} elseif ($all_ai_currency_data->risk_type == "Low") {
						$detaClass = 'low-deta low-deta-row';
						$textColor = 'text-red';
						} else {
						$detaClass = 'low-deta low-deta-yellow';
						$textColor = 'text-green';
						}
						@endphp
                        <div class="col-md-4 col-sm-6">
                            <div class="liquid-basket-card">
                                <div class="liquid-basket-head">
                                    <h4><span><img src="{{ url('public/storage/'.$all_ai_currency_data->icon) }}" alt=""></span> {{ $all_ai_currency_data->title }}</h4>
                                    <!--<h6>Free</h6>-->
								</div>
                                <div class="liquid-basket-text">
                                    <h5>Min Amount <br><span>₹ {{ $all_ai_currency_data->min_amount }}</span></h5>
                                    <h5>1 y return <br><span class="text-green">{{ $all_ai_currency_data->yearly_return }} %</span></h5>
									
									<h5 class="{{ $detaClass }}">Validity <br>
										<span class="{{ $textColor }}">
											<img class="in-svg" src="{{ url('front/images/custom-image/speedometer.svg') }}" alt=""> 
											{{ $all_ai_currency_data->risk_type }}
										</span>
									</h5>
								</div>
                                <div class="liquid-basket-footer">
                                    <a href="{{ url('view-ai-boat', $get_ai_bot['currency_type']) }}?risk_type={{ urlencode($all_ai_currency_data->risk_type) }}"><?php //echo substr($all_ai_currency_data->description, 0, 50)?> Evergreen Solution for all market conditions <span><img src="{{ url('front/images/custom-image/arrow.svg') }}" alt=""></span></a>
								</div>
							</div>
						</div>
						@endforeach
					</div>
				</div>
				@endforeach
				<hr>
				<div class="liquid-basket">
                    <div class="investment-head">
                        <h4>User Investment </h4>
					</div>
                    <div class="row">
						@foreach($get_user_investments as $key=>$get_user_investment)
                        <div class="col-md-4 col-sm-6">
                            <div class="liquid-basket-card">
                                <div class="liquid-basket-head">
                                    <h4># {{ $key +1 }} </h4>
									
									<a href="{{ url('get-return-of-interest',$get_user_investment->id) }}" onclick="viewInvestmentReturnInterest(this,event)">
										<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
									</a>
									
								</div>
								<h4>Investment Plan Name : {{ $get_user_investment->investmentPlan->plan_name }}</h4>
                                <div class="liquid-basket-text">
                                    <h5><b>Investment Amount :</b>  <span>{{ $get_user_investment->investment_amount }}</span></h5><br>
                                    <h5><b>Investment Date :</b>  <span>{{ $get_user_investment->created_at }}</span></h5><br>
								</div>
								<div class="card-body">
									<div class="card-title">
										<h4>Return Of Interest Progressbar</h4>
									</div>
									<?php
									$total_return_of_interest = $get_user_investment->return_interest_sum_total_return_of_interest;
									
									if(empty($total_return_of_interest))
									{
										$total_return_of_interest = 0;
									}
									?>
									<div class="progress">
										<div class="progress-bar" role="progressbar" style="width: {{ $total_return_of_interest}}%;" aria-valuenow="{{ $total_return_of_interest}}" aria-valuemin="0" aria-valuemax="{{ $get_user_investment->return_on_investment}}">{{ $total_return_of_interest}}%</div>
									</div>
								</div>
								<?php
									if($get_user_investment->return_interest_sum_total_return_of_interest == $get_user_investment->return_on_investment)
									{
										$estimated_return = "0.00";
									}
									else
									{
										$estimated_return =  rand(2, 7);
									}
								?>
								<div class="liquid-basket-text">
                                    <h5><b>Estimated Return (This Month):</b>  <span>{{ $estimated_return }} %</span></h5><br>
                                    <h5><b>Previous Month Return :</b>  <span>@if(count($get_user_investment->returnInterest) > 0){{ number_format($get_user_investment->returnInterest[0]->total_return_of_interest,2)}} @else 0.0 @endif% </span></h5><br>
								</div>
							</div>
						</div>
						@endforeach
					</div>
				</div>
				@if($total_user_investment == 0)
				<div class="main-btn mb-3">
					<a href="{{ url('investment-price') }}" class="comm-btn m-auto" >Invest Now</a>
				</div>
				@endif
				
                <div class="tree-img">
                    <img src="{{ url('front/images/custom-image/tree.png') }}" alt="">
				</div>
				
				
			</div>
		</div>
	</div>
</main>
@endsection
@push('js')
<script>
	function viewInvestmentReturnInterest(obj,event)
	{  
		event.preventDefault(); 
		if (!modalOpen)
		{
			modalOpen = true;
			closemodal();
			$.get(obj, function(res)
			{
				$('body').find('#modal-view-render').html(res.view); 
				$('#view_investment_return').modal('show');  
			}); 
		}
	}
</script>
@endpush
