@extends('layouts.main')

@section('content')

<main class="page-content">
    <div class="basket-deta">
        <div class="row">
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket1.png') }}" alt="">
                    <h6>Fashion</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket2.png') }}" alt="">
                    <h6>Foods</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket3.png') }}" alt="">
                    <h6>Travels</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket4.png') }}" alt="">
                    <h6>Electronics</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket5.png') }}" alt="">
                    <h6>Entertainment</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket6.png') }}" alt="">
                    <h6>Recharge & Subscription</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket7.png') }}" alt="">
                    <h6>Credit Card Payments</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket8.png') }}" alt="">
                    <h6>Gift Card</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket12.png') }}" alt="">
                    <h6>Donation</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket9.png') }}" alt="">
                    <h6>Devotion</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket10.png') }}" alt="">
                    <h6>Jewelry</h6>
                </div>
            </div>
            <div class="col-xxl-2 col-md-3 col-sm-4">
                <div class="basket-card">
                    <img src="{{url('front/images/custom-image/basket11.png') }}" alt="">
                    <h6>Kids</h6>
                </div>
            </div>
        </div>
         <div class="main-btn">
				<a href="javascript:void(0)" class="comm-btn">comming Soon</a>
			</div>
    </div>
</main>

@endsection
@push('js')

@endpush