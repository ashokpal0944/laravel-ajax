@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="course-view-main">
        <div class="course-view-card">
            <h4>
				@if($course_type == "Rehab")
				<span>Rehab</span> Course
				@else
				@php
				$course_title = explode(' ', $get_data->title, 2);
				@endphp
				
				<span>{{ $course_title[0] }}</span>
				@isset($course_title[1])
				{{ $course_title[1] }}
				@endisset
				@endif
			</h4>
            <?php
				echo $get_data->description;
			?>
			
			@php
			$duration = $get_data->duration; 
			
			// Get the current date
			$startDate = \Carbon\Carbon::now();
			
			// Calculate the end date based on the duration
			$endDate = $startDate->copy()->add($duration);
			@endphp
			
            <div class="course-card-footer">
                <div class="course-footer-deta">
                    <img src="{{ url('front/images/custom-image/date.png') }}" alt="">
                    <div class="course-footer-text">
                        <h6>End on {{ $endDate->format('M d') }}</h6>
                        <p>{{ $startDate->format('M d') }} - {{ $endDate->format('M d') }}<br>{{ $endDate->format('Y') }}</p>
					</div>
				</div>
                <div class="course-footer-deta">
                    <img src="{{ url('front/images/custom-image/play.png') }}" alt="">
                    <div class="course-footer-text">
                        <h6>28</h6>
                        <p>Lessons</p>
					</div>
				</div>
			</div>
			<form id="purchaseEducationCourse" action="{{ url('purchase-education-course')}}" method="post">
				@csrf
				<input type="hidden" name="course_id" value="{{ $get_data->id }}">	
				<input type="hidden" name="course_type" value="{{ $course_type }}">	
				<input type="hidden" name="course_price" id="course_price" value="{{ $get_data->package_price }}">	
				<input type="hidden" name="start_date" id="start_date" value="{{ $startDate->format('Y-m-d') }}">	
				<input type="hidden" name="expire_date" id="expire_date" value="{{ $endDate->format('Y-m-d') }}">	
				<div class="main-btn">
					<button type="submit" class="comm-btn">Purchase now</button>
				</div>
			</form>
		</div>
	</div>
</main>
@endsection
@push('js')
<script>
    $(document).ready(function() {
        $('#purchaseEducationCourse').on('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
            
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to purchase this course!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, purchase it!"
				}).then((result) => {
				
				//console.log('Swal result:', result); // Check the entire result object
                if (result.value) {
                    
                    var $form = $(this);
                    var $submitButton = $form.find('button');
                    var $spinButton = $form.find('button.spin-button');
					
                    // Disable the submit button and show the loading spinner
                    $submitButton.prop('disabled', true);
                    $spinButton.addClass('loading').html('<span class="spinner"></span>');
					
                    // Serialize form data
                    var formData = $form.serialize();
					
                    $.ajax({
                        type: $form.attr('method'),
                        url: $form.attr('action'),
                        data: formData,
                        success: function(res) {
                            // Re-enable the submit button and remove the loading spinner
                            $submitButton.prop('disabled', false);
							$spinButton.removeClass('loading').html('Purchase now');
						   
                            if (res.status === "error") 
							{
                                Swal.fire("Error!", res.msg, "error");
							} 
							else 
							{
								toastrMsg(res.status, res.msg);
								
								setTimeout(function() {
									location.href = "{{ url('purchase-history') }}"; 
								}, 2000);
							}
						},
                        error: function(err) 
						{
                            // Re-enable the submit button and remove the loading spinner
                            $submitButton.prop('disabled', false);
                            $spinButton.removeClass('loading').html('Purchase now');
							
                            // Display an error message
                            Swal.fire("Error!", "An error occurred. Please try again.", "error");
                            console.error('AJAX error:', err);
						}
					});
				}
			});
		});
	});
</script>

@endpush
