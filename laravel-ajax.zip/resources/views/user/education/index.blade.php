@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="educations-main">
        <div class="educations-card">
            <div class="educations-img">
                <img src="{{ url('front/images/custom-image/educations-img.png') }}" alt="">
            </div>
            <div class="educations-deta">
                <h3>Educations</h3>
                <div class="row">
                    <div class="col-md-4 col-6">
                        <a href="{{ url('education/trading') }}">
                            <div class="wallet-page-box">
                                <img src="{{ url('front/images/custom-image/wallet-card-ico1.png') }}" alt="">
                                <h4>Trading</h4>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 col-6">
                        <a href="{{ url('education/rehab') }}">
                            <div class="wallet-page-box wallet-color2">
                                <img src="{{ url('front/images/custom-image/wallet-card-ico2.png') }}" alt="">
                                <h4>Rehab</h4>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 col-6">
                        <a href="{{ url('education/business') }}">
                            <div class="wallet-page-box wallet-color3">
                                <img src="{{ url('front/images/custom-image/wallet-card-ico3.png') }}" alt="">
                                <h4>Business</h4>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection
