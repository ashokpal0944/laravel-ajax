@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="course-deta-main">
        <div class="row">
			@foreach($get_business as $get_busines)
            <div class="col-xxl-3 col-lg-5 col-sm-6">
                <a href="{{ url('education/business/course', $get_busines->id)}}">
                    <div class="course-card business-card">
						@php
							$course_title = explode(' ', $get_busines->title, 2);
							$business_titles = explode(',', $get_busines->business_title);
						@endphp
                        <h4>
							<span>{{ $course_title[0] }}</span>
							@isset($course_title[1])
								{{ $course_title[1] }}
							@endisset
						</h4>
                        <img src="{{ url('public/storage/'.$get_busines->image) }}" alt="">
						<h5>{{ $get_busines->duration }}</h5>
						
                        <div class="buiness-dev-deta text-start">
                            <ul>
								@foreach($business_titles as $key=>$value)
									<li>{{ $value }}</li>
                                @endforeach
                            </ul>
                        </div>
                        <h6>Just At ₹ {{ number_format($get_busines->package_price, 2) }}/-</h6>
                    </div>
                </a>
            </div>
			@endforeach
        </div>
    </div>
</main>
@endsection
