@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="course-deta-main">
        <div class="row">
			@foreach($get_tradings as $get_trading)
				<div class="col-xxl-3 col-md-4 col-sm-6">
					<a href="{{ url('education/trading/course', $get_trading->id)}}">
						<div class="course-card">
							@php
								$course_title = explode(' ', $get_trading->title, 2);
							@endphp
							<h4>
								<span>{{ $course_title[0] }}</span>
								@isset($course_title[1])
									{{ $course_title[1] }}
								@endisset
							</h4>
							<img src="{{ url('public/storage/'.$get_trading->image) }}" alt="">
							<h5>{{ $get_trading->duration }}</h5>
							<h6>₹ {{ number_format($get_trading->package_price, 2) }} /-</h6>
						</div>
					</a>
				</div>
			@endforeach
		</div>
	</div>
</main>
@endsection
