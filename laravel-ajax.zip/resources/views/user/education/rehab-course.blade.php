@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="course-deta-main">
        <div class="row">
			@foreach($get_rehabs as $get_rehab)
            <div class="col-xxl-4 col-xl-5 col-md-6">
                <a href="{{ url('education/rehab/course', $get_rehab->id)}}">
                    <div class="course-card business-card rehub-card">
                        <div class="rehub-course-head">
                            <img src="{{ url('public/storage/'.$get_rehab->image) }}" alt="">
							@php
								$courses_lists = explode(',', $get_rehab->courses);
							@endphp
						
                            <div class="rehub-deta">
								@foreach($courses_lists as $index => $value)
									<h5 class="{{ $index % 2 == 0 ? 'rehub-high' : '' }}">{{ $value }}</h5>
								@endforeach
                            </div>
                        </div>
                        <h5>{{ $get_rehab->duration }}</h5>
                        <h6>Just At ₹ {{ number_format($get_rehab->package_price, 2) }}/-</h6>
                    </div>
                </a>
            </div>
			@endforeach
        </div>
    </div>
</main>
@endsection
