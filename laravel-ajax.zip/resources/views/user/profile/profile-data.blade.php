@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="profile-personal-deta">
		<form id="updateProfile" method="post" action="{{ url('update-profile') }}">
			@csrf
			<div class="row">
				<div class="col-sm-6">
					<div class="form-group">
						<label for="" class="label-main">Full Name <span class="text-danger">*</span></label>
						<input type="text" class="input-main" name="name" id="name" placeholder="Full Name" value="{{ $authUser->name }}">
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label for="username" class="label-main">User Name <span class="text-danger">*</span></label>
						<input type="text" class="input-main" name="username" id="username" placeholder="User Name" value="{{ $authUser->username }}" disabled>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label for="email" class="label-main">Email Address <span class="text-danger">*</span></label>
						<input type="email" class="input-main" name="email" id="email" placeholder="User Name" value="{{ $authUser->email }}" disabled>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label for="phone_number" class="label-main">Phone Number <span class="text-danger">*</span></label>
						<input type="text" class="input-main" name="phone_number" id="phone_number" placeholder="Enter Phone Number" maxlength="10" value="{{ $authUser->phone_number }}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
					</div>
				</div>
				<div class="col-sm-6">
					<div class="row">
						<div class="col-4">
							<div class="form-group">
								<label for="" class="label-main">Country</label>
								<select class="form-control select2" name="country_id" id="country_id" onchange="getStateData()">
									<option value="">Select Country</option>
									@foreach($get_country as $get_countr)
									<option value="{{ $get_countr->id }}" {{ $get_countr->id == $authUser->country_id ? "selected" : '' }}>{{ $get_countr->name }}</option>
									@endforeach
								</select>
							</div>
						</div>
						<div class="col-4">
							<div class="form-group">
								<label for="" class="label-main">State</label>
								<select class="form-control select2" name="state_id" id="state_id" onchange="getCityData()">
									<option value="">Select State</option>
									@foreach($get_states as $get_state)
									<option value="{{ $get_state->id }}" {{ $get_state->id == $authUser->state_id ? "selected" : '' }}>{{ $get_state->name }}</option>
									@endforeach
								</select>
							</div>
						</div>
						<div class="col-4">
							<div class="form-group">
								<label for="" class="label-main">City</label>
								<select class="form-control select2" name="city_id" id="city_id">
									<option value="">Select City</option>
									@foreach($get_citys as $get_city)
									<option value="{{ $get_city->id }}" {{ $get_city->id == $authUser->city_id ? "selected" : '' }}>{{ $get_city->name }}</option>
									@endforeach
								</select>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label for="" class="label-main">Occupations</label>
						<select class="form-control select2" name="occupation" id="occupation">
							<option value="">Select Occupation</option>
							<option value="Software Engineer" {{ $authUser->occupation == "Software Engineer" ? "selected" : '' }}>Software Engineer</option>
							<option value="Doctor" {{ $authUser->occupation == "Doctor" ? "selected" : '' }}>Doctor</option>
							<option value="Teacher" {{ $authUser->occupation == "Teacher" ? "selected" : '' }}>Teacher</option>
							<option value="Accountant" {{ $authUser->occupation == "Accountant" ? "selected" : '' }}>Accountant</option>
							<option value="Civil Engineer" {{ $authUser->occupation == "Civil Engineer" ? "selected" : '' }}>Civil Engineer</option>
							<option value="Nurse" {{ $authUser->occupation == "Nurse" ? "selected" : '' }}>Nurse</option>
							<option value="Lawyer" {{ $authUser->occupation == "Lawyer" ? "selected" : '' }}>Lawyer</option>
							<option value="Pharmacist" {{ $authUser->occupation == "Pharmacist" ? "selected" : '' }}>Pharmacist</option>
							<option value="Graphic Designer" {{ $authUser->occupation == "Graphic Designer" ? "selected" : '' }}>Graphic Designer</option>
							<option value="Architect" {{ $authUser->occupation == "Architect" ? "selected" : '' }}>Architect</option>
							<option value="Sales Manager" {{ $authUser->occupation == "Sales Manager" ? "selected" : '' }}>Sales Manager</option>
							<option value="Electrician" {{ $authUser->occupation == "Electrician" ? "selected" : '' }}>Electrician</option>
							<option value="Plumber" {{ $authUser->occupation == "Plumber" ? "selected" : '' }}>Plumber</option>
							<option value="Chef" {{ $authUser->occupation == "Chef" ? "selected" : '' }}>Chef</option>
							<option value="Marketing Manager" {{ $authUser->occupation == "Marketing Manager" ? "selected" : '' }}>Marketing Manager</option>
						</select>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label for="profile" class="label-main">Profile<span class="text-danger">*</span></label>
						<input type="file" class="input-main" name="profile" id="profile">
					</div>
				</div>
				@if($authUser->profile)
				<div class="col-sm-6">
					<div class="form-group">
						<image src="{{ url('storage/' . $authUser->profile) }}" class="user-img" width="100">
					</div>
				</div>
				@endif
				<div class="col-12">
					<button type="submit" class="comm-btn action-btn spin-btn">Save</button>
				</div>
			</div>
		</form>
	</div>
</main>
@endsection
@push('js')
<script>
	$('#updateProfile').submit(function(event) {
		event.preventDefault();
		
		var $form = $(this);
		var $submitButton = $form.find('button');
		var $spinButton = $form.find('button.spin-btn');
		
		$submitButton.prop('disabled', true);
		$spinButton.addClass('loading');
		
		var formData = new FormData(this);
		formData.append('_token', "{{ csrf_token() }}");
		
		$.ajax({
			async: true,
			type: $form.attr('method'),
			url: $form.attr('action'),
			data: formData,
			cache: false,
			processData: false,
			contentType: false,
			dataType: 'Json',
			success: function(res) {
				$submitButton.prop('disabled', false);
				$spinButton.removeClass('loading');
				
				if (res.status === "error") {
					toastrMsg(res.status, res.msg);
					} else if (res.status === "validation") {
					$('.error').remove(); // Clear previous error messages
					
					$.each(res.errors, function(key, value) {
						var inputField = $('#' + key);
						var errorSpan = $('<span>')
						.addClass('error text-danger')
						.attr('id', key + 'Error')
						.text(value[0]);
						inputField.parent().append(errorSpan);
					});
					} else {
					toastrMsg(res.status, res.msg);
					$('body').css({'overflow': 'auto'});
					$('.error').remove();
					
					setTimeout(function() {
						location.reload(); 
					}, 3000);
				}
			}
		});
	});
</script>
@endpush