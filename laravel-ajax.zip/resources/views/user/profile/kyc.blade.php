@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
	<div class="kyc-step-main">
		<h2>KYC</h2>
		<div id="smartwizard">
			<ul class="nav">
				<li class="nav-item">
					<a class="nav-link" href="#step-1"> <strong>Photo</strong></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#step-2"> <strong>Aadhaar Card</strong></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#step-3"> <strong>Pan Card</strong></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#step-4"> <strong>Bank Details</strong></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#step-5"> <strong>Crypto Credentials</strong></a>
				</li>
				<li class="nav-item d-none">
					<a class="nav-link" href="#step-6"> <strong></strong></a>
				</li>
			</ul>
			<div class="kyc-line">
				<img src="{{ url('front/images/custom-image/kyc-line.png') }}" alt="">
			</div>
			<div class="tab-content">
				<div id="step-1" class="tab-pane" role="tabpanel" aria-labelledby="step-1">
					<div class="kyc-box-main">
						<h4>Photo</h4>
						<p>Please Upload Your Photo</p>
						<form id="updateProfileImage" method="post" action="{{ url('update-profile-image') }}">
							@csrf
							<div class="upload-box">
								<h5>Upload your Photo</h5>
								<label> Upload <span>+</span>
									<input type="file" name="profile" id="profile" accept="image/*">
								</label>
								<div class="upload-image-show">
									<img id="imagePreview" src="{{ url('public/storage/'. $authUser->profile) }}" alt="Image Preview" style="display: {{ $authUser->profile != '' ? 'block' : 'none' }};">
								</div>
							</div>
							@php
							$minDate = \Carbon\Carbon::now()->subYears(18)->format('Y-m-d');
							@endphp
							<div class="upload-birth">
								<label for="" class="label-main">Date of Birth</label>
								<input type="date" name="dob" id="dob" value="{{ $authUser->dob }}" max="{{ $minDate }}">
							</div>
							<div class="sub-btn">
								<button type="submit">Submit</button>
							</div>
						</form>
						<div class="upload-footer">
							<p>If you're experiencing any issues or need to update your KYC, please email us.<br><a href="mailto:clarus-ventures@gmail.com"><span>clarus-ventures@gmail.com</span></a></p>
						</div>
					</div>
				</div>
				<div id="step-2" class="tab-pane" role="tabpanel" aria-labelledby="step-2">
					<div class="kyc-box-main">
						@if(isset($get_user_kyc) && $get_user_kyc->is_aadhaar == 1)
						<div class="reject-deta approve-deta">
							<h6><span><i class="fadeIn animated bx bx-badge-check"></i></span> Approve</h6>
						</div>
						@endif
						
						@if(isset($get_user_kyc) && $get_user_kyc->is_aadhaar == 2)
						<div class="reject-deta">
							<h6><span><i class="fadeIn animated bx bx-error"></i></span> Rejected</h6>
							<p>{{ $get_user_kyc->aadhaar_note}}</p>
						</div>
						@endif
						<h4>Aadhaar Card</h4>
						<p>Please upload your Aadhar card below for completing your first step of KYC.</p>
						<form id="updateAadharcard" method="post" action="{{ url('update-user-kyc') }}">
							@csrf
							
							<div class="upload-box">
								<h5>Upload aadhaar card front photo </h5>
								<label> Upload <span>+</span>
									<input type="file" id="aadhaar_front" name="aadhaar_front" accept="image/*" {{ isset($get_user_kyc) && $get_user_kyc->is_aadhaar == 1 ? 'disabled' : '' }} >
								</label>
								<div class="upload-image-show">
									<img id="imagePreview2" src="{{ $get_user_kyc && $get_user_kyc->aadhaar_front ? url('public/storage/' . $get_user_kyc->aadhaar_front) : '' }}"
									alt="Image Preview" style="display: {{ $get_user_kyc && $get_user_kyc->aadhaar_front ? 'block' : 'none' }};">
								</div>
							</div>
							<div class="upload-box">
								<h5>Upload aadhaar card Back photo </h5>
								<label> Upload <span>+</span>
									<input type="file" name="aadhaar_back" id="aadhaar_back" accept="image/*" {{ isset($get_user_kyc) && $get_user_kyc->is_aadhaar == 1 ? 'disabled' : '' }}>
								</label>
								<div class="upload-image-show">
									<img id="imagePreview3" src="{{ $get_user_kyc && $get_user_kyc->aadhaar_back ? url('public/storage/' . $get_user_kyc->aadhaar_back) : '' }}"
									alt="Image Preview" style="display: {{ $get_user_kyc && $get_user_kyc->aadhaar_back ? 'block' : 'none' }};">
								</div>
							</div>
							<div class="upload-birth">
								<label for="" class="label-main">Aadhar Card Number</label>
								<input type="text" name="aadhaar_number" id="aadhaar_number" value="{{ $get_user_kyc ? $get_user_kyc->aadhaar_number : '' }}" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="12" {{ isset($get_user_kyc) && $get_user_kyc->is_aadhaar == 1 ? 'disabled' : '' }} >
							</div>
							<div class="sub-btn">
								@if(empty($get_user_kyc) || $get_user_kyc->is_aadhaar != 1)
									<button type="submit">Submit</button>
								@endif
							</div>
						</form>
						<div class="upload-footer">
							<p>If you're experiencing any issues or need to update your KYC, please email us.<br><a href="mailto:clarus-ventures@gmail.com"><span>clarus-ventures@gmail.com</span></a></p>
						</div>
					</div>
				</div>
				<div id="step-3" class="tab-pane" role="tabpanel" aria-labelledby="step-4">
					<div class="kyc-box-main">
						@if(isset($get_user_kyc) && $get_user_kyc->is_pancard == 1)
						<div class="reject-deta approve-deta">
							<h6><span><i class="fadeIn animated bx bx-badge-check"></i></span> Approve</h6>
						</div>
						@endif
						
						@if(isset($get_user_kyc) && $get_user_kyc->is_pancard == 2)
						<div class="reject-deta">
							<h6><span><i class="fadeIn animated bx bx-error"></i></span> Rejected</h6>
							<p>{{ $get_user_kyc->pancard_note}}</p>
						</div>
						@endif
						<h4>Pan Card</h4>
						<p>Please upload your Pan card below for completing your first step of KYC.</p>
						<form id="updatePanCard" method="post" action="{{ url('update-user-kyc') }}">
							@csrf
							<div class="upload-box">
								<h5>Upload your Pan card Photo</h5>
								<label> Upload <span>+</span>
									<input type="file" id="pancard_image" name="pancard_image" accept="image/*" {{ isset($get_user_kyc) && $get_user_kyc->is_pancard == 1 ? 'disabled' : '' }}>
								</label>
								<div class="upload-image-show">
									<img id="imagePreview4" src="{{ $get_user_kyc && $get_user_kyc->pancard_image ? url('public/storage/' . $get_user_kyc->pancard_image) : '' }}"
									alt="Image Preview" style="display: {{ $get_user_kyc && $get_user_kyc->pancard_image ? 'block' : 'none' }};">
								</div>
							</div>
							<div class="upload-birth">
								<label for="pancard_number" class="label-main">Pan Card Number</label>
								<input type="text" name="pancard_number" id="pancard_number" value="{{ $get_user_kyc ? $get_user_kyc->pancard_number : '' }}" maxlength="10"  required {{ isset($get_user_kyc) && $get_user_kyc->is_pancard == 1 ? 'disabled' : '' }}>
							</div>
							<div class="sub-btn">
								@if(empty($get_user_kyc) || $get_user_kyc->is_pancard != 1)
									<button type="submit">Submit</button>
								@endif
							</div>
						</form>
						<div class="upload-footer">
							<p>If you're experiencing any issues or need to update your KYC, please email us.<br><a href="mailto:clarus-ventures@gmail.com"><span>clarus-ventures@gmail.com</span></a></p>
						</div>
					</div>
				</div>
				<div id="step-4" class="tab-pane" role="tabpanel" aria-labelledby="step-5">
					<div class="kyc-box-main">
						@if(isset($get_user_kyc) && $get_user_kyc->is_bank_account == 1)
						<div class="reject-deta approve-deta">
							<h6><span><i class="fadeIn animated bx bx-badge-check"></i></span> Approve</h6>
						</div>
						@endif
						
						@if(isset($get_user_kyc) && $get_user_kyc->is_bank_account == 2)
						<div class="reject-deta">
							<h6><span><i class="fadeIn animated bx bx-error"></i></span> Rejected</h6>
							<p>{{ $get_user_kyc->bank_account_note}}</p>
						</div>
						@endif
						<h4>Bank Details</h4>
						<p>Please upload your Bank Details below for completing your first step of KYC.</p>
						<form id="updateAccountDetails" method="post" action="{{ url('update-user-kyc') }}">
							@csrf
							<div class="bank-details-deta">
								<div class="row">
									<div class="col-md-4 col-sm-6">
										<label for="">Account number</label>
										<input type="text" name="account_number" id="account_number" value="{{ $get_user_kyc ? $get_user_kyc->account_number : '' }}" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" >
									</div>
									<div class="col-md-4 col-sm-6">
										<label for="">Re-Enter Account number</label>
										<input type="text" name="confirmation_account_number" id="confirmation_account_number" required oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ $get_user_kyc ? $get_user_kyc->account_number : '' }}"  >
									</div>
									<div class="col-md-4 col-sm-6">
										<label for="">Bank Name</label>
										<input type="text" name="bank_name" id="bank_name" value="{{ $get_user_kyc ? $get_user_kyc->bank_name : '' }}" required >
									</div>
									<div class="col-md-4 col-sm-6">
										<label for="">IFSC Code</label>
										<input type="text" name="ifsc_code" id="ifsc_code" value="{{ $get_user_kyc ? $get_user_kyc->ifsc_code : '' }}" required >
									</div>
									<div class="col-md-4 col-sm-6">
										<label for="">Account type</label>
										<select class="select2" name="account_type" id="account_type" >
											<option value="Current account" {{ $get_user_kyc && $get_user_kyc->account_type == "Current account" ? 'selected' : '' }}>Current account</option>
											<option value="Savings account" {{ $get_user_kyc && $get_user_kyc->account_type == "Savings account" ? 'selected' : '' }}>Savings account</option>
											<option value="Salary account" {{ $get_user_kyc && $get_user_kyc->account_type == "Salary account" ? 'selected' : '' }}>Salary account</option>
											<option value="Fixed deposit account" {{ $get_user_kyc && $get_user_kyc->account_type == "Fixed deposit account" ? 'selected' : '' }}>Fixed deposit account</option>
											<option value="Recurring deposit account" {{ $get_user_kyc && $get_user_kyc->account_type == "Recurring deposit account" ? 'selected' : '' }}>Recurring deposit account</option>
										</select>
									</div>
								</div>
							</div>
							<h4>OR</h4>
							<div class="bank-details-deta">
								<div class="row">
									<div class="col-md-4 col-sm-6">
										<label for="">UPI Address</label>
										<input type="text" name="upi_address" id="upi_address" value="{{ $get_user_kyc ? $get_user_kyc->upi_address : '' }}">
									</div>
								</div>
							</div>
							<div class="sub-btn mb-0">
								<button type="submit">Submit</button>
							</div>
						</form>
					</div>
					</div>
					<div id="step-5" class="tab-pane" role="tabpanel" aria-labelledby="step-6">
						<div class="kyc-box-main">
						<h4>Crypto Credentials</h4>
						<p>Please enter your bank account details with which you are <br> going to make payment for investment.</p>
						<form id="updateWalletKYC" method="post" action="{{ url('update-user-kyc') }}">
							@csrf
							<div class="crypto-tab">
								<div class="ai-tab-main">
									<ul class="nav nav-pills nav-pills-warning mb-3" role="tablist">
										<li class="nav-item" role="presentation">
											<a class="nav-link active" data-bs-toggle="pill" href="#warning-pills-home" role="tab" aria-selected="true">
												<div class="tab-title">Wallet</div>
											</a>
										</li>
										<li class="nav-item" role="presentation">
											<a class="nav-link" data-bs-toggle="pill" href="#warning-pills-profile" role="tab" aria-selected="false">
												<div class="tab-title">Exchange</div>
											</a>
										</li>
									</ul>
									<div class="tab-content">
										<div class="tab-pane fade show active" id="warning-pills-home" role="tabpanel">
											<div class="crypto-wallet">
												<div class="row">
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox1" />
														<label for="myCheckbox1">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/crypto-wallet-icon1.png') }}" alt="">
																<h5>TRUST WALLET</h5>
															</div>
														</label>
													</div>
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox2" />
														<label for="myCheckbox2">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/crypto-wallet-icon2.png') }}" alt="">
																<h5>METAMASK</h5>
															</div>
														</label>
													</div>
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox3" />
														<label for="myCheckbox3">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/crypto-wallet-icon3.png') }}" alt="">
																<h5>EKAUM</h5>
															</div>
														</label>
													</div>
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox4" />
														<label for="myCheckbox4">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/crypto-wallet-icon4.png') }}" alt="">
																<h5>PHANTOM</h5>
															</div>
														</label>
													</div>
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox5" />
														<label for="myCheckbox5">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/crypto-wallet-icon5.png') }}" alt="">
																<h5>1 INCH</h5>
															</div>
														</label>
													</div>
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox6" />
														<label for="myCheckbox6">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/crypto-wallet-icon6.png') }}" alt="">
																<h5>ELECTRUM</h5>
															</div>
														</label>
													</div>
												</div>
												<div class="bank-details-deta">
													<div class="row">
														<div class="col-md-6 col-sm-6">
															<label for="">Trust Wallet Address</label>
															<input type="text" id="trust_wallet" name="trust_wallet" value="{{ $get_user_kyc ? $get_user_kyc->trust_wallet : '' }}">
														</div>
														<div class="col-md-6 col-sm-6">
															<label for="">Metamask Wallet</label>
															<input type="text" id="metamask_wallet" name="metamask_wallet" value="{{ $get_user_kyc ? $get_user_kyc->metamask_wallet : '' }}">
														</div>
														
														<div class="col-md-6 col-sm-6">
															<label for="">Ekaum Wallet</label>
															<input type="text" id="ekaum_wallet" name="ekaum_wallet" value="{{ $get_user_kyc ? $get_user_kyc->ekaum_wallet : '' }}">
														</div>
														
														<div class="col-md-6 col-sm-6">
															<label for="">Phantom Wallet</label>
															<input type="text" id="phantom_wallet" name="phantom_wallet" value="{{ $get_user_kyc ? $get_user_kyc->phantom_wallet : '' }}">
														</div>
														
														<div class="col-md-6 col-sm-6">
															<label for="">1 INCH Wallet</label>
															<input type="text" id="one_inch_wallet" name="one_inch_wallet" value="{{ $get_user_kyc ? $get_user_kyc->one_inch_wallet : '' }}">
														</div>
														<div class="col-md-6 col-sm-6">
															<label for="">Electrum Wallet</label>
															<input type="text" id="electrum_wallet" name="electrum_wallet" value="{{ $get_user_kyc ? $get_user_kyc->electrum_wallet : '' }}">
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="tab-pane fade" id="warning-pills-profile" role="tabpanel">
											<div class="crypto-wallet">
												<div class="row justify-content-center">
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox7" />
														<label for="myCheckbox7">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/exchange-ico1.png') }}" alt="">
																<h5>BITCOIN</h5>
															</div>
														</label>
													</div>
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox8" />
														<label for="myCheckbox8">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/exchange-ico2.png') }}" alt="">
																<h5>ETHERIUM</h5>
															</div>
														</label>
													</div>
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox9" />
														<label for="myCheckbox9">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/exchange-ico3.png') }}" alt="">
																<h5>USDT</h5>
															</div>
														</label>
													</div>
													<div class="col-md-2 col-sm-4">
														<input type="checkbox" id="myCheckbox10" />
														<label for="myCheckbox10">
															<div class="crypto-wallet-card">
																<img src="{{ url('front/images/custom-image/crypto-wallet-icon3.png') }}" alt="">
																<h5>EKAUM</h5>
															</div>
														</label>
													</div>
												</div>
												<div class="bit-head">
													<h4>Bit Coin</h4>
													<p class="text-center">Please enter your bank account details with which you are <br>
													going to make payment for investment.</p>
												</div>
												<div class="bank-details-deta">
													<div class="row">
														<div class="col-md-6 col-sm-6">
															<label for="">Bitcoin Address</label>
															<input type="text">
														</div>
														<div class="col-md-6 col-sm-6">
															<label for="">Ethereum Address ERC-20</label>
															<input type="text">
														</div>
														<div class="col-md-6 col-sm-6">
															<label for="">USD Address TRC-20</label>
															<input type="text">
														</div>
														<div class="col-md-6 col-sm-6">
															<label for="">EKAOM Address TRC-20</label>
															<input type="text">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="sub-btn mb-0">
								<button type="submit">Submit</button>
							</div>
						</form>
					</div>
				</div>
				<div id="step-6" class="tab-pane" role="tabpanel" aria-labelledby="step-7">
					<div class="kyc-box-main kyc-complate">
						<img src="{{ url('front/images/custom-image/kyc-complate.png') }}" alt="">
						<h5>KYC Completed</h5>
						<p>Thanks for submitting your document we’ll verify it and complete your KYC as soon as possible</p>
						<div class="sub-btn mb-0">
							<a href="{{ url('home') }}">Back to home</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>
@endsection
@push('js')
<script>
	function handleImageChange(event, previewId) {
		// Get the selected file
		const file = event.target.files[0];
		
		// Check if a file is selected and if it's an image
		if (file && file.type.startsWith('image/')) {
			const reader = new FileReader();
			
			// Load the image file
			reader.onload = function(e) {
				// Set the image preview source
				const imagePreview = document.getElementById(previewId);
				imagePreview.src = e.target.result;
				imagePreview.style.display = 'block';
			};
			
			// Read the file as a data URL
			reader.readAsDataURL(file);
			} else {
			// Hide the preview if no file is selected or it's not an image
			document.getElementById(previewId).style.display = 'none';
		}
	}
	
	// Attach event listeners
	document.getElementById('profile').addEventListener('change', function(event) {
		handleImageChange(event, 'imagePreview');
	});
	document.getElementById('aadhaar_front').addEventListener('change', function(event) {
		handleImageChange(event, 'imagePreview2');
	});
	document.getElementById('aadhaar_back').addEventListener('change', function(event) {
		handleImageChange(event, 'imagePreview3');
	});
	document.getElementById('pancard_image').addEventListener('change', function(event) {
		handleImageChange(event, 'imagePreview4');
	});
	
	$(document).ready(function() {
		// Toolbar extra buttons
		var btnFinish = $('<button></button>').text('Finish').addClass('btn btn-info').on('click', function() {
			alert('Finish Clicked');
		});
		var btnCancel = $('<button></button>').text('Cancel').addClass('btn btn-danger').on('click', function() {
			$('#smartwizard').smartWizard("reset");
		});
		// Step show event
		$("#smartwizard").on("showStep", function(e, anchorObject, stepNumber, stepDirection, stepPosition) {
			$("#prev-btn").removeClass('disabled');
			$("#next-btn").removeClass('disabled');
			if (stepPosition === 'first') {
				$("#prev-btn").addClass('disabled');
				} else if (stepPosition === 'last') {
				$("#next-btn").addClass('disabled');
				} else {
				$("#prev-btn").removeClass('disabled');
				$("#next-btn").removeClass('disabled');
			}
		});
		// Smart Wizard
		$('#smartwizard').smartWizard({
			selected: 0,
			theme: 'dots',
			transition: {
				animation: 'slide-horizontal', // Effect on navigation, none/fade/slide-horizontal/slide-vertical/slide-swing
			},
			toolbarSettings: {
				toolbarPosition: 'both', // both bottom
				toolbarExtraButtons: [btnFinish, btnCancel]
			}
		});
		// External Button Events
		$("#reset-btn").on("click", function() {
			// Reset wizard
			$('#smartwizard').smartWizard("reset");
			return true;
		});
		$("#prev-btn").on("click", function() {
			// Navigate previous
			$('#smartwizard').smartWizard("prev");
			return true;
		});
		$("#next-btn").on("click", function() {
			// Navigate next
			$('#smartwizard').smartWizard("next");
			return true;
		});
		// Demo Button Events
		$("#got_to_step").on("change", function() {
			// Go to step
			var step_index = $(this).val() - 1;
			$('#smartwizard').smartWizard("goToStep", step_index);
			return true;
		});
		$("#is_justified").on("click", function() {
			// Change Justify
			var options = {
				justified: $(this).prop("checked")
			};
			$('#smartwizard').smartWizard("setOptions", options);
			return true;
		});
		$("#animation").on("change", function() {
			// Change theme
			var options = {
				transition: {
					animation: $(this).val()
				},
			};
			$('#smartwizard').smartWizard("setOptions", options);
			return true;
		});
		$("#theme_selector").on("change", function() {
			// Change theme
			var options = {
				theme: $(this).val()
			};
			$('#smartwizard').smartWizard("setOptions", options);
			return true;
		});
	});
	
	$(document).ready(function() {
		function handleFormSubmission(formId) {
			$(formId).submit(function(event) {
				event.preventDefault();
				
				var $form = $(this);
				var $submitButton = $form.find('button');
				var $spinButton = $form.find('button.spin-button');
				
				// Disable the button and show loading spinner
				$submitButton.prop('disabled', true);
				$spinButton.addClass('loading').html('<span class="spinner"></span>');
				
				var formData = new FormData(this);
				formData.append('_token', "{{ csrf_token() }}");
				
				// Perform AJAX request
				$.ajax({
					async: true,
					type: $form.attr('method'),
					url: $form.attr('action'),
					data: formData,
					cache: false,
					processData: false,
					contentType: false,
					dataType: 'json',
					success: function(res) {
						$submitButton.prop('disabled', false);
						$spinButton.removeClass('loading').html('Save');
						
						if (res.status === "error") {
							toastrMsg(res.status, res.msg);
							} else if (res.status === "validation") {
							$('.error').remove(); // Clear previous error messages
							$.each(res.errors, function(key, value) {
								var inputField = $('#' + key);
								var errorSpan = $('<span>')
								.addClass('error text-danger')
								.attr('id', key + 'Error')
								.text(value[0]);
								inputField.parent().append(errorSpan);
							});
							} else {
							toastrMsg(res.status, res.msg);
							$('body').css({
								'overflow': 'auto'
							});
							$('.error').remove();
							setTimeout(function() {
								location.reload();
							}, 3000);
						}
					}
				});
			});
		}
		
		// Attach the form submission handler to each form
		handleFormSubmission('#updateProfileImage');
		handleFormSubmission('#updateAadharcard');
		handleFormSubmission('#updateAadharcardBack');
		handleFormSubmission('#updatePanCard');
		handleFormSubmission('#updateAccountDetails');
		handleFormSubmission('#updateWalletKYC');
	});
</script>
@endpush