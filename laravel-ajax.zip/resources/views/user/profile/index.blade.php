@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="profile-main">
        <div class="profile-head">
			@if($authUser->profile)
				<img src="{{ url('public/storage/'. $authUser->profile) }}" alt="">
			@else
				<img src="{{ url('front/images/custom-image/profile-img.png') }}" alt="">	
			@endif
            <div class="profile-text">
                <h5>{{ $authUser->name }}</h5>
                <h6>{{ $authUser->email }}</h6>
            </div>
        </div>
        <div class="profile-navigation">
            <a href="{{ url('personal-data') }}">
                <h5><span><img src="{{ url('front/images/custom-image/profile-navigation1.png') }}" alt=""></span>Personal Data</h5>
                <i class="lni lni-chevron-right"></i>
            </a>
           <!-- <a href="profile-settings.php">
                <h5><span><img src="{{ url('front/images/custom-image/profile-navigation2.png') }}" alt=""></span>Settings</h5>
                <i class="lni lni-chevron-right"></i>
            </a> -->
            <a href="{{ url('kyc') }}">
                <h5><span><img src="{{ url('front/images/custom-image/profile-navigation3.png') }}" alt=""></span>KYC</h5>
                <i class="lni lni-chevron-right"></i>
            </a>
            <!--<a href="wallet.php">
                <h5><span><img src="{{ url('front/images/custom-image/profile-navigation4.png') }}" alt=""></span>Add Crypto wallet</h5>
                <i class="lni lni-chevron-right"></i>
            </a>-->
            <a href="{{ url('purchase-history') }}">
                <h5><span><img src="{{ url('front/images/custom-image/profile-navigation5.png') }}" alt=""></span>Purchase history</h5>
                <i class="lni lni-chevron-right"></i>
            </a>
            <a href="{{ url('referral-code') }}">
                <h5><span><img src="{{ url('front/images/custom-image/profile-navigation6.png') }}" alt=""></span>Referral Code</h5>
                <i class="lni lni-chevron-right"></i>
            </a>
        </div>
    </div>
</main>
@endsection
@push('js')

</script>
@endpush