@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="refer-main">
        <h2>Refer <span>Friends & Earn</span> $10</h2>
        <div class="refer-card">
            <h6>Your referral code</h6>
            <h3 id="referralCode">{{ $authUser->referral_code }}</h3>
           <a href="javascript:void(0);" onclick="copyToClipboard()">Tap to copy</a>
        </div>
        <div class="refer-point">
            <p><span><img src="{{ url('front/images/custom-image/arrow-dotted.svg') }}" alt=""></span> Send an invite to a friend.</p>
            <p><span><img src="{{ url('front/images/custom-image/arrow-dotted.svg') }}" alt=""></span> Your friend sign up.</p>
            <p><span><img src="{{ url('front/images/custom-image/arrow-dotted.svg') }}" alt=""></span> You’ll both get cash when friend <br>
                submits their first receipt.</p>
        </div>
        <div class="invite-btn">
            <a href="javascript:void(0);" class="comm-btn">Invite</a>
        </div>
    </div>
</main>
@endsection
@push('js')
<script>
	function copyToClipboard() {
            // Get the referral code text
            var codeText = document.getElementById("referralCode").innerText;
            
            // Create a temporary input element to hold the text
            var tempInput = document.createElement("input");
            document.body.appendChild(tempInput);
            tempInput.value = codeText;
            tempInput.select();
            tempInput.setSelectionRange(0, 99999); // For mobile devices
            
            // Copy the text to clipboard
            document.execCommand("copy");
            
            // Remove the temporary input element
            document.body.removeChild(tempInput);

            // Optionally, display a message to the user
            alert("Referral code copied to clipboard: " + codeText);
        }
</script>
@endpush