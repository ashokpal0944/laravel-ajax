@extends('layouts.main')

@section('content')
<main class="page-content wallet-payment-bg">
    <div class="profile-personal-deta">
		<form id="updatePassword" method="post" action="{{ url('update-password') }}">
			@csrf
			<div class="row">
				<div class="col-sm-6">
					<div class="form-group">
						<label for="old_password" class="label-main">Old Password</label>
						<div class="eye-deta position-relative">
							<input type="password" class="input-main" name="old_password" id="old_password" placeholder="Old Password">
							<img id="toggleOldPassword" class="eye-icon" src="{{ url('front/images/custom-image/eye.svg') }}" alt="Show Password" style="cursor: pointer; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">
						</div>
					</div>
				</div>
				<div class="col-sm-6"></div>
				<div class="col-sm-6">
					<div class="form-group">
						<label for="password" class="label-main">New Password</label>
						<div class="eye-deta position-relative">
							<input type="password" class="input-main" name="password" id="password" placeholder="New Password">
							<img id="toggleNewPassword" class="eye-icon" src="{{ url('front/images/custom-image/eye.svg') }}" alt="Show Password" style="cursor: pointer; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">
						</div>
					</div>
				</div>
				<div class="col-sm-6"></div>
				<div class="col-sm-6">
					<div class="form-group">
						<label for="confirm_password" class="label-main">Re-type password</label>
						<div class="eye-deta position-relative">
							<input type="password" class="input-main" name="confirm_password" id="confirm_password" placeholder="Re-type password">
							<img id="toggleConfirmPassword" class="eye-icon" src="{{ url('front/images/custom-image/eye.svg') }}" alt="Show Password" style="cursor: pointer; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">
						</div>
					</div>
				</div>
				<div class="col-12">
					<button type="submit" class="comm-btn action-btn spin-btn">Save</button>
				</div>
			</div>
		</form>
	</div>
</main>
@endsection
@push('js')
<script>
	
	function togglePasswordVisibility(inputId, toggleIconId) {
        const inputField = document.getElementById(inputId);
        const toggleIcon = document.getElementById(toggleIconId);
        const isPassword = inputField.getAttribute('type') === 'password';
        
        // Toggle the input field type
        inputField.setAttribute('type', isPassword ? 'text' : 'password');
        
        // Toggle the eye icon
        toggleIcon.src = isPassword ? "{{ url('front/images/custom-image/eye-hidden.svg') }}" : "{{ url('front/images/custom-image/eye.svg') }}";
	}
	
    // Event listeners for each eye icon
    document.getElementById('toggleOldPassword').addEventListener('click', function() {
        togglePasswordVisibility('old_password', 'toggleOldPassword');
	});
	
    document.getElementById('toggleNewPassword').addEventListener('click', function() {
        togglePasswordVisibility('password', 'toggleNewPassword');
	});
	
    document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
        togglePasswordVisibility('confirm_password', 'toggleConfirmPassword');
	});
	
	$('#updatePassword').submit(function(event) {
		event.preventDefault();
		
		var $form = $(this);
		var $submitButton = $form.find('button');
		var $spinButton = $form.find('button.spin-btn');
		
		$submitButton.prop('disabled', true);
		$spinButton.addClass('loading');
		
		var formData = new FormData(this);
		formData.append('_token', "{{ csrf_token() }}");
		
		$.ajax({
			async: true,
			type: $form.attr('method'),
			url: $form.attr('action'),
			data: formData,
			cache: false,
			processData: false,
			contentType: false,
			dataType: 'Json',
			success: function(res) {
				$submitButton.prop('disabled', false);
				$spinButton.removeClass('loading');
				
				if (res.status === "error")
				{
					toastrMsg(res.status, res.msg);
					$('.error').remove();
					} else if (res.status === "validation") {
					$('.error').remove(); // Clear previous error messages
					
					$.each(res.errors, function(key, value) {
						var inputField = $('#' + key);
						var errorSpan = $('<span>')
						.addClass('error text-danger')
						.attr('id', key + 'Error')
						.text(value[0]);
						inputField.parent().append(errorSpan);
					});
					} else {
					toastrMsg(res.status, res.msg);
					$('body').css({'overflow': 'auto'});
					$('.error').remove();
					$form[0].reset();
					
					setTimeout(function() {
						location.reload(); 
					}, 3000);
				}
			}
		});
	});
</script>
@endpush