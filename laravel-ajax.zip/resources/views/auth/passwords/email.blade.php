<!doctype html>
<html lang="en" class="semi-dark">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="{{ url('storage/' . config('setting.fevicon_icon')) }}">
		<link href="{{ url('front/css/bootstrap.min.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/bootstrap-extended.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/style.css') }}" rel="stylesheet" />
		<title>Send Password Reset Link</title>
	</head>
	<body>
		<div class="login-page-main forgot-pass-right">
			<div class="container">
				<div class="row justify-content-between align-items-center">
					<div class="col-lg-5">
						<div class="login-deta">
							<div class="login-head">
								<img src="{{ url('storage/' . config('setting.logo')) }}" alt="">
								<h3>Forgot your password?</h3>
								<p>Don’t worry, happens to all of us. Enter your email below to recover your password</p>
							</div>
							
							@if (session('status'))
							<div class="alert alert-success" role="alert">
								{{ session('status') }}
							</div>
							@endif
							
							<div class="login-form">
								<form method="POST" action="{{ route('password.email') }}">
									@csrf
									<div class="row">
										<div class="col-12">
											<label for="">{{ __('Email Address') }}</label>
											<input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
											@error('email')
											<span class="invalid-feedback" role="alert">
												<strong>{{ $message }}</strong>
											</span>
											@enderror
										</div>
										<div class="col-lg-12">
											<button type="submit"> {{ __('Send Password Reset Link') }}</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-xl-5 col-lg-6">
						<div class="login-img">
							<img src="{{ url('front/images/custom-image/forgot-pass.png') }}" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
		<script src="{{ url('front/js/bootstrap.bundle.min.js') }}"></script>
	</body>
</html>