<!doctype html>
<html lang="en" class="semi-dark">
	<head>
		<!-- Required meta tags -->
		<title>User - Login</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="{{ url('storage/' . config('setting.fevicon_icon')) }}">
		<link href="{{ url('admin/libs/select2/select2.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{url('admin/libs/sweetalert2/sweetalert2.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{url('admin/libs/jquery-toast/jquery.toast.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ url('front/css/bootstrap.min.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/bootstrap-extended.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/style.css') }}" rel="stylesheet" />
		<style>
		    .login-forgot .label-main a,.sign-up span {
			color: #ffe500;
            }
            
            .otp-deta {
			text-align: center;
			color: #fff;
			font-size: 14px;
			margin: 0;
            }
            
            .otp-resend {
			text-align: center;
			color: #ffe500;
			font-size: 14px;
			margin-top: 5px;
			display: block;
			font-weight: 500;
            }
            
            .otp-resend:hover{
			color: #ffe500;
            }
            
            .show-otp p {
			text-align: center;
			margin: 0;
			color: #fff;
			font-size: 14px;
			font-weight: 500;
            }
            
            .show-otp p span {
			color: #ffe500;
            }
		</style>
	</head>
	<body>
		<div class="login-page-main">
			<div class="container">
				<div class="row justify-content-between align-items-center">
					<div class="col-lg-5">
						<div class="login-deta">
							<div class="login-head">
								<img src="{{ url('storage/' . config('setting.logo')) }}" alt="">
								<h3>Login</h3>
								<!--<p>Login to access your travelwise account</p>-->
							</div>
							<div class="login-form">
								<form id="loginForm" method="POST" action="{{ url('user-login') }}">
									@csrf
									<div class="row">
										<div id="user_detail_login_div">
											<div class="col-12">
												<label for="">{{ __('Email Address') }} / Username</label>
												<input id="email" type="text" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}"  autocomplete="email" autofocus>
												@error('email')
												<span class="invalid-feedback" role="alert">
													<strong>{{ $message }}</strong>
												</span>
												@enderror
											</div>
											<div class="col-12">
												<label for="">{{ __('Password') }}</label>
												<div class="eye-deta">
													<input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" autocomplete="current-password">
													<img id="togglePassword" class="eye-icon" src="{{ url('front/images/custom-image/eye.svg') }}" alt="Show Password" style="cursor: pointer; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">
												</div>
												@error('password')
												<span class="invalid-feedback" role="alert">
													<strong>{{ $message }}</strong>
												</span>
												@enderror
											</div>
										</div>
										<div id="mobile_detail_login_div" style="display:none;">
											<div class="col-12">
												<label for="">Mobile Number</label>
												<input id="mobile_number" type="text" class="form-control @error('mobile_number') is-invalid @enderror" name="mobile_number" value="{{ old('mobile_number') }}" maxlength="10" autocomplete="mobile_number" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" autofocus>
												@error('mobile_number')
												<span class="invalid-feedback" role="alert">
													<strong>{{ $message }}</strong>
												</span>
												@enderror
											</div>
										</div>
										<div class="col-12">
											<div class="login-forgot">
												<div class="form-term d-flex align-items-center">
													<input class="form-check-input" type="checkbox" required name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
													<label class="label-main m-0" for="remember">I have read <a href="https://softieons.com">User agrement</a> and i accepted it</label>
												</div>
												<a href="{{ route('password.request') }}">Forgot Password</a>
											</div>
										</div>
										<div class="col-lg-12">
											<!--<button type="submit">Login</button>-->
											<button type="submit" class="action-btn spin-btn" id="login-details">Login</button>
										</div>
										<div class="col-12 text-center">
											<div class="d-flex justify-content-between">
												<a href="{{ url('register') }}" class="sign-up">Don’t have an account? <span>Sign up</span></a>
												<a href="javascript:void();" onclick="changeScreen('mobile')" id="login_mobile_screen" class="sign-up">Login <span>Mobile</span></a>
												<a href="javascript:void();" onclick="changeScreen('username')" id="login_username_screen" class="sign-up" style="display:none;">Login <span>Username</span></a>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-xl-5 col-lg-6">
						<div class="login-img">
							<img src="{{ url('front/images/custom-image/login-img.png') }}" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="modal fade" id="otp_verification_model" tabindex="-1" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">OTP Verification</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<form id="otpVerifyModel" method="post" action="{{ url('user-otp-verification')}}">
						@csrf
						<div class="modal-body">
							<div class="add-deposite-main">
								<div class="row">
									<div class="col-lg-12">
										<div class="show-otp">
											<p id="your_otp_display"></p>
										</div>
									</div>
									<div class="col-lg-12">
										<label class="label-main" for="">OTP</label>
										<input class="input-main" type="text" name="otp" id="otp" placeholder="Enter OTP.">
										<input class="input-main" type="hidden" name="mobileNumber" id="mobileNumber" placeholder="Enter OTP.">
									</div>
									<div class="col-lg-12 text-center">
										<p class="otp-deta" id="otp_timer">Resend OTP in <span id="timer">30</span> seconds</p>
										<a href="javascript:void(0);" class="otp-resend" id="resend_otp_btn" onclick="resendOtp()" style="display: none;">Resend OTP</a>
									</div>
									<div class="col-lg-12">
										<button type="submit" class="comm-btn w-100 action-btn spin-btn">Verify OTP</button>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
		<script src="{{ url('admin/libs/select2/select2.min.js') }}"></script>
		<script src="{{url('admin/libs/sweetalert2/sweetalert2.min.js') }}"></script>
		<script src="{{url('admin/libs/jquery-toast/jquery.toast.min.js') }}"></script>
		<script src="{{ url('front/js/bootstrap.bundle.min.js') }}"></script>
		<script>
			function changeScreen(loginType) {
				if (loginType === "mobile") {
					$("#login_mobile_screen").hide();
					$("#login_username_screen").show();
					$("#user_detail_login_div").hide();
					$("#mobile_detail_login_div").show();
					// Clear username and password fields
					$("#email").val('');
					$("#password").val('');
					$("#login-details").text('Send OTP');
					} else {
					$("#login_mobile_screen").show();
					$("#login_username_screen").hide();
					$("#user_detail_login_div").show();
					$("#mobile_detail_login_div").hide();
					// Clear mobile number field
					$("#login-details").text('Login');
					$("#mobile_number").val('');
				}
			}
			
			$('#loginForm').submit(function(event) {
				event.preventDefault();
				
				var $form = $(this);
				var $submitButton = $form.find('button');
				var $spinButton = $form.find('button.spin-btn');
				
				// Disable the submit button and show the loader
				$submitButton.prop('disabled', true);
				$spinButton.addClass('loading'); // Correct jQuery method to add a class
				
				const mobileNumber = $("#mobile_number").val();
				
				var formData = new FormData(this);
				formData.append('_token', "{{ csrf_token() }}");
				
				$.ajax({
					async: true,
					type: $form.attr('method'),
					url: $form.attr('action'),
					data: formData,
					cache: false,
					processData: false,
					contentType: false,
					dataType: 'json',
					success: function(res) {
						// Re-enable the button and hide the loader
						$submitButton.prop('disabled', false);
						$spinButton.removeClass('loading'); // Correct jQuery method to remove a class
						
						if (res.status === "error") 
						{
							toastrMsg(res.status, res.msg);
						} 
						else if (res.status === "validation")
						{
							$('.error').remove(); // Clear previous error messages
							
							$.each(res.errors, function(key, value) {
								var inputField = $('#' + key);
								var errorSpan = $('<span>')
								.addClass('error text-danger')
								.attr('id', key + 'Error')
								.text(value[0]);
								inputField.parent().append(errorSpan);
							});
						} 
						else if (res.status === "email_validation") 
						{
							$('.error').remove(); 
							
							Swal.fire({
								icon: "error",
								type:"error",
								title: '<h4 style="font-weight: normal;font-size: 18px;font-weight: 600;"">' + res.msg+ '</h4>',
								html: '<p style="text-align: center;font-size: 12px;font-weight: 500;">Please click on the link to verify your email and start using your account. If you need further assistance, feel free to contact our support team at <a href="mailto:support@clarusventure.com">support@clarusventure.com</a>.</p> ',
								width: '600px', // Increase modal width
								customClass: {
									popup: 'swal-wide-popup', // Add custom class for additional styling if needed
									title: 'swal-wide-title', // Custom class for title
									htmlContainer: 'swal-wide-html' // Custom class for HTML content
								},
								confirmButtonText: 'Okay',
							});
						}
						else {
							toastrMsg(res.status, res.msg);
							$('body').css({'overflow': 'auto'});
							
							// Reset Select2 or any plugin-dependent fields
							$form.find('select').val('').trigger('change'); 
							$('.error').remove();
							
							if(res.otp) 
							{
								$("#mobileNumber").val(mobileNumber);
								$("#your_otp_display").html("Your OTP Is : <span>"+res.otp+"</span>");
								startOtpTimer();
								$("#otp_verification_model").modal('show');
							} 
							else 
							{
								$form[0].reset();
								// Redirect to the login page
								window.location.href = "{{ url('home') }}";
							}
						}
					},
					error: function() {
						$submitButton.prop('disabled', false);
						$spinButton.removeClass('loading'); // Hide the loader in case of error
						toastrMsg('error', 'An unexpected error occurred.');
					}
				});
			});
			
			$('#otpVerifyModel').submit(function(event) {
				event.preventDefault();
				
				var $form = $(this);
				var $submitButton = $form.find('button');
				var $spinButton = $form.find('button.spin-btn');
				
				const mobileNumber = $("#mobile_number").val();
				
				// Disable the button and show loading spinner
				$submitButton.prop('disabled', true);
				$spinButton.addClass('loading');
				
				// Prepare form data
				const formData = new FormData(this);
				formData.append('_token', "{{ csrf_token() }}");
				formData.append('mobile_number', mobileNumber);
				
				// AJAX request
				$.ajax({
					type: $form.attr('method'),
					url: $form.attr('action'),
					data: formData,
					cache: false,
					processData: false,
					contentType: false,
					dataType: 'json',
					success: function(res) {
						// Re-enable the button and remove loading spinner
						$submitButton.prop('disabled', false);
						$spinButton.removeClass('loading'); // Correct jQuery method to remove a class
						
						// Handle response
						if (res.status === "error") {
							toastrMsg(res.status, res.msg);
						} 
						else if (res.status === "validation") {
							// Clear previous errors
							$('.error').remove();
							// Display validation errors
							$.each(res.errors, function(key, value) {
								const $inputField = $('#' + key);
								const errorSpan = $('<span>')
								.addClass('error text-danger')
								.attr('id', key + 'Error')
								.text(value[0]);
								$inputField.parent().append(errorSpan);
							});
						} 
						else {
							toastrMsg(res.status, res.msg);
							window.location.href = "{{ url('home') }}";
						}
					},
					error: function(xhr, status, error) {
						// Handle general AJAX errors
						toastrMsg('error', 'An error occurred. Please try again.');
						$submitButton.prop('disabled', false);
						$spinButton.removeClass('loading');
					}
				});
			});
			
			function startOtpTimer() {
				let countdown = 30;
				const timerDisplay = document.getElementById('timer');
				const resendOtpBtn = document.getElementById('resend_otp_btn');
				const otpTimer = document.getElementById('otp_timer');
				
				const interval = setInterval(() => {
					countdown--;
					timerDisplay.textContent = countdown;
					
					if (countdown <= 0) {
						clearInterval(interval);
						otpTimer.style.display = 'none'; // Hide timer text
						resendOtpBtn.style.display = 'inline'; // Show resend button
					}
				}, 1000);
			}
			
			function resendOtp() {
				let mobileNumber = $('#mobileNumber').val(); // Make sure you get the mobile number input field's value
				let $form = $('#otpVerifyModel'); // Cache the form element
				let $submitButton = $form.find('button[type="submit"]'); // Cache the submit button
				let $spinButton = $form.find('.spin-btn'); // Cache the spin button
				
				// Disable the submit button and show a loading state
				$submitButton.prop('disabled', true);
				$spinButton.addClass('loading');
				
				document.getElementById('otp_timer').style.display = 'block';
				document.getElementById('resend_otp_btn').style.display = 'none';
				document.getElementById('timer').textContent = '30';
				
				$.ajax({
					type: "POST",
					url: "{{ url('user-login') }}",
					data: {
						'_token': "{{ csrf_token() }}",
						'mobile_number': mobileNumber
					},
					dataType: 'json',
					success: function(res) {
						// Re-enable the submit button and remove the loading state
						$submitButton.prop('disabled', false);
						$spinButton.removeClass('loading');
						
						if (res.status === "error") {
							toastrMsg(res.status, res.msg);
							} else if (res.status === "validation") {
							$('.error').remove(); // Clear previous error messages
							
							$.each(res.errors, function(key, value) {
								var inputField = $('#' + key);
								var errorSpan = $('<span>')
								.addClass('error text-danger')
								.attr('id', key + 'Error')
								.text(value[0]);
								inputField.parent().append(errorSpan);
							});
							} else {
							toastrMsg(res.status, res.msg);
							$('body').css({'overflow': 'auto'});
							
							// Reset Select2 or any plugin-dependent fields
							$form.find('select').val('').trigger('change');
							$('.error').remove();
							
							if (res.otp) {
								$("#your_otp_display").html("Your OTP is: <span>" + res.otp + "</span>");
								startOtpTimer();
								} else {
								$form[0].reset();
								window.location.href = "{{ url('home') }}"; // Redirect to the home page
							}
						}
					},
					error: function() {
						// Re-enable the submit button and remove the loading state in case of error
						$submitButton.prop('disabled', false);
						$spinButton.removeClass('loading');
						toastrMsg('error', 'An unexpected error occurred.');
					}
				});
			}
			
			// JavaScript to toggle password visibility
			document.getElementById('togglePassword').addEventListener('click', function (e) {
				const passwordInput = document.getElementById('password');
				const isPassword = passwordInput.getAttribute('type') === 'password';
				
				// Toggle password visibility
				passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
				
				// Toggle the eye icon image
				this.src = isPassword ? "{{ url('front/images/custom-image/eye-hidden.svg') }}" : "{{ url('front/images/custom-image/eye.svg') }}";
			});
			
			function toastrMsg(type,msg)
			{
				$.toast({
					text: msg, 
					position: "top-right",
					loaderBg: "#da8609",
					icon: type,
					hideAfter: 3e3,
					stack: 1
				})
			}
		</script>
	</body>
</html>