<!doctype html>
<html lang="en" class="semi-dark">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="{{ url('storage/' . config('setting.fevicon_icon')) }}">
		<link href="{{ url('admin/libs/select2/select2.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{url('admin/libs/jquery-toast/jquery.toast.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{ url('front/css/bootstrap.min.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/bootstrap-extended.css') }}" rel="stylesheet" />
		<link href="{{ url('front/css/style.css') }}" rel="stylesheet" />
		<title>User - Register</title>
		<style>
		    .login-forgot .label-main a,.sign-up span {
            	color: #ffe500;
            }
            
		</style>
	</head>
	<body>
		<div class="login-page-main">
			<div class="container">
				<div class="row justify-content-between align-items-center">
					<div class="col-lg-6">
						<div class="login-deta register-deta">
							<div class="login-head">
								<img src="{{ url('storage/' . config('setting.logo')) }}" alt="">
								<!-- <h3>Login</h3>
								<p>Login to access your travelwise account</p> -->
							</div>
							<?php
								$get_countrys = App\Models\Country::where('name','!=','')->get();
								
							?>
							<div class="login-form">
								<form id="registerForm" action="{{ url('user-register') }}" method="post">
									@csrf
									<div class="row">
										<div class="col-lg-6 col-sm-6">
											<label for="">{{ __('Name') }}</label>
											<input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}"  autocomplete="name" autofocus>
											@error('name')
											<span class="invalid-feedback" role="alert">
												<strong>{{ $message }}</strong>
											</span>
											@enderror
										</div>
										<div class="col-lg-6 col-sm-6">
											<label for="">Mobile</label>
											<input id="phone_number" type="text" class="form-control @error('phone_number') is-invalid @enderror" name="phone_number" value="{{ old('phone_number') }}"  autocomplete="phone_number" autofocus oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
											@error('phone_number')
											<span class="invalid-feedback" role="alert">
												<strong>{{ $message }}</strong>
											</span>
											@enderror
										</div>
										<div class="col-lg-6 col-sm-6">
											<label for="">User Name</label>
											<input id="username" type="text" class="form-control @error('username') is-invalid @enderror" name="username" value="{{ old('username') }}"  autocomplete="username" autofocus>
											@error('username')
											<span class="invalid-feedback" role="alert">
												<strong>{{ $message }}</strong>
											</span>
											@enderror
										</div>
										<div class="col-lg-6 col-sm-6">
											<label for="">Password</label>
											<div class="eye-deta">
											<input type="password" class="form-control" name="password" id="password">
											<img id="togglePassword" class="eye-icon" src="{{ url('front/images/custom-image/eye.svg') }}" alt="Show Password" style="cursor: pointer; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);">
											</div>
										</div>
										<div class="col-lg-4 col-sm-6">
											<label for="">Country </label>
											<select class="form-control select2" name="country_id" id="country_id" onchange="getStateData()">
												<option value="">Select Country</option>
												@foreach($get_countrys as $get_country)
												<option value="{{ $get_country->id }}">{{ $get_country->name }}</option>
												@endforeach
											</select>
										</div>
										<div class="col-lg-4 col-sm-6">
											<label for="">State</label>
											<select class="form-control select2" name="state_id" id="state_id" onchange="getCityData()">
												<option value="">Select State</option>
											</select>
										</div>
										<div class="col-lg-4 col-sm-6">
											<label for="">City</label>
											<select class="form-control select2" name="city_id" id="city_id">
												<option value="">Select City</option>
											</select>
										</div>
										<div class="col-6 col-sm-6">
											<label for="occupation">Occupation </label>
											<select class="form-control select2" name="occupation" id="occupation">
												<option value="">Select Occupation</option>
												<option value="Software Engineer">Software Engineer</option>
												<option value="Doctor">Doctor</option>
												<option value="Teacher">Teacher</option>
												<option value="Accountant">Accountant</option>
												<option value="Civil Engineer">Civil Engineer</option>
												<option value="Nurse">Nurse</option>
												<option value="Lawyer">Lawyer</option>
												<option value="Pharmacist">Pharmacist</option>
												<option value="Graphic Designer">Graphic Designer</option>
												<option value="Architect">Architect</option>
												<option value="Sales Manager">Sales Manager</option>
												<option value="Electrician">Electrician</option>
												<option value="Plumber">Plumber</option>
												<option value="Chef">Chef</option>
												<option value="Marketing Manager">Marketing Manager</option>
											</select>
										</div>
										<div class="col-lg-6 col-sm-6">
											<label for="">Email</label>
											<input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}"  autocomplete="email" autofocus>
											@error('email')
											<span class="invalid-feedback" role="alert">
												<strong>{{ $message }}</strong>
											</span>
											@enderror
										</div>
										<div class="col-12">
											<div class="login-forgot">
												<div class="form-term d-flex align-items-center">
													<input class="form-check-input" type="checkbox" name="is_agree" id="is_agree" required>
													<label class="label-main m-0" for="">I have read <a href="https://softieons.com/">User agrement</a> and i accepted it</label>
												</div>
												<!-- <a href="#">Forgot Password</a> -->
											</div>
										</div>
										<div class="col-lg-12"><button type="submit" class="comm-btn w-100 action-btn spin-btn">Register </button></div>
										<div class="col-12 text-center"><a href="{{ url('login') }}" class="sign-up">Do you have an account ? <span>Login</span></a></div>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="col-xl-5 col-lg-6">
						<div class="login-img">
							<img src="{{ url('front/images/custom-image/login-img.png') }}" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
		<script src="{{ url('admin/libs/select2/select2.min.js') }}"></script>
		<script src="{{url('admin/libs/jquery-toast/jquery.toast.min.js') }}"></script>
		<script src="{{ url('front/js/bootstrap.bundle.min.js') }}"></script>
		<script>
			$('.select2').select2({
				placeholder: 'Select an option',
				allowClear: true
			});
			
			function getStateData()
			{
				var country_id = $('#country_id').val();
				var _token = $('input[name="_token"]').val();
				
				$.ajax({
					url:"{{ url('get-state-data') }}",
					method:"POST",
					data:{country_id:country_id, _token:_token},
					success:function(result)
					{
						$('#state_id').html(result);
					}
				})
			}
			
			function getCityData()
			{
				var state_id = $('#state_id').val();
				var _token = $('input[name="_token"]').val();
				
				$.ajax({
					url:"{{ url('get-city-data') }}",
					method:"POST",
					data:{state_id:state_id, _token:_token},
					success:function(result)
					{
						$('#city_id').html(result);
					}
				})
			}
			
			$('#registerForm').submit(function(event) {
				event.preventDefault();
				
				var $form = $(this);
				var $submitButton = $form.find('button');
				var $spinButton = $form.find('button.spin-btn');
				
				$submitButton.prop('disabled', true);
				$spinButton.addClass('loading'); 
				
				var formData = new FormData(this);
				formData.append('_token', "{{ csrf_token() }}");
				
				$.ajax({
					async: true,
					type: $form.attr('method'),
					url: $form.attr('action'),
					data: formData,
					cache: false,
					processData: false,
					contentType: false,
					dataType: 'Json',
					success: function(res) {
						$submitButton.prop('disabled', false);
						$spinButton.removeClass('loading');
						
						if (res.status === "error") {
							toastrMsg(res.status, res.msg);
							} else if (res.status === "validation") {
							$('.error').remove(); // Clear previous error messages
							
							$.each(res.errors, function(key, value) {
								var inputField = $('#' + key);
								var errorSpan = $('<span>')
								.addClass('error text-danger')
								.attr('id', key + 'Error')
								.text(value[0]);
								inputField.parent().append(errorSpan);
							});
							} else {
							toastrMsg(res.status, res.msg);
							$('body').css({'overflow': 'auto'});
							
							// Reset the form after successful submission
							$form[0].reset();
							
							// Reset Select2 or any plugin-dependent fields
							$form.find('select').val('').trigger('change'); 
							$('.error').remove();
							// Redirect to the login page
							setTimeout(function() {
								window.location.href = "{{ url('login') }}";
							}, 3000); // 3000 milliseconds = 3 seconds
						}
					}
				});
			});
			
			document.getElementById('togglePassword').addEventListener('click', function (e) {
				const passwordInput = document.getElementById('password');
				const isPassword = passwordInput.getAttribute('type') === 'password';
				
				// Toggle password visibility
				passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
				
				// Toggle the eye icon image
				this.src = isPassword ? "{{ url('front/images/custom-image/eye-hidden.svg') }}" : "{{ url('front/images/custom-image/eye.svg') }}";
			});
			
			function toastrMsg(type,msg)
			{
				$.toast({
					text: msg, 
					position: "top-right",
					loaderBg: "#da8609",
					icon: type,
					hideAfter: 3e3,
					stack: 1
				})
			}
			
			$(function() {
				$('#username').on('input', function() {
					const regex = /^[a-zA-Z0-9_]{5,20}$/; // Only letters, numbers, and underscores, 5-20 characters
					const username = $(this).val();

					if (!regex.test(username)) {
						$(this).addClass('is-invalid');
						$(this).next('.invalid-feedback').show().text('Username must be 5-20 characters long, only letters, numbers, and underscores are allowed.');
					} else {
						$(this).removeClass('is-invalid');
						$(this).next('.invalid-feedback').hide();
					}
				});

				$('#username').on('keypress', function(e) {
					if (e.which == 32) { // Prevent space character
						console.log('Space Detected');
						return false;
					}
				});
			});
		</script>
	</body>
</html>