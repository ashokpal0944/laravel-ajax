@extends('admin.layouts.admin')

@section('title','Setting - '.config('setting.website_title'))

@section('content')
<style>
	.upload-img {
	width: 100px;
	height: 100px;
	object-fit: cover;
	}
</style>
<div class="content">
	<!-- Start Content-->
	<div class="container-fluid">
		<!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box">
					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Home</a></li>
							<li class="breadcrumb-item active">Setting</li>
						</ol>
					</div>
					<h4 class="page-title">Update Setting Details</h4>
				</div>
			</div>
		</div>     
		<!-- end page title --> 
		<div class="row">
			<div class="col-lg-6">
				<div class="card-box">
					<h4 class="header-title">Web Site Setting Data</h4>
					<form id="updateSetting" class="parsley-examples" action="{{ url('admin/update-setting') }}" method="post">
						@csrf
						<div class="form-group row">
							<div class="col-lg-6">
								<label for="logo">Logo<span class="text-danger">*</span></label>
								<input type="file" name="logo" parsley-trigger="change"  placeholder="Enter name" class="form-control" id="logo">
							</div>
							<div class="col-lg-6">
								<label for="fevicon_icon">Fevicon Icon <span class="text-danger">*</span></label>
								<input type="file" name="fevicon_icon" class="form-control" id="fevicon_icon">
							</div>
						</div>
						<div class="form-group row">
							<div class="col-lg-6">
								<img src="{{ url('storage/' . config('setting.logo')) }}" alt="Logo" class="rounded-circle">
							</div>
							<div class="col-lg-6">
								<img src="{{ url('storage/' . config('setting.fevicon_icon')) }}" alt="Fevicon Icon" class="rounded-circle">
							</div>
						</div>
						<div class="form-group row">
							<div class="col-lg-4">
								<label for="website_title">Site Title<span class="text-danger">*</span></label>
								<input id="website_title" type="text" name="website_title" placeholder="Enter Site Title" class="form-control" value="{{ config('setting.website_title')}}" required>
							</div>
							<div class="col-lg-4">
								<label for="email">Contact Email<span class="text-danger">*</span></label>
								<input id="email" type="email" name="email" placeholder="Enter Contact Email" class="form-control" value="{{ config('setting.email')}}">
							</div>
							<div class="col-lg-4">
								<label for="contact_number">Contact Number<span class="text-danger">*</span></label>
								<input id="contact_number" type="text" name="contact_number" placeholder="Enter Contact Number" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.contact_number')}}">
							</div>
						</div>
						<div class="form-group">
							<label for="address">Address<span class="text-danger">*</span></label>
							<textarea name="address" id="address" class="form-control">{{ config('setting.address')}}</textarea>
						</div>
						<h3>Front Side Display Dynamic </h3>
						<div class="form-group">
							<label for="past_top_trade_title">Past Top Trade Title<span class="text-danger">*</span></label>
							<input id="past_top_trade_title" type="text" name="past_top_trade_title" placeholder="Enter Past Top Trade Title" class="form-control" value="{{ config('setting.past_top_trade_title')}}">
						</div>
						
						<div class="form-group">
							<label for="past_top_trade_title_percentag">Past Top Trade Title Percentag<span class="text-danger">*</span></label>
							<input id="past_top_trade_title_percentag" type="text" name="past_top_trade_title_percentag" placeholder="Enter Past Top Trade Title Percentag" class="form-control" value="{{ config('setting.past_top_trade_title_percentag')}}">
						</div>
						
						<div class="form-group">
							<label for="past_top_trade_information">Past Top Trade Information <span class="text-danger">*</span></label>
							<textarea name="past_top_trade_information" id="past_top_trade_information" rows="10" class="form-control"><?php echo config('setting.past_top_trade_information'); ?></textarea>
						</div>
						<div class="form-group">
							<label for="past_top_trade_title">Past Top Trade Title<span class="text-danger">*</span></label>
							<input id="past_top_trade_title" type="text" name="past_top_trade_title" placeholder="Enter Past Top Trade Title" class="form-control" value="{{ config('setting.past_top_trade_title')}}">
						</div>
						<div class="form-group">
							<label for="explore_the_exclusive_banner">Explore the Exclusive Banner<span class="text-danger">*</span></label>
							<input type="file" name="explore_the_exclusive_banner" class="form-control" id="explore_the_exclusive_banner">
						</div>
						
						@if(config('setting.explore_the_exclusive_banner'))
						<div class="form-group">
							<img src="{{ url('storage/' . config('setting.explore_the_exclusive_banner')) }}" alt="Banner Explore the Exclusive Banner" style="width:100px;">
						</div>
						@endif
						
						<div class="form-group">
							<label for="investment_banner_first">Investment First Banner<span class="text-danger">*</span></label>
							<input type="file" name="investment_banner_first[]" multiple class="form-control" id="investment_banner_first">
						</div>
						
						@if(config('setting.investment_banner_first'))
						<div class="form-group">
							<?php
								$investment_banner_first = json_decode(config('setting.investment_banner_first'));
							?>
							@foreach($investment_banner_first as $investment_banner)
							<img src="{{ url('storage/' . $investment_banner) }}" alt="Banner Images" style="width:100px;">
							<a href="javascript:void(0)" onclick="deleteFirstBanner('{{ urlencode($investment_banner) }}', event)">Delete</a>
							@endforeach
						</div>
						@endif
						<div class="form-group">
							<label for="investment_banner_second">Investment Second Banner<span class="text-danger">*</span></label>
							<input type="file" name="investment_banner_second[]" multiple class="form-control" id="investment_banner_second">
						</div>
						@if(config('setting.investment_banner_second'))
						<div class="form-group">
							<?php
								$investment_banner_second = json_decode(config('setting.investment_banner_second'));
							?>
							@foreach($investment_banner_second as $investment_banner)
							<div style="display: inline-block; margin-right: 10px;">
								<img src="{{ url('storage/' . $investment_banner) }}" alt="Banner Images" style="width:100px;">
								<a href="javascript:void(0)" onclick="deleteSecondBanner('{{ urlencode($investment_banner) }}', event)">Delete</a>
							</div>
							@endforeach
						</div>
						@endif
						
						<h3>Taxes Charges</h3>
						<div class="form-group row">
							<div class="col-lg-4">
								<label for="crypto_tax_percentage">Crypto tax<span class="text-danger">*</span></label>
								<input id="crypto_tax_percentage" type="text" name="crypto_tax_percentage" placeholder="Enter Crypto Tax Percentage" class="form-control" value="{{ config('setting.crypto_tax_percentage')}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
							</div>
							<div class="col-lg-4">
								<label for="cess_tax_percentage">CESS<span class="text-danger">*</span></label>
								<input id="cess_tax_percentage" type="text" name="cess_tax_percentage" placeholder="Enter CESS Percentage" class="form-control" value="{{ config('setting.cess_tax_percentage')}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
							</div>
							<div class="col-lg-4">
								<label for="tds_tax_percentage">TDS<span class="text-danger">*</span></label>
								<input id="tds_tax_percentage" type="text" name="tds_tax_percentage" placeholder="Enter TDS Percentage" class="form-control" value="{{ config('setting.tds_tax_percentage')}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
							</div>
						</div>
						<div class="form-group row">
							<div class="col-lg-4">
								<label for="wc_tax_percentage">WC<span class="text-danger">*</span></label>
								<input id="wc_tax_percentage" type="text" name="wc_tax_percentage" placeholder="Enter WC Percentage" class="form-control" value="{{ config('setting.wc_tax_percentage')}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
							</div>
							<div class="col-lg-4">
								<label for="maintenance_tax_percentage">Maintenance<span class="text-danger">*</span></label>
								<input id="maintenance_tax_percentage" type="text" name="maintenance_tax_percentage" placeholder="Enter Maintenance Percentage" class="form-control" value="{{ config('setting.maintenance_tax_percentage')}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
							</div>
						</div>
						<div class="form-group text-right mb-0">
							<button class="btn btn-gradient waves-effect waves-light" type="submit">Submit</button>
							<button type="reset" class="btn btn-light waves-effect ml-1">Cancel</button>
						</div>
					</form>
				</div> <!-- end card-box -->
			</div>
			<div class="col-md-6">
				<div class="row" style="flex-direction: collumn">
					<div class="col-12">
						<div class="card-box">
							<h4 class="header-title mb-4">Payment Information</h4>
							<ul class="nav nav-pills navtab-bg nav-justified">
								<li class="nav-item">
									<a href="#bank_account_details" data-toggle="tab" aria-expanded="false" class="nav-link active">
										Bank Account Details
									</a>
								</li>
								<li class="nav-item">
									<a href="#upi_id_tab_view" data-toggle="tab" aria-expanded="true" class="nav-link">
										UPI Id
									</a>
								</li>
								<li class="nav-item">
									<a href="#wallet_address" data-toggle="tab" aria-expanded="false" class="nav-link">
										Wallet Address
									</a>
								</li>
								<li class="nav-item">
									<a href="#exchange_address" data-toggle="tab" aria-expanded="false" class="nav-link">
										Exchange Address
									</a>
								</li>
							</ul>
							<div class="tab-content">
								<div class="tab-pane show active" id="bank_account_details">
									<div class="card-box">
										<form id="updateBankDetails" class="parsley-examples" action="{{ url('admin/update-setting') }}" method="post">
											@csrf
											<div class="form-group">
												<label for="bank_holder_name">Bank Holder Name<span class="text-danger">*</span></label>
												<input id="bank_holder_name" type="text" name="bank_holder_name" placeholder="Enter Bank Holder Name" class="form-control" value="{{ config('setting.bank_holder_name')}}" >
											</div>
											<div class="form-group">
												<label for="bank_name">Enter Bank Name<span class="text-danger">*</span></label>
												<input id="bank_name" type="text" name="bank_name" placeholder="Enter Bank Name" class="form-control" value="{{ config('setting.bank_name')}}" >
											</div>
											<div class="form-group">
												<label for="account_number">Account Number<span class="text-danger">*</span></label>
												<input id="account_number" type="text" name="account_number" placeholder="Enter Account Number" class="form-control" value="{{ config('setting.account_number')}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" >
											</div>
											<div class="form-group">
												<label for="ifsc_code">IFSC Code<span class="text-danger">*</span></label>
												<input id="ifsc_code" type="text" name="ifsc_code" placeholder="Enter Contact Number" class="form-control" value="{{ config('setting.ifsc_code')}}">
											</div>
											<div class="form-group text-right mb-0">
												<button class="btn btn-gradient waves-effect waves-light" type="submit">Submit</button>
												<button type="reset" class="btn btn-light waves-effect ml-1">Cancel</button>
											</div>
										</form>
									</div>
								</div>
								<div class="tab-pane" id="upi_id_tab_view">
									<div class="card-box">
										<form id="updateQRcode" class="parsley-examples" action="{{ url('admin/update-setting') }}" method="post">
											@csrf
											<div class="form-group">
												<label for="qr_code">QR Code<span class="text-danger">*</span></label>
												<input id="qr_code" type="file" name="qr_code" class="form-control" value="{{ config('setting.qr_code')}}" >
											</div>
											@if(config('setting.qr_code'))
											<div class="form-group row">
												<img src="{{ url('storage/' . config('setting.qr_code')) }}" alt="qr_code">
											</div>
											@endif
											<div class="form-group">
												<label for="upi_address">UPI Addres<span class="text-danger">*</span></label>
												<input id="upi_address" type="text" name="upi_address" placeholder="Enter UPI Addres" class="form-control" value="{{ config('setting.upi_address')}}" >
											</div>
											<div class="form-group text-right mb-0">
												<button class="btn btn-gradient waves-effect waves-light" type="submit">Submit</button>
												<button type="reset" class="btn btn-light waves-effect ml-1">Cancel</button>
											</div>
										</form>
									</div>
								</div>
								<div class="tab-pane" id="wallet_address">
									<div class="card-box">
										<form id="updateWalletAddress" class="parsley-examples" action="{{ url('admin/update-setting') }}" method="post">
											@csrf
											<div class="form-group row">
												<div class="col-md-3">
													<label for="trust_wallet_qr_code">Trust Wallet QR Code<span class="text-danger">*</span></label>
													<input id="trust_wallet_qr_code" type="file" name="trust_wallet_qr_code" placeholder="Enter Trust Wallet Address" class="form-control">
												</div>
												<div class="col-md-3">
													<img class="upload-img" src="{{ url('storage/' . config('setting.trust_wallet_qr_code')) }}" alt="">
												</div>
												<div class="col-md-6">
													<label for="trust_wallet">Trust Wallet Address<span class="text-danger">*</span></label>
													<input id="trust_wallet" type="text" name="trust_wallet" placeholder="Enter Trust Wallet Address" class="form-control" value="{{ config('setting.trust_wallet')}}" >
												</div>
											</div>
											<div class="form-group row">
												<div class="col-md-3">
													<label for="metamask_wallet_qr_code">Trust Metamask QR Code<span class="text-danger">*</span></label>
													<input id="metamask_wallet_qr_code" type="file" name="metamask_wallet_qr_code" class="form-control">
												</div>
												<div class="col-md-3">
													<img class="upload-img" src="{{ url('storage/' . config('setting.metamask_wallet_qr_code')) }}" alt="">
												</div>
												<div class="col-md-6">
													<label for="metamask_wallet">Metamask Wallet Address<span class="text-danger">*</span></label>
													<input id="metamask_wallet" type="text" name="metamask_wallet" placeholder="Enter Metamask Wallet Address" class="form-control" value="{{ config('setting.metamask_wallet')}}" >
												</div>
											</div>
											<div class="form-group row">
												<div class="col-md-3">
													<label for="ekaum_wallet_qr_code">Ekaum Metamask QR Code<span class="text-danger">*</span></label>
													<input id="ekaum_wallet_qr_code" type="file" name="ekaum_wallet_qr_code" class="form-control">
												</div>
												<div class="col-md-3">
													<img class="upload-img" src="{{ url('storage/' . config('setting.ekaum_wallet_qr_code')) }}" alt="">
												</div>
												<div class="col-md-6">
													<label for="ekaum_wallet">Ekaum Wallet Address<span class="text-danger">*</span></label>
													<input id="ekaum_wallet" type="text" name="ekaum_wallet" placeholder="Enter Ekaum Wallet Address" class="form-control" value="{{ config('setting.ekaum_wallet')}}">
												</div>
											</div>
											<div class="form-group row">
												<div class="col-md-3">
													<label for="phantom_wallet_qr_code">Phantom Wallet QR Code<span class="text-danger">*</span></label>
													<input id="phantom_wallet_qr_code" type="file" name="phantom_wallet_qr_code" class="form-control">
												</div>
												<div class="col-md-3">
													<img class="upload-img" src="{{ url('storage/' . config('setting.phantom_wallet_qr_code')) }}" alt="">
												</div>
												<div class="col-md-6">
													<label for="phantom_wallet">Phantom Wallet Address<span class="text-danger">*</span></label>
													<input id="phantom_wallet" type="text" name="phantom_wallet" placeholder="Enter Phantom Wallet Address" class="form-control" value="{{ config('setting.phantom_wallet')}}">
												</div>
											</div>
											<div class="form-group row">
												<div class="col-md-3">
													<label for="one_inch_wallet_qr_code">1 Inch Wallet QR Code<span class="text-danger">*</span></label>
													<input id="one_inch_wallet_qr_code" type="file" name="one_inch_wallet_qr_code" class="form-control">
												</div>
												<div class="col-md-3">
													<img class="upload-img" src="{{ url('storage/' . config('setting.one_inch_wallet_qr_code')) }}" alt="">
												</div>
												<div class="col-md-6">
													<label for="one_inch_wallet">1 Inch Wallet Address<span class="text-danger">*</span></label>
													<input id="one_inch_wallet" type="text" name="one_inch_wallet" placeholder="Enter 1 Inch Wallet Address" class="form-control" value="{{ config('setting.one_inch_wallet')}}">
												</div>
											</div>
											<div class="form-group row">
												<div class="col-md-3">
													<label for="electrum_wallet_qr_code">Electrum Wallet QR Code<span class="text-danger">*</span></label>
													<input id="electrum_wallet_qr_code" type="file" name="electrum_wallet_qr_code" class="form-control">
												</div>
												<div class="col-md-3">
													<img class="upload-img" src="{{ url('storage/' . config('setting.electrum_wallet_qr_code')) }}" alt="">
												</div>
												<div class="col-md-6">
													<label for="electrum_wallet">Electrum Wallet Address<span class="text-danger">*</span></label>
													<input id="electrum_wallet" type="text" name="electrum_wallet" placeholder="Enter Electrum Wallet Address" class="form-control" value="{{ config('setting.electrum_wallet')}}">
												</div>
											</div>
											<div class="form-group text-right mb-0">
												<button class="btn btn-gradient waves-effect waves-light" type="submit">Submit</button>
												<button type="reset" class="btn btn-light waves-effect ml-1">Cancel</button>
											</div>
										</form>
									</div>
								</div>
								<div class="tab-pane" id="exchange_address">
									<div class="card-box">
										<form id="updateExchangeAddress" class="parsley-examples" action="{{ url('admin/update-setting') }}" method="post">
											@csrf
											<div class="form-group">
												<label for="bitcoin_exchange">Bitcoin Exchange Address<span class="text-danger">*</span></label>
												<input id="bitcoin_exchange" type="text" name="bitcoin_exchange" placeholder="Enter Bitcoin Exchange Address" class="form-control" value="{{ config('setting.bitcoin_exchange')}}" >
											</div>
											<div class="form-group">
												<label for="etherium_exchange">Etherium Exchange Address<span class="text-danger">*</span></label>
												<input id="etherium_exchange" type="text" name="etherium_exchange" placeholder="Enter Etherium Exchange Address" class="form-control" value="{{ config('setting.etherium_exchange')}}" >
											</div>
											<div class="form-group">
												<label for="usdt_exchange">USDT Exchange Address<span class="text-danger">*</span></label>
												<input id="usdt_exchange" type="text" name="usdt_exchange" placeholder="Enter USDT Exchange Address" class="form-control" value="{{ config('setting.usdt_exchange')}}">
											</div>
											<div class="form-group">
												<label for="ekaum_exchange">Ekaum Exchange Address<span class="text-danger">*</span></label>
												<input id="ekaum_exchange" type="text" name="ekaum_exchange" placeholder="Enter Ekaum Exchange Address" class="form-control" value="{{ config('setting.ekaum_exchange')}}">
											</div>
											<div class="form-group text-right mb-0">
												<button class="btn btn-gradient waves-effect waves-light" type="submit">Submit</button>
												<button type="reset" class="btn btn-light waves-effect ml-1">Cancel</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-12">
						<div class="card-box">
							<h4 class="header-title">Investment Set Pecentage</h4>
							<form id="InvestmentPecentage" class="parsley-examples" action="{{ url('admin/update-setting') }}" method="post">
								@csrf
								<div class="form-group">
									<label for="return_on_investment">Return on Investment (%)<span class="text-danger">*</span></label>
									<input id="return_on_investment" type="text" name="return_on_investment" placeholder="Enter Return on Investment" class="form-control" value="{{ config('setting.return_on_investment')}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
								</div>
								<div class="form-group">
									<label for="estimated_time">Estimated Time <span class="text-danger">*</span></label>
									<input id="estimated_time" type="text" name="estimated_time" placeholder="12 - 18 Months" class="form-control" value="{{ config('setting.estimated_time')}}" >
								</div>
								<div class="form-group text-right mb-0">
									<button class="btn btn-gradient waves-effect waves-light" type="submit">Submit</button>
									<button type="reset" class="btn btn-light waves-effect ml-1">Cancel</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			
			<div class="col-lg-6">
	
			</div>
		</div>
	</div>
</div>
@endsection	
@push('js')
<script>
	let descriptionEditor;
	
	ClassicEditor
    .create(document.querySelector('#past_top_trade_information'))
    .then(editor => {
        descriptionEditor = editor;
	console.log('Editor was initialized successfully', editor);
	})
    .catch(error => {
        console.error('There was a problem initializing the editor.', error);
	});
	
	function handleFormSubmit(formId, editorId = null) {
		$(formId).submit(function(event) {
			event.preventDefault();
			
			// If an editor is provided, get its data and assign it to a hidden input
			if (editorId) {
				const data = descriptionEditor.getData();
				$(editorId).val(data);
			}
			
			// Disable button and show spinner
			const button = $(this).find('button');
			button.prop('disabled', true);
			button.addClass('loading').html('<span class="spinner"></span>');
			
			var formData = new FormData(this);
			formData.append('_token', "{{csrf_token()}}");
			
			$.ajax({
				async: true,
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: formData,
				cache: false,
				processData: false,
				contentType: false,
				dataType: 'Json',
				success: function(res) {
					button.prop('disabled', false);
					button.removeClass('loading').html('Save');
					
					if (res.status === "error") {
						toastrMsg(res.status, res.msg);
					} 
					else if (res.status === "validation") {
						$('.error').remove();  
						$.each(res.errors, function(key, value) {
							const inputField = $('#' + key);
							const errorSpan = $('<span>')
                            .addClass('error text-danger')
                            .attr('id', key + 'Error')
                            .text(value[0]);
							inputField.parent().append(errorSpan);
						});
					} 
					else {
						toastrMsg(res.status, res.msg);
						setTimeout(function() {
							window.location.reload(1);
						}, 3000);
					}
				}
			});
		});
	}
	
	// Applying the function to each form
	handleFormSubmit('#updateSetting', '#past_top_trade_information');
	handleFormSubmit('#updateBankDetails');
	handleFormSubmit('#updateQRcode');
	handleFormSubmit('#updateWalletAddress');
	handleFormSubmit('#updateExchangeAddress');
	handleFormSubmit('#InvestmentPecentage');
	
	function deleteFirstBanner(imagePath, event) {
		event.preventDefault(); // Prevent default link behavior
		
		Swal.fire({
			title: "Are you sure?",
			text: "You won't be able to revert this!",
			icon: "warning",
			showCancelButton: true,
			confirmButtonColor: "#3085d6",
			cancelButtonColor: "#d33",
			confirmButtonText: "Yes, delete it!"
			}).then(function(result) {
			if (result.value) {
				// AJAX request
				$.ajax({
					url: "{{ url('admin/delete-first-banner') }}",
					method: "post",
					data: {
						image: imagePath,
						_token: "{{ csrf_token() }}"
					},
					success: function(res) {
						if (res.status == "error") {
							Swal.fire("Error!", res.msg, "error");
							} else {
							Swal.fire("Deleted!", res.msg, "success");
							// Optionally, you can reload the page or remove the image element
							
							setTimeout(function(){
								location.reload();
							}, 2000);
							// 
						}
					},
					error: function() {
						Swal.fire("Error!", "Something went wrong.", "error");
					}
				});
			}
		});
	}
	
	function deleteSecondBanner(imagePath, event) {
		event.preventDefault(); // Prevent default link behavior
		
		Swal.fire({
			title: "Are you sure?",
			text: "You won't be able to revert this!",
			icon: "warning",
			showCancelButton: true,
			confirmButtonColor: "#3085d6",
			cancelButtonColor: "#d33",
			confirmButtonText: "Yes, delete it!"
			}).then(function(result) {
			if (result.value) {
				// AJAX request
				$.ajax({
					url: "{{ url('admin/delete-second-banner') }}",
					method: "post",
					data: {
						image: imagePath,
						_token: "{{ csrf_token() }}"
					},
					success: function(res) {
						if (res.status == "error") {
							Swal.fire("Error!", res.msg, "error");
							} else {
							Swal.fire("Deleted!", res.msg, "success");
							// Optionally, you can reload the page or remove the image element
							
							setTimeout(function(){
								location.reload();
							}, 2000);
							// 
						}
					},
					error: function() {
						Swal.fire("Error!", "Something went wrong.", "error");
					}
				});
			}
		});
	}
</script>
@endpush