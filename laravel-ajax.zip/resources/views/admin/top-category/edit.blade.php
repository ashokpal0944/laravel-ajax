
<div class="modal fade" id="edit_top_category_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Edit Top Category</h4>
			</div>
			<div class="modal-body">
				<form id="editTopCategoryModal" class="parsley-examples" action="{{ url('admin/top-category/edit',$get_top_category->id) }}" method="post">
					@csrf
					<div class="form-group">
						<label for="title">Title<span class="text-danger">*</span></label>
						<input type="text" name="title" parsley-trigger="change" required placeholder="Enter Title" class="form-control" id="title" value="{{ $get_top_category->title }}">
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="image">Image<span class="text-danger">*</span></label>
							<input type="file" name="image" parsley-trigger="change"   class="form-control" id="image">
						</div>
						<div class="col-lg-6">
							<img src="{{ url('public/storage/'.$get_top_category->image) }}" class="img-fluid mt-2" width="100px"/>
						</div>
					</div>
					
					<div class="form-group">
						<label for="description">Description <span class="text-danger">*</span></label>
						<textarea name="description" id="description" class="form-control"><?php echo $get_top_category->description; ?></textarea>
					</div>
					<div class="form-group">
						<label for="is_status">Status<span class="text-danger">*</span></label>
						<select class="form-control" name="is_status" id="is_status">
							<option value="">Select Status</option>
							<option value="1" {{ $get_top_category->is_status == 1 ? 'selected' : '' }}>Active</option>
							<option value="0" {{ $get_top_category->is_status == 0 ? 'selected' : '' }}>InActive</option>
						</select>
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light spin-button" type="submit">Submit</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	
	<script>
         $('#editTopCategoryModal').submit(function(event) {
			event.preventDefault();
			
			// Update the textarea value with CKEditor content
			const data = descriptionEditor.getData();
			$('#description').val(data);
			
			$(this).find('button').prop('disabled', true);
			$(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
			
			var formData = new FormData(this);
			formData.append('_token', "{{csrf_token()}}");
			
			$.ajax({
				async: true,
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: formData,
				cache: false,
				processData: false,
				contentType: false,
				dataType: 'Json',
				success: function(res) {
					$('#editTopCategoryModal').find('button').prop('disabled', false);
					$('#editTopCategoryModal').find('button.spin-button').removeClass('loading').html('Save');
					if (res.status == "error") {
						toastrMsg(res.status, res.msg);
					} else if (res.status == "validation") {
						$('.error').remove();
						$.each(res.errors, function(key, value) {
							var inputField = $('#' + key);
							var errorSpan = $('<span>')
								.addClass('error text-danger')
								.attr('id', key + 'Error')
								.text(value[0]);
							inputField.parent().append(errorSpan);
						});
					} else {
						toastrMsg(res.status, res.msg);
						$('#edit_top_category_modal').modal('hide');
						$('#edit_top_category_modal').remove();
						$('.modal-backdrop').remove();
						$('body').css({
							'overflow': 'auto'
						});
						DataTable.draw();
					}
				}
			});
		});
	</script>
</div>
