
<div class="modal fade" id="add_top_category_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Add Top Category</h4>
			</div>
			<div class="modal-body">
				<form id="addTopCategoryModal" class="parsley-examples" action="{{ url('admin/top-category/add') }}" method="post">
					@csrf
					<div class="form-group">
						<label for="title">Title<span class="text-danger">*</span></label>
						<input type="text" name="title" parsley-trigger="change" required placeholder="Enter Title" class="form-control" id="title">
					</div>
					<div class="form-group">
						<label for="title">Image <span class="text-danger">*</span></label>
						<input type="file" name="image" parsley-trigger="change" required  class="form-control" id="image">
					</div>
					<div class="form-group">
						<label for="description">Description </label>
						<textarea name="description" id="description" rows="10" class="form-control"></textarea>
					</div>
					<div class="form-group">
						<label for="is_status">Status<span class="text-danger">*</span></label>
						<select class="form-control" name="is_status" id="is_status">
							<option value="">Select Status</option>
							<option value="1">Active</option>
							<option value="0">InActive</option>
						</select>
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light spin-button" type="submit">Submit</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	<script>
        $('#addTopCategoryModal').submit(function(event) {
			event.preventDefault();
			
			// Update the textarea value with CKEditor content
			const data = descriptionEditor.getData();
			$('#description').val(data);
			
			$(this).find('button').prop('disabled', true);
			$(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
			
			var formData = new FormData(this);
			formData.append('_token', "{{csrf_token()}}");
			
			$.ajax({
				async: true,
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: formData,
				cache: false,
				processData: false,
				contentType: false,
				dataType: 'Json',
				success: function(res) {
					$('#addTopCategoryModal').find('button').prop('disabled', false);
					$('#addTopCategoryModal').find('button.spin-button').removeClass('loading').html('Save');
					if (res.status == "error") {
						toastrMsg(res.status, res.msg);
					} else if (res.status == "validation") {
						$('.error').remove();
						$.each(res.errors, function(key, value) {
							var inputField = $('#' + key);
							var errorSpan = $('<span>')
								.addClass('error text-danger')
								.attr('id', key + 'Error')
								.text(value[0]);
							inputField.parent().append(errorSpan);
						});
					} else {
						toastrMsg(res.status, res.msg);
						$('#add_top_category_modal').modal('hide');
						$('#add_top_category_modal').remove();
						$('.modal-backdrop').remove();
						$('body').css({
							'overflow': 'auto'
						});
						DataTable.draw();
					}
				}
			});
		});
	</script>
</div>
