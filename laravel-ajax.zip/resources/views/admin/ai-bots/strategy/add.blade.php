
<div class="modal fade" id="add_strategy_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Add Strategy</h4>
			</div>
			<div class="modal-body">
				<form id="addStrategyModal" class="parsley-examples" action="{{ url('admin/ai-bots/add-strategy') }}" method="post">
					@csrf
					<input type="hidden" id="aiboat_id" name="ai_boat_id" value="">
					<div class="form-group">
						<label for="title">Title<span class="text-danger">*</span></label>
						<input type="text" name="title" parsley-trigger="change" required placeholder="Enter Title" class="form-control" id="title">
					</div>
					<div class="form-group">
						<label for="title">Icon <span class="text-danger">*</span></label>
						<input type="file" name="icon" parsley-trigger="change" required  class="form-control" id="icon">
					</div>
					<div class="form-group">
						<label for="title">Icone Name <span class="text-danger">*</span></label>
						<input type="text" name="icon_name" parsley-trigger="change" required placeholder="Enter Icone Name" class="form-control" id="icon_name">
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="investment_price">Investment Price<span class="text-danger">*</span></label>
							<input type="text" name="investment_price" parsley-trigger="change" required placeholder="Enter Investment Price" class="form-control" id="investment_price" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
						</div>
						<div class="col-lg-6">
							<label for="return_of_intrest">Return Of Intrest<span class="text-danger">*</span></label>
							<input type="text" name="return_of_intrest" parsley-trigger="change" required placeholder="Enter Return Of Intrest" class="form-control" id="return_of_intrest" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
						</div>
					</div>
					<h3>Chart Data</h3>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="chart_data">Data<span class="text-danger">*</span></label>
							<input type="text" name="chart_data" parsley-trigger="change" required placeholder="Enter Chart Data" class="form-control" id="chart_data">
							<small class="text-danger">10, 20, 30 ....</small>
						</div>
						<div class="col-lg-6">
							<label for="chart_label">Label<span class="text-danger">*</span></label>
							<input type="text" name="chart_label" parsley-trigger="change" required placeholder="Enter Chart Label" class="form-control" id="chart_label">
							<small class="text-danger">Test 1, Test 2, Test 3 ....</small>
						</div>
					</div>
					<div class="form-group">
						<label for="is_status">Status<span class="text-danger">*</span></label>
						<select class="form-control" name="is_status" id="is_status">
							<option value="">Select Status</option>
							<option value="1">Active</option>
							<option value="0">InActive</option>
						</select>
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light spin-button" type="submit">Submit</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	<script>
		$('#addStrategyModal').submit(function(event) {
			event.preventDefault();
			
			$(this).find('button').prop('disabled', true);
			$(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
			
			var formData = new FormData(this);
			formData.append('_token', "{{csrf_token()}}");
			
			$.ajax({
				async: true,
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: formData,
				cache: false,
				processData: false,
				contentType: false,
				dataType: 'Json',
				success: function(res) {
					$('#addStrategyModal').find('button').prop('disabled', false);
					$('#addStrategyModal').find('button.spin-button').removeClass('loading').html('Save');
					if (res.status == "error") {
						toastrMsg(res.status, res.msg);
						} else if (res.status == "validation") {
						$('.error').remove();
						$.each(res.errors, function(key, value) {
							var inputField = $('#' + key);
							var errorSpan = $('<span>')
							.addClass('error text-danger')
							.attr('id', key + 'Error')
							.text(value[0]);
							inputField.parent().append(errorSpan);
						});
						} else {
						toastrMsg(res.status, res.msg);
						$('#add_strategy_modal').modal('hide');
						$('#add_strategy_modal').remove();
						$('.modal-backdrop').remove();
						$('body').css({
							'overflow': 'auto'
						});
						DataTable.draw();
					}
				}
			});
		});
	</script>
</div>
