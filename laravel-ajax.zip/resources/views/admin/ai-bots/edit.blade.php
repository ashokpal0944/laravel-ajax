
<div class="modal fade" id="edit_ai_bots_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Edit Ai Bots</h4>
			</div>
			<div class="modal-body">
				<form id="editAiBotsModal" class="parsley-examples" action="{{ url('admin/ai-bots/edit',$get_ai_bots->id) }}" method="post">
					@csrf
					
					<div class="form-group">
						<label for="currency_type">Currency Type<span class="text-danger">*</span></label>
						<select class="form-control" name="currency_type" id="currency_type">
							<option value="">Select Currency Type</option>
							<option value="Forex" {{ $get_ai_bots->currency_type == "Forex" ? 'selected' : '' }}>Forex</option>
							<option value="Crypto" {{ $get_ai_bots->currency_type == "Crypto" ? 'selected' : '' }}>Crypto</option>
							<option value="Stock" {{ $get_ai_bots->currency_type == "Stock" ? 'selected' : '' }}>Stock</option>
						</select>
					</div>
					<div class="form-group">
						<label for="risk_type">Risk Type<span class="text-danger">*</span></label>
						<select class="form-control" name="risk_type" id="risk_type">
							<option value="">Select Risk Type</option>
							<option value="High" {{ $get_ai_bots->risk_type == "High" ? 'selected' : '' }}>High</option>
							<option value="Low" {{ $get_ai_bots->risk_type == "Low" ? 'selected' : '' }}>Low</option>
							<option value="Medium" {{ $get_ai_bots->risk_type == "Medium" ? 'selected' : '' }}>Medium</option>
						</select>
					</div>
					<div class="form-group">
						<label for="title">Title<span class="text-danger">*</span></label>
						<input type="text" name="title" parsley-trigger="change" required placeholder="Enter Title" class="form-control" id="title" value="{{ $get_ai_bots->title }}">
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="image">Icon<span class="text-danger">*</span></label>
							<input type="file" name="icon" parsley-trigger="change"  class="form-control" id="icon">
						</div>
						<div class="col-lg-6">
							<img src="{{ url('public/storage/'.$get_ai_bots->icon) }}" class="img-fluid mt-2" width="100px"/>
						</div>
					</div>
					
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="min_amount">Min Amount<span class="text-danger">*</span></label>
							<input type="text" name="min_amount" parsley-trigger="change" required placeholder="Enter Min Amount" class="form-control" id="min_amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ $get_ai_bots->min_amount }}">
						</div>
						<div class="col-lg-6">
							<label for="max_amount">Max Amount<span class="text-danger">*</span></label>
							<input type="text" name="max_amount" parsley-trigger="change" required placeholder="Enter Max Amount" class="form-control" id="max_amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  value="{{ $get_ai_bots->max_amount }}">
						</div>
					</div>
					<div class="form-group">
						<label for="yearly_return">Yearly Return Pencentage<span class="text-danger">*</span></label>
						<input type="text" name="yearly_return" parsley-trigger="change" required placeholder="Enter Yearly Return Pencentage" class="form-control" id="yearly_return" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ $get_ai_bots->yearly_return }}">
					</div>
					<div class="form-group">
						<label for="description">Description</label>
						<textarea name="description" id="description" rows="10" class="form-control">{{ $get_ai_bots->description }}</textarea>
					</div>
					
					<div class="form-group">
						<label for="is_status">Status<span class="text-danger">*</span></label>
						<select class="form-control" name="is_status" id="is_status">
							<option value="">Select Status</option>
							<option value="1" {{ $get_ai_bots->is_status == 1 ? 'selected' : '' }}>Active</option>
							<option value="0" {{ $get_ai_bots->is_status == 0 ? 'selected' : '' }}>InActive</option>
						</select>
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light spin-button" type="submit">Submit</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	
	<script>
        $('#editAiBotsModal').submit(function(event) {
			event.preventDefault();
			
			// Update the textarea value with CKEditor content
			const data = descriptionEditor.getData();
			$('#description').val(data);
			
			$(this).find('button').prop('disabled', true);
			$(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
			
			var formData = new FormData(this);
			formData.append('_token', "{{csrf_token()}}");
			
			$.ajax({
				async: true,
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: formData,
				cache: false,
				processData: false,
				contentType: false,
				dataType: 'Json',
				success: function(res) {
					$('#editAiBotsModal').find('button').prop('disabled', false);
					$('#editAiBotsModal').find('button.spin-button').removeClass('loading').html('Save');
					if (res.status == "error") {
						toastrMsg(res.status, res.msg);
						} else if (res.status == "validation") {
						$('.error').remove();
						$.each(res.errors, function(key, value) {
							var inputField = $('#' + key);
							var errorSpan = $('<span>')
							.addClass('error text-danger')
							.attr('id', key + 'Error')
							.text(value[0]);
							inputField.parent().append(errorSpan);
						});
						} else {
						toastrMsg(res.status, res.msg);
						$('#edit_ai_bots_modal').modal('hide');
						$('#edit_ai_bots_modal').remove();
						$('.modal-backdrop').remove();
						$('body').css({
							'overflow': 'auto'
						});
						DataTable.draw();
					}
				}
			});
		});
	</script>
</div>
