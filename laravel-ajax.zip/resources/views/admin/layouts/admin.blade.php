<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>@yield('title','Clarus Ventures')</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="{{ url('storage/' . config('setting.fevicon_icon')) }}">
        <!-- App css -->
		
		
		<link href="{{url('admin/libs/datatables/dataTables.bootstrap4.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{url('admin/libs/datatables/buttons.bootstrap4.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{url('admin/libs/datatables/responsive.bootstrap4.css') }}" rel="stylesheet" type="text/css" />
		
		<link href="{{url('admin/libs/sweetalert2/sweetalert2.min.css') }}" rel="stylesheet" type="text/css" />
		<link href="{{url('admin/libs/jquery-toast/jquery.toast.min.css') }}" rel="stylesheet" type="text/css" />
		
		<link href="{{url('admin/libs/bootstrap-tagsinput/bootstrap-tagsinput.css') }}" rel="stylesheet" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css">
		
		<link href="{{url('admin/libs/select2/select2.min.css') }}" rel="stylesheet" type="text/css" />
		
        <link href="{{url('admin/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{url('admin/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{url('admin/css/app.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{url('admin/css/style.css') }}" rel="stylesheet" type="text/css" />
	</head>
    <body>
        <!-- Begin page -->
        <div id="wrapper">
            <!-- Topbar Start -->
			@include('admin.layouts.admin_partials.topbar')
            <!-- end Topbar -->
            <!-- ========== Left Sidebar Start ========== -->
			@include('admin.layouts.admin_partials.left-sidebar')
            <!-- Left Sidebar End -->
            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
				@yield('content')
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                2017 - 2019 &copy; Abstack theme by <a href="">Coderthemes</a>
							</div>
						</div>
					</div>
				</footer>
                <!-- end Footer -->
			</div>
            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->
		</div>
        <!-- END wrapper -->
        
        <!-- /Right-bar -->
        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>
        <!-- Vendor js -->
        <script src="{{url('admin/js/vendor.min.js') }}"></script>
		<!-- Chart JS -->
		<script src="{{url('admin/libs/chart-js/Chart.bundle.min.js') }}"></script>
		
		<script src="{{url('admin/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js') }}"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.min.js"></script>
        <script src="{{url('admin/libs/select2/select2.min.js') }}"></script>
		
		<script src="{{url('admin/libs/datatables/jquery.dataTables.min.js') }}"></script>
		<script src="{{url('admin/libs/datatables/dataTables.bootstrap4.min.js') }}"></script>
		<!-- Buttons examples -->
		<script src="{{url('admin/libs/datatables/dataTables.buttons.min.js') }}"></script>
		<script src="{{url('admin/libs/datatables/buttons.bootstrap4.min.js') }}"></script>
		<script src="{{url('admin/libs/jszip/jszip.min.js') }}"></script>
		<script src="{{url('admin/libs/pdfmake/pdfmake.min.js') }}"></script>
		<script src="{{url('admin/libs/pdfmake/vfs_fonts.js') }}"></script>
		<script src="{{url('admin/libs/datatables/buttons.html5.min.js') }}"></script>
		<script src="{{url('admin/libs/datatables/buttons.print.min.js') }}"></script>
		
		<!-- Responsive examples -->
		<script src="{{url('admin/libs/datatables/dataTables.responsive.min.js') }}"></script>
		<script src="{{url('admin/libs/datatables/responsive.bootstrap4.min.js') }}"></script>
		
		<!-- Datatables init -->
		<script src="{{url('admin/js/pages/datatables.init.js') }}"></script>
		
		<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
		
		<!-- Init js -->
        <script src="{{url('admin/js/pages/dashboard.init.js') }}"></script>
		
		<script src="{{url('admin/libs/sweetalert2/sweetalert2.min.js') }}"></script>
		
		<script src="{{url('admin/libs/jquery-toast/jquery.toast.min.js') }}"></script>
		
		<script src="{{url('admin/js/pages/form-advanced.init.js') }}"></script>
        <!-- App js -->
        <script src="{{url('admin/js/app.min.js') }}"></script>
		<script>
            let modalOpen = false;
            function closemodal()
            {
                setTimeout(function()
                {
                    modalOpen = false;
				},1000)
			}
			
			function toastrMsg(type,msg)
			{
				$.toast({
					text: msg, 
					position: "top-right",
					loaderBg: "#da8609",
					icon: type,
					hideAfter: 3e3,
					stack: 1
				})
			}
		</script>
		@stack('js')
		
		<div id="modal-view-render"> </div> 
	</body>
</html>