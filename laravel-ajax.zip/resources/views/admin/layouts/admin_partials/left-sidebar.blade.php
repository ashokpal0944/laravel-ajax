<div class="left-side-menu">
	<div class="slimscroll-menu">
		<!--- Sidemenu -->
		<div id="sidebar-menu">
			<ul class="metismenu" id="side-menu">
				<li class="menu-title">Navigation</li>
				<li>
					<a href="{{ url('admin/dashboard') }}">
						<i class="fe-airplay"></i>
						<span> Dashboard </span>
					</a>
				</li>
				<li>
					<a href="javascript: void(0);">
						<i class="fe-box"></i>
						<span> User </span>
						<span class="menu-arrow"></span>
					</a>
					<ul class="nav-second-level" aria-expanded="false">
						<li><a href="{{ url('admin/user/list') }}">User List</a></li>
						<li><a href="{{ url('admin/user/kyc/list') }}">User KYC</a></li>
					</ul>
				</li>
				<li>
					<a href="{{ url('admin/user/premium-subscription/list') }}">
						<i class="fe-briefcase"></i>
						<span>Premium Subscription List</span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/user/deposit/list') }}">
						<i class="fe-briefcase"></i>
						<span>Deposit List</span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/user/withdrawal/list') }}">
						<i class="fe-briefcase"></i>
						<span>Withdrawal List</span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/user/purchase/list') }}">
						<i class="fe-briefcase"></i>
						<span>Purchase List</span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/ai-bots/purchase/list') }}">
						<i class="fe-briefcase"></i>
						<span>Ai Bot Purchase List</span>
					</a>
				</li>
				<li>
					<a href="javascript: void(0);">
						<i class="fe-briefcase"></i>
						<span>User Investment </span>
						<span class="menu-arrow"></span>
					</a>
					<ul class="nav-second-level" aria-expanded="false">
						<li><a href="{{ url('admin/user/investment/list') }}">Investment List</a></li>
						<li><a href="{{ url('admin/user/return-on-investment/list') }}">Return On investment</a></li>
					</ul>
				</li>
				<li>
					<a href="{{ url('admin/past-trade/list') }}">
						<i class="fe-briefcase"></i>
						<span> Past Traded </span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/live-trade/list') }}">
						<i class="fe-briefcase"></i>
						<span> Live Traded </span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/news/list') }}">
						<i class="fe-briefcase"></i>
						<span> News </span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/investment-plan/list') }}">
						<i class="fe-briefcase"></i>
						<span> Investment Plan  </span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/video/list') }}">
						<i class="fe-briefcase"></i>
						<span> Video List  </span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/stock-buzz/list') }}">
						<i class="fe-briefcase"></i>
						<span> Stock Buzz  </span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/top-category/list') }}">
						<i class="fe-briefcase"></i>
						<span> Top Category  </span>
					</a>
				</li>
				<li>
					<a href="{{ url('admin/setting') }}">
						<i class="fe-settings noti-icon"></i>
						<span> Setting </span>
					</a>
				</li>
				<li>
					<a href="javascript: void(0);">
						<i class="fe-box"></i>
						<span> Education </span>
						<span class="menu-arrow"></span>
					</a>
					<ul class="nav-second-level" aria-expanded="false">
						<li><a href="{{ url('admin/trading/list') }}">Trading</a></li>
						<li><a href="{{ url('admin/rehab/list') }}">Rehab</a></li>
						<li><a href="{{ url('admin/business/list') }}">Business</a></li>
					</ul>
				</li>
				<li>
					<a href="{{ url('admin/ai-bots/list') }}">
						<i class="fe-settings noti-icon"></i>
						<span> AI & Bots </span>
					</a>
				</li>
			</ul>
		</div>
		<!-- End Sidebar -->
		<div class="clearfix"></div>
	</div>
	<!-- Sidebar -left -->
</div>