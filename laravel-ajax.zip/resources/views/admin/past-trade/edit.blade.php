
<div class="modal fade" id="edit_past_trade_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Edit Past Trade</h4>
			</div>
			<div class="modal-body">
				<form id="editPastTradeModal" class="parsley-examples" action="{{ url('admin/past-trade/edit',$get_past_trade->id) }}" method="post">
					@csrf
					<div class="form-group">
						<label for="icon">Icon<span class="text-danger">*</span></label>
						<input type="file" name="icon" parsley-trigger="change" class="form-control" id="icon">
						<img src="{{ url('public/storage/'.$get_past_trade->icon) }}" class="img-fluid " width="100px"/>
					</div>
					<div class="form-group">
						<label for="title">Title<span class="text-danger">*</span></label>
						<input type="text" name="title" parsley-trigger="change" required placeholder="Enter Title" class="form-control" id="title" value="{{ $get_past_trade->title }}">
					</div>
					<div class="form-group">
						<label for="Sub Title">Sub Title<span class="text-danger">*</span></label>
						<input id="sub_title" type="text" placeholder="Enter Sub Title" name="sub_title" required class="form-control" value="{{ $get_past_trade->sub_title }}">
					</div>
					<div class="form-group">
						<label for="trade_percentage">Trade Percentage<span class="text-danger">*</span></label>
						<input type="text" name="trade_percentage" parsley-trigger="change" required placeholder="Enter Trade Percentage" class="form-control" id="trade_percentage" value="{{ $get_past_trade->trade_percentage }}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light" type="submit">
							Submit
						</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">
							Cancel
						</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	<script>
	$('#editPastTradeModal').submit(function(event) {
        event.preventDefault();
        $(this).find('button').prop('disabled', true);
        $(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
        var formData = new FormData(this);
        formData.append('_token', "{{csrf_token()}}");
        $.ajax({
            async: true,
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            dataType: 'Json',
            success: function(res) {
                $('#editPastTradeModal').find('button').prop('disabled', false);
                $('#editPastTradeModal').find('button.spin-button').removeClass('loading').html(
                'Save');
                if (res.status == "error") 
				{
                    toastrMsg(res.status, res.msg);
                } 
				else if(res.status == "validation")
				{
					$('.error').remove();  
					$.each(res.errors, function(key, value) {
						var inputField = $('#' + key);
						var errorSpan = $('<span>')
						.addClass('error text-danger') 
						.attr('id', key + 'Error')
						.text(value[0]);  
						inputField.parent().append(errorSpan);
					});
				}
				else
				{
                    toastrMsg(res.status, res.msg);
                    $('#edit_past_trade_modal').modal('hide');
                    $('#edit_past_trade_modal').remove();
                    $('.modal-backdrop').remove();
                    $('body').css({
                        'overflow': 'auto'
                    });
                    DataTable.draw();
                }
            }
        });
    });
	</script>
</div>
