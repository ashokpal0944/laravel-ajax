@extends('admin.layouts.admin')
@section('title','News - '.config('setting.website_title'))
@section('content')
<div class="content">
	<!-- Start Content-->
	<div class="container-fluid">
		<!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box">
					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Home</a></li>
							<li class="breadcrumb-item active">News List</li>
						</ol>
					</div>
					<h4 class="page-title">News List</h4>
				</div>
			</div>
		</div>     
		<!-- end page title --> 
		<div class="row">
			<div class="col-12">
				<div class="card-box table-responsive">
					<div class="header-container">
						<h4 class="header-title"><b>News List Data</b></h4>
						<div class="right-align">
							<button href="javascript:void(0);" class="btn btn-primary waves-light waves-effect width-md" onclick="addNews()">Add News</button>
						</div>
					</div>
					<table id="news_list_data" class="table table-bordered  dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
						<thead>
							<tr>
								<th>#</th>
								<th>Image</th>
								<th>Title</th>
								<th>Trade Title</th>
								<th>Trade Percentage</th>
								<th>Status</th>
								<th>Created Date</th>
								<th>Action</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection	
@push('js')
<script>
	var DataTable = $('#news_list_data').DataTable({
		processing:true,
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': 'Loading...'
		},
		serverSide:true,
		bLengthChange: true,
		searching: true,
		bFilter: true,
		bInfo: true,
		iDisplayLength: 25,
		order: [[0, 'desc'] ],
		bAutoWidth: false,			 
		"ajax":{
			"url": "{{ url('admin/news/get-news-data-ajax') }}",
			"dataType": "json",
			"type": "POST",
			"data": function (d) {
				d._token   = "{{csrf_token()}}";
				d.search   = $('input[type="search"]').val(); 
				d.filter_name   = $('#filter_name').val(); 
				d.filter_card_number  = $('#filter_card_number').val(); 
				d.filter_status  = $('#filter_status').val(); 
				d.filter_from  = $('#filter_from').val(); 
				d.filter_to  = $('#filter_to').val(); 
			}
		},
		"columns": [
		{ "data": "id" },
		{ "data": "image" },
		{ "data": "title" },
		{ "data": "trade_title" },
		{ "data": "trade_percentage" },
		{ "data": "is_status" },
		{ "data": "created_at" },
		{ "data": "action" }
		]
	});
	
	function addNews()
	{
		if (!modalOpen) 
		{
			modalOpen = true;
			closemodal();
			$.get("{{ url('admin/news/add')}}", function(res) {
				$('body').find('#modal-view-render').html(res.view);
				$('#add_news_modal').modal('show');
			});
		}
	}
	
	function editNews(obj,event)
	{  
		event.preventDefault(); 
		if (!modalOpen)
		{
			modalOpen = true;
			closemodal();
			$.get(obj, function(res)
			{
				$('body').find('#modal-view-render').html(res.view); 
				$('#edit_news_modal').modal('show');  
			}); 
		}
	}
	
	function deleteNews(obj,event)
	{	 
		event.preventDefault();
		Swal.fire({
			title:"Are you sure?",
			text:"You won't be able to revert this!",
			type:"warning",
			showCancelButton:!0,
			confirmButtonColor:"#3085d6",
			cancelButtonColor:"#d33",
			confirmButtonText:"Yes, delete it!"
		}).then(function(t)
		{
			t.value&&
			
			$.post(obj,{_token:"{{csrf_token()}}"},function(res)
			{ 
				if(res.status == "error")
				{
					Swal.fire("Error!",res.msg,"error")
				}
				else
				{ 
					Swal.fire("Deleted!",res.msg,"success")
					 DataTable.draw();
				}
			});
		}) 
	}
</script>
@endpush