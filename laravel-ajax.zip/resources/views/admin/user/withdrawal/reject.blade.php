
<div class="modal fade" id="reject_withdrawal_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Withdrawal Request Reject</h4>
			</div>
			<div class="modal-body">
				<form id="rejectWithdrawalModal" class="parsley-examples" action="{{ url('admin/user/withdrawal/reject',$get_user_wallet->id) }}" method="post">
					@csrf
					<div class="form-group">
						<label for="name">Amount<span class="text-danger">*</span></label>
						<input type="text"  class="form-control" value="{{ $get_user_wallet->amount }}" disabled>
					</div>
					<div class="form-group">
						<label for="transaction_note">Rejected Note<span class="text-danger">*</span></label>
						<textarea type="text" name="transaction_note" class="form-control" id="transaction_note" required></textarea>
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light spin-button" type="submit">Submit</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	<script>
        $('#rejectWithdrawalModal').submit(function(event) {
			event.preventDefault();
			
			$(this).find('button').prop('disabled', true);
			$(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
			
			var formData = new FormData(this);
			formData.append('_token', "{{csrf_token()}}");
			
			$.ajax({
				async: true,
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: formData,
				cache: false,
				processData: false,
				contentType: false,
				dataType: 'Json',
				success: function(res) {
					$('#rejectWithdrawalModal').find('button').prop('disabled', false);
					$('#rejectWithdrawalModal').find('button.spin-button').removeClass('loading').html('Save');
					if (res.status == "error") {
						toastrMsg(res.status, res.msg);
						} else if (res.status == "validation") {
						$('.error').remove();
						$.each(res.errors, function(key, value) {
							var inputField = $('#' + key);
							var errorSpan = $('<span>')
							.addClass('error text-danger')
							.attr('id', key + 'Error')
							.text(value[0]);
							inputField.parent().append(errorSpan);
						});
						} else {
						toastrMsg(res.status, res.msg);
						$('#reject_withdrawal_modal').modal('hide');
						$('#reject_withdrawal_modal').remove();
						$('.modal-backdrop').remove();
						$('body').css({
							'overflow': 'auto'
						});
						DataTable.draw();
					}
				}
			});
		});
	</script>
</div>
