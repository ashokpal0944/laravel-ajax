@extends('admin.layouts.admin')
@section('title','User Withdrawal List - '.config('setting.website_title'))
@section('content')
<div class="content">
	<!-- Start Content-->
	<div class="container-fluid">
		<!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box">
					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Home</a></li>
							<li class="breadcrumb-item active">User Withdrawal List</li>
						</ol>
					</div>
					<h4 class="page-title">User Withdrawal List</h4>
				</div>
			</div>
		</div>     
		<!-- end page title --> 
		<div class="row">
			<div class="col-12">
				<div class="card-box table-responsive">
					<div class="header-container">
						<h4 class="header-title"><b>User Withdrawal List</b></h4>
					</div>
					<div class="row justify-content-center mb-2">
						<div class="col-lg-2">
							<select class="form-control select2" name="user_id" id="user_id">
								<option value=""> Select User </option>
								@foreach($get_users as $get_user)
									<option value="{{ $get_user->id }}">{{ $get_user->name }}</option>
								@endforeach
							</select>
						</div>
						<div class="col-lg-2">
							<select class="form-control" name="status" id="status">
								<option value=""> Select Status </option>
								<option value="0"> Pending</option>
								<option value="1"> Approved</option>
								<option value="2"> Rejected</option>
							</select>
						</div>
						<div>
							<button type="button" class="btn btn-primary" id="filter_data"> Filter </button>
							<a href="{{ url()->current() }}" class="btn btn-danger"> Reset </a>
						</div>
					</div>
					<table id="withdrawal_history_list_data" class="table table-bordered  dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
						<thead>
							<tr>
								<th>Id</th>
								<th>User Name</th>
								<th>Withdrawal Method</th>
								<th>Withdrawal Wallet / Bank Account</th>
								<th>Amount</th>
								<th>Transaction Id</th>
								<th>Transaction Image</th>
								<th>Status</th>
								<th>Created Date</th>
								<th>Action</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection	
@push('js')
<script>
	var DataTable = $('#withdrawal_history_list_data').DataTable({
		processing:true,
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': 'Loading...'
		},
		serverSide:true,
		bLengthChange: true,
		searching: true,
		bFilter: true,
		bInfo: true,
		iDisplayLength: 25,
		order: [[0, 'desc'] ],
		bAutoWidth: false,			 
		"ajax":{
			"url": "{{ url('admin/user/withdrawal/get-user-withdrawal-data-ajax') }}",
			"dataType": "json",
			"type": "POST",
			"data": function (d) {
				d._token   = "{{csrf_token()}}";
				d.search   = $('input[type="search"]').val(); 
				d.filter_name   = $('#filter_name').val(); 
				d.user_id   = $('#user_id').val(); 
				d.status   = $('#status').val(); 
			}
		},
		"columns": [
		{ "data": "id" },
		{ "data": "user_name" },
		{ "data": "transaction_method" },
		{ "data": "transaction_wallet_address" },
		{ "data": "amount" },
		{ "data": "transaction_id" },
		{ "data": "transaction_image" },
		{ "data": "is_status" },
		{ "data": "created_at" },
		{ "data": "action" }
		]
	});
	
	$("#filter_data").on('click', function() {
		// Assuming 'DataTable' is the instance of your DataTable
		DataTable.draw();
	});
	
	function approveWithdrawal(obj,event)
	{	 
		event.preventDefault();
		Swal.fire({
			title:"Are you sure?",
			text:"You want to approve the Withdrawal request.",
			type:"warning",
			showCancelButton:!0,
			confirmButtonColor:"#3085d6",
			cancelButtonColor:"#d33",
			confirmButtonText:"Yes, Approve it!"
		}).then(function(t)
		{
			t.value&&
			
			$.post(obj,{_token:"{{csrf_token()}}"},function(res)
			{ 
				if(res.status == "error")
				{
					Swal.fire("Error!",res.msg,"error")
				}
				else
				{ 
					Swal.fire("Approve!",res.msg,"success")
					 DataTable.draw();
				}
			});
		}) 
	}
	
	function rejectWithdrawalAmount(obj,event)
	{  
		event.preventDefault(); 
		if (!modalOpen)
		{
			modalOpen = true;
			closemodal();
			$.get(obj, function(res)
			{
				$('body').find('#modal-view-render').html(res.view); 
				$('#reject_withdrawal_modal').modal('show');  
			}); 
		}
	}
</script>
@endpush