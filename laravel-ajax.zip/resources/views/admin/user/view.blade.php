
<div class="modal fade" id="view_user_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">View User Details</h4>
			</div>
			<div class="modal-body">
				<form id="editUserData" class="parsley-examples" action="{{ url('admin/user/edit',$get_user->id) }}" method="post">
					@csrf
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="icon">Profile<span class="text-danger">*</span></label>
							@if($get_user->profile)
							<img src="{{ url('public/storage/'.$get_user->profile) }}" class="img-fluid " width="100px"/>
							@else
							<img src="{{ url('front/images/letter/'.strtolower(substr($get_user->name, 0, 1)).'.png') }}" class="img-fluid " width="100px"/>	
							@endif
						</div>
						<div class="col-lg-6">
							<label for="referral_code">Referral Code<span class="text-danger">*</span></label>
							<input type="text" parsley-trigger="change" class="form-control" value="{{ $get_user->referral_code }}" disabled>
						</div>
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="name">Name<span class="text-danger">*</span></label>
							<input type="text" class="form-control" value="{{ $get_user->name }}" disabled>
						</div>
						<div class="col-lg-6">
							<label for="username">User Name<span class="text-danger">*</span></label>
							<input id="username" type="text" class="form-control" value="{{ $get_user->username }}" disabled>
						</div>
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="email">Email<span class="text-danger">*</span></label>
							<input type="email" name="email" parsley-trigger="change" required  placeholder="Enter email" class="form-control" id="email" value="{{ $get_user->email }}">
						</div>
						<div class="col-lg-6">
							<label for="phone_number">Phone Number<span class="text-danger">*</span></label>
							<input id="phone_number" type="text" placeholder="Enter Phone Number" name="phone_number" required class="form-control" value="{{ $get_user->phone_number }}">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="dob">DOB</label>
							<input type="date" name="dob" parsley-trigger="change"  placeholder="Enter email" class="form-control" id="dob" value="{{ $get_user->dob }}" >
						</div>
						<div class="col-lg-6">
							<label for="occupation">Occupation<span class="text-danger">*</span></label>
							<input id="occupation" type="text" placeholder="Enter Occupation" name="occupation"  class="form-control" value="{{ $get_user->occupation }}" disabled>
						</div>
					</div>
					<div class="form-group row">
						<div class="col-lg-4">
							<label for="country_id">Country<span class="text-danger">*</span></label>
							<input type="text" name="country_id" parsley-trigger="change"  placeholder="Enter Country" class="form-control" id="country_id" value="{{ $get_user->country->name }}" disabled>
						</div>
						<div class="col-lg-4">
							<label for="state">State<span class="text-danger">*</span></label>
							<input id="state" type="text" placeholder="Enter State" name="state" class="form-control" value="{{ $get_user->state->name }}" disabled>
						</div>
						<div class="col-lg-4">
							<label for="City">City<span class="text-danger">*</span></label>
							<input id="City" type="text" placeholder="Enter City" name="City" class="form-control" value="{{ $get_user->city->name }}" disabled>
						</div>
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="email">Status<span class="text-danger">*</span></label>
							<select class="form-control select2" name="is_status" id="is_status">
								<option value="1" {{ $get_user->is_status == 1 ? 'selected' : ''}}>Active</option>
								<option value="0" {{ $get_user->is_status == 0 ? 'selected' : ''}}>InActive</option>
							</select>
						</div>
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light spin-button" type="submit">Submit</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>

<script>
        $('#editUserData').submit(function(event) {
			event.preventDefault();
			
			$(this).find('button').prop('disabled', true);
			$(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
			
			var formData = new FormData(this);
			formData.append('_token', "{{csrf_token()}}");
			
			$.ajax({
				async: true,
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: formData,
				cache: false,
				processData: false,
				contentType: false,
				dataType: 'Json',
				success: function(res) {
					$('#editUserData').find('button').prop('disabled', false);
					$('#editUserData').find('button.spin-button').removeClass('loading').html('Save');
					if (res.status == "error") {
						toastrMsg(res.status, res.msg);
						} else if (res.status == "validation") {
						$('.error').remove();
						$.each(res.errors, function(key, value) {
							var inputField = $('#' + key);
							var errorSpan = $('<span>')
							.addClass('error text-danger')
							.attr('id', key + 'Error')
							.text(value[0]);
							inputField.parent().append(errorSpan);
						});
						} else {
						toastrMsg(res.status, res.msg);
						$('#view_user_modal').modal('hide');
						$('#view_user_modal').remove();
						$('.modal-backdrop').remove();
						$('body').css({
							'overflow': 'auto'
						});
						DataTable.draw();
					}
				}
			});
		});
	</script>
