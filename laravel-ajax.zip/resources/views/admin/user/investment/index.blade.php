@extends('admin.layouts.admin')
@section('title','User Investment List - '.config('setting.website_title'))
@section('content')
<div class="content">
	<!-- Start Content-->
	<div class="container-fluid">
		<!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box">
					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Home</a></li>
							<li class="breadcrumb-item active">User Investment List</li>
						</ol>
					</div>
					<h4 class="page-title">User Investment List</h4>
				</div>
			</div>
		</div>     
		<!-- end page title --> 
		<div class="row">
			<div class="col-12">
				<div class="card-box table-responsive">
					<div class="header-container">
						<h4 class="header-title"><b>User Investment List</b></h4>
					</div>
					<table id="investment_history_list_data" class="table table-bordered  dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
						<thead>
							<tr>
								<th>Id</th>
								<th>User Name</th>
								<th>Investment Plan</th>
								<th>Investment Amount</th>
								<th>Status</th>
								<th>Created Date</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection	
@push('js')
<script>
	var DataTable = $('#investment_history_list_data').DataTable({
		processing:true,
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': 'Loading...'
		},
		serverSide:true,
		bLengthChange: true,
		searching: true,
		bFilter: true,
		bInfo: true,
		iDisplayLength: 25,
		order: [[0, 'desc'] ],
		bAutoWidth: false,			 
		"ajax":{
			"url": "{{ url('admin/user/investment/get-user-investment-data-ajax') }}",
			"dataType": "json",
			"type": "POST",
			"data": function (d) {
				d._token   = "{{csrf_token()}}";
				d.search   = $('input[type="search"]').val(); 
				d.filter_name   = $('#filter_name').val(); 
			}
		},
		"columns": [
		{ "data": "id" },
		{ "data": "user_name" },
		{ "data": "investment_plan" },
		{ "data": "investment_amount" },
		{ "data": "is_status" },
		{ "data": "created_at" }
		]
	});
	
	function approveDeposit(obj,event)
	{	 
		event.preventDefault();
		Swal.fire({
			title:"Are you sure?",
			text:"You want to approve the deposit request.",
			type:"warning",
			showCancelButton:!0,
			confirmButtonColor:"#3085d6",
			cancelButtonColor:"#d33",
			confirmButtonText:"Yes, Approve it!"
		}).then(function(t)
		{
			t.value&&
			
			$.post(obj,{_token:"{{csrf_token()}}"},function(res)
			{ 
				if(res.status == "error")
				{
					Swal.fire("Error!",res.msg,"error")
				}
				else
				{ 
					Swal.fire("Deleted!",res.msg,"success")
					 DataTable.draw();
				}
			});
		}) 
	}
	
	function rejectDepositAmount(obj,event)
	{  
		event.preventDefault(); 
		if (!modalOpen)
		{
			modalOpen = true;
			closemodal();
			$.get(obj, function(res)
			{
				$('body').find('#modal-view-render').html(res.view); 
				$('#reject_deposit_modal').modal('show');  
			}); 
		}
	}
</script>
@endpush