
<div class="modal fade" id="interest_pay_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Pay Return Of Interest</h4>
			</div>
			<div class="modal-body">
				<form id="PayReturnModal" class="parsley-examples" action="{{ url('admin/user/return-on-investment/pay-interest-amount') }}" method="post">
					@csrf
					<div class="form-group">
						<label for="total_return_of_interest">Total Return Of Interest (%)<span class="text-danger">*</span></label>
						<input type="text" name="total_return_of_interest" parsley-trigger="change" required placeholder="Enter Total Return Of Interest (%)" class="form-control" id="total_return_of_interest">
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light" type="submit">Submit</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	<script>
	$('#PayReturnModal').submit(function(event) {
        event.preventDefault();
        $(this).find('button').prop('disabled', true);
        $(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
        var formData = new FormData(this);
        formData.append('_token', "{{csrf_token()}}");
        $.ajax({
            async: true,
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            dataType: 'Json',
            success: function(res) {
                $('#PayReturnModal').find('button').prop('disabled', false);
                $('#PayReturnModal').find('button.spin-button').removeClass('loading').html(
                'Save');
                if (res.status == "error") 
				{
                    toastrMsg(res.status, res.msg);
                } 
				else if(res.status == "validation")
				{
					$('.error').remove();  
					$.each(res.errors, function(key, value) {
						var inputField = $('#' + key);
						var errorSpan = $('<span>')
						.addClass('error text-danger') 
						.attr('id', key + 'Error')
						.text(value[0]);  
						inputField.parent().append(errorSpan);
					});
				}
				else
				{
                    toastrMsg(res.status, res.msg);
                    $('#interest_pay_modal').modal('hide');
                    $('#interest_pay_modal').remove();
                    $('.modal-backdrop').remove();
                    $('body').css({
                        'overflow': 'auto'
                    });
                     DataTable.draw();
                }
            }
        });
    });
	</script>
</div>
