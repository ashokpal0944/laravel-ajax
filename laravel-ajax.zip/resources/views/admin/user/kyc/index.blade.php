@extends('admin.layouts.admin')
@section('title','User KYC List - '.config('setting.website_title'))
@section('content')
<div class="content">
	<!-- Start Content-->
	<div class="container-fluid">
		<!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box">
					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Home</a></li>
							<li class="breadcrumb-item active">User KYC List</li>
						</ol>
					</div>
					<h4 class="page-title">User KYC List</h4>
				</div>
			</div>
		</div>     
		<!-- end page title --> 
		<div class="row">
			<div class="col-12">
				<div class="card-box table-responsive">
					<div class="header-container">
						<h4 class="header-title"><b>User KYC List</b></h4>
					</div>
					<table id="user_kyc_list_data" class="table table-bordered  dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
						<thead>
							<tr>
								<th>#</th>
								<th>Name</th>
								<th>Aadhar Card Number</th>
								<th>Pan Card Number</th>
								<th>Bank Details</th>
								<th>KYC Status</th>
								<th>Created Date</th>
								<th>Action</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection	
@push('js')
<script>
	var DataTable = $('#user_kyc_list_data').DataTable({
		processing:true,
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': 'Loading...'
		},
		serverSide:true,
		bLengthChange: true,
		searching: true,
		bFilter: true,
		bInfo: true,
		iDisplayLength: 25,
		order: [[0, 'desc'] ],
		bAutoWidth: false,			 
		"ajax":{
			"url": "{{ url('admin/user/kyc/get-user-kyc-data-ajax') }}",
			"dataType": "json",
			"type": "POST",
			"data": function (d) {
				d._token   = "{{csrf_token()}}";
				d.search   = $('input[type="search"]').val(); 
				d.filter_name   = $('#filter_name').val(); 
			}
		},
		"columns": [
		{ "data": "id" },
		{ "data": "name" },
		{ "data": "aadhaar_number" },
		{ "data": "pancard_number" },
		{ "data": "bank_details" },
		{ "data": "kyc_status" },
		{ "data": "created_at" },
		{ "data": "action" }
		]
	});
	
	function editUserKycData(obj,event)
	{  
		event.preventDefault(); 
		if (!modalOpen)
		{
			modalOpen = true;
			closemodal();
			$.get(obj, function(res)
			{
				$('body').find('#modal-view-render').html(res.view); 
				$('#edit_user_kyc_modal').modal('show');  
			}); 
		}
	}
</script>
@endpush