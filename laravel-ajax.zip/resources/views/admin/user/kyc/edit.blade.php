@extends('admin.layouts.admin')
@section('title','Edit User KYC - '.config('setting.website_title'))
@section('content')
<style>
    .card-img-deta img {
    	width: 350px;
    	height: 250px;
    	object-fit: cover;
    	padding: 20px;
    }
    
    .card-img-deta {
    	display: block;
    }
</style>
<div class="content">
	<!-- Start Content-->
	<div class="container-fluid">
		<!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box">
					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Home</a></li>
							<li class="breadcrumb-item active">Edit User KYC</li>
						</ol>
					</div>
					<h4 class="page-title">Edit User KYC Data</h4>
				</div>
			</div>
		</div>     
		<!-- end page title --> 
		<div class="row">
			<div class="col-xl-12 main-content ps-xl-4 pe-xl-5">
				<div class="card-body">
					<h4 id="card-group">Pancard Details</h4>
					<div class="row">
						<div class="col-md-6">
							<div class="btn-group">
								@if($get_user_kyc->is_pancard != 1)
									<button type="button" class="btn btn-wide" onclick="approveChange('Pan Card','1');" style="background-color: #67CF94; color: #fff;"><i class="fa fa-arrow-right"></i>Approve</button> 
								@endif
								<button type="button" class="btn btn-wide" onclick="rejectChange('Pan Card','2');" style="background-color: #ff0000; color: #fff;"><i class="fa fa-times"></i>Reject</button>
							</div>
						</div>
						<div class="col-md-6">
							<h3>User Name:- {{ $get_user_kyc->user->name }}</h3>
						</div>
					</div>
					
					@if(!empty($get_user_kyc->is_pancard))
					@if($get_user_kyc->is_pancard == 0)
					<h4 id="card-group" style="color: #f00; font-size: 16px;">Pending</h4>
					@elseif($get_user_kyc->is_pancard == 1)
					<h4 id="card-group" style="color: #67CF94; font-size: 16px;">Approved</h4>
					@elseif($get_user_kyc->is_pancard == 2)
					<h4 id="card-group" style="color: #f00; font-size: 16px;">Reject</h4>
					@endif
					@endif  
					
					@if(!empty($get_user_kyc->is_pancard))
					@if($get_user_kyc->is_pancard == 2)
					<p class="mb-3" style="color: #f00;">{{ $get_user_kyc->pancard_note }}</p>
					@endif
					@endif
					<br/>
					<div class="card-group card-img-deta">
						<div class="card">
							<div class="card-body">
								<div class="mb-3">
									<label for="exampleInputEmail1" class="form-label">PANCARD NUMBER</label>
									<input type="text" class="form-control" value="<?php if(!empty($get_user_kyc->pancard_number)){ echo $get_user_kyc->pancard_number;} ?>"  disabled>
								</div>
							</div>
						</div>
						<div class="card">
							@if(!empty($get_user_kyc->pancard_image))
							<img id="preview_pancard_img" src="{{ url('public/storage/'.$get_user_kyc->pancard_image) }}" class="card-img-top" alt="...">
							@endif
						</div>
					</div>
				</div>
				
				<div class="card-body">
					<h4 id="card-group">Aadhaar Card Details</h4>
					<div class="row">
						<div class="col-md-8">
							<div class="btn-group">
								@if($get_user_kyc->is_aadhaar != 1)
									<button type="button" class="btn btn-wide"  onclick="approveChange('Aadhaar Card','1');" style="background-color: #67CF94; color: #fff;"><i class="fa fa-arrow-right"></i>Approve</button> 
								@endif
								<button type="button" class="btn btn-wide" onclick="rejectChange('Aadhaar Card','2');" style="background-color: #ff0000; color: #fff;"><i class="fa fa-times"></i>Reject</button>
							</div>
						</div>
					</div>
					@if(!empty($get_user_kyc->is_aadhaar))
					@if($get_user_kyc->is_aadhaar == 0)
					<h4 id="card-group" style="color: #f00; font-size: 16px;">Pending</h4>
					@elseif($get_user_kyc->is_aadhaar == 1)
					<h4 id="card-group" style="color: #67CF94; font-size: 16px;">Approved</h4>
					@elseif($get_user_kyc->is_aadhaar == 2)
					<h4 id="card-group" style="color: #f00; font-size: 16px;">Reject</h4>
					@endif
					@endif  
					
					@if(!empty($get_user_kyc->is_aadhaar))
					@if($get_user_kyc->is_aadhaar == 2)
					<p class="mb-3" style="color: #f00;">{{ $get_user_kyc->aadhaar_note }}</p>
					@endif
					@endif
					<br/>
					<p>Front & Back</p>
					<div class="card-group card-img-deta">
						<div class="card">
							<div class="card-body">
								<div class="mb-3">
									<label for="exampleInputEmail1" class="form-label">Aadhaar Card NUMBER</label>
									<input type="text" class="form-control"
									value="<?php if(!empty($get_user_kyc->aadhaar_number)){ echo $get_user_kyc->aadhaar_number;} ?>" disabled>
								</div>
							</div>
						</div>
						<div class="card">
    						<div class="adhar-multiple">
    							@if(!empty($get_user_kyc->aadhaar_front))
    							<img id="preview_front_document_img" src="{{ url('public/storage/'.$get_user_kyc->aadhaar_front) }}" class="card-img-top" alt="...">
    							@else
    							<img id="preview_front_document_img" src="{{ url('common/assets/images/others/placeholder.jpg') }}" class="card-img-top" alt="...">
    							@endif
    							
    							@if(!empty($get_user_kyc->aadhaar_back))
    							<img id="preview_back_document_img" src="{{ url('public/storage/'.$get_user_kyc->aadhaar_back) }}" class="card-img-top" alt="...">
    							@else
    							<img id="preview_back_document_img" src="{{ url('common/assets/images/others/placeholder.jpg') }}" class="card-img-top" alt="...">
							    @endif
						    </div> 
						</div> 
					</div>
				</div>
				<div class="card-body">
					<h4 id="card-group">Bank Details</h4>
					<div class="row">
						<div class="col-md-8">
							<div class="btn-group">
								@if($get_user_kyc->is_bank_account != 1)
									<button type="button" class="btn btn-wide" onclick="approveChange('Bank Account','1');" style="background-color: #67CF94; color: #fff;"><i class="fa fa-arrow-right"></i>Approve</button> 
								@endif
								<button type="button" class="btn btn-wide" onclick="rejectChange('Bank Account','2');" style="background-color: #ff0000; color: #fff;"><i class="fa fa-times"></i>Reject</button>
							</div>
						</div>
					</div>
					@if(!empty($get_user_kyc->is_bank_account))
					@if($get_user_kyc->is_bank_account == 0)
					<h4 id="card-group" style="color: #f00; font-size: 16px;">Pending</h4>
					@elseif($get_user_kyc->is_bank_account == 1)
					<h4 id="card-group" style="color: #67CF94; font-size: 16px;">Approved</h4>
					@elseif($get_user_kyc->is_bank_account == 2)
					<h4 id="card-group" style="color: #f00; font-size: 16px;">Reject</h4>
					@endif
					@endif  
					
					@if(!empty($get_user_kyc->is_bank_account))
					@if($get_user_kyc->is_bank_account == 2)
					<p class="mb-3" style="color: #f00;">{{ $get_user_kyc->bank_account_note }}</p>
					@endif
					@endif
					<br/>
					<div class="card-group">
						<div class="card">
							<div class="card-body">
								<div class="mb-3">
									<label for="exampleInputEmail1" class="form-label">BANK NAME</label>
									<input type="text" class="form-control" value="{{ $get_user_kyc->bank_name }}" disabled>
								</div>
								<div class="mb-3">
									<label for="exampleInputEmail1" class="form-label">BANK ACCOUNT NUMBER</label>
									<input type="text" class="form-control" value="{{ $get_user_kyc->account_number }}" disabled>
								</div>
								<div class="mb-3">
									<label for="exampleInputEmail1" class="form-label">BANK IFSC CODE </label>
									<input type="text" class="form-control" value="{{ $get_user_kyc->ifsc_code }}" disabled>
								</div>
								<div class="mb-3">
									<label for="exampleInputEmail1" class="form-label">BANK ACCOUNT TYPE </label>
									<input type="text" class="form-control" value="{{ $get_user_kyc->account_type }}" disabled>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Approve Document</h4>
			</div>
			<div class="modal-body">
				<form id="approveKYC" class="p-20" action="{{ url('admin/user/kyc/change-status') }}" method="POST">
					{{ csrf_field() }}
					<div class="modal-body">
						<div class="row">
							<div class="col-lg-12">
								<input type="hidden" name="statusname" id="statusname">
								<input type="hidden" name="code" id="code">
								<input type="hidden" name="id" value="<?php if(!empty($get_user_kyc)){ echo $get_user_kyc->id; }?>">
								<div class="form-group">
									<label>Note</label>
									<textarea type="text" class="form-control"
									value="" id="note" name="note"></textarea>
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div>
</div>

<div class="modal fade" id="rejectModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Reject Document</h4>
			</div>
			<div class="modal-body">
				<form id="rejectKYC" class="p-20" action="{{ url('admin/user/kyc/change-status') }}" method="POST">
					{{ csrf_field() }}
					<div class="modal-body">
						<div class="row">
							<div class="col-lg-12">
								<input type="hidden" name="statusname" id="statusname_reject">
								<input type="hidden" name="code" id="code_reject">
								<input type="hidden" name="id" value="<?php if(!empty($get_user_kyc)){ echo $get_user_kyc->id; }?>">
								<div class="form-group">
									<label>Note</label>
									<textarea type="text" class="form-control"
									value="" id="note" name="note"></textarea>
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div>
</div>

@endsection	
@push('js')
<script>
	function approveChange(status,code)
	{
		$('#statusname').val(status);
		$('#code').val(code);
		$('#approveModal').modal('show');
	}
	
	function rejectChange(status,code)
	{
		$('#statusname_reject').val(status);
		$('#code_reject').val(code);
		$('#rejectModal').modal('show');
	}
	
	$(document).ready(function () {
		function handleFormSubmission(formId) {
			$(formId).submit(function (event) {
				event.preventDefault();
				
				var $form = $(this);
				var $submitButton = $form.find('button');
				var $spinButton = $form.find('button.spin-button');
				
				// Disable the button and show loading spinner
				$submitButton.prop('disabled', true);
				$spinButton.addClass('loading').html('<span class="spinner"></span>');
				
				var formData = new FormData(this);
				formData.append('_token', "{{ csrf_token() }}");
				
				// Perform AJAX request
				$.ajax({
					async: true,
					type: $form.attr('method'),
					url: $form.attr('action'),
					data: formData,
					cache: false,
					processData: false,
					contentType: false,
					dataType: 'json',
					success: function (res) {
						$submitButton.prop('disabled', false);
						$spinButton.removeClass('loading').html('Save');
						
						if (res.status === "error") {
							toastrMsg(res.status, res.msg);
							} else if (res.status === "validation") {
							$('.error').remove(); // Clear previous error messages
							$.each(res.errors, function (key, value) {
								var inputField = $('#' + key);
								var errorSpan = $('<span>')
                                .addClass('error text-danger')
                                .attr('id', key + 'Error')
                                .text(value[0]);
								inputField.parent().append(errorSpan);
							});
							} else {
							toastrMsg(res.status, res.msg);
							$('body').css({ 'overflow': 'auto' });
							$('.error').remove();
							setTimeout(function () {
								location.reload();
							}, 3000);
						}
					}
				});
			});
		}
		
		// Attach the form submission handler to each form
		handleFormSubmission('#approveKYC');
		handleFormSubmission('#rejectKYC');
	});
</script>
@endpush