<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Admin - Login</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		
        <meta content="Clarus Ventures" name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
       <link rel="shortcut icon" href="{{ url('storage/' . config('setting.fevicon_icon')) }}">
        <!-- App css -->
        <link href="{{url('admin/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{url('admin/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{url('admin/css/app.min.css') }}" rel="stylesheet" type="text/css" />
	</head>
    <body class="authentication-bg bg-gradient">
		<div class="account-pages mt-5 pt-5 mb-5">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-md-8 col-lg-6 col-xl-5">
						<div class="card bg-pattern">
							<div class="card-body p-4">
								<div class="text-center w-75 m-auto">
									<a href="index.html">
										<span><img src="{{ url('storage/' . config('setting.logo')) }}" alt="" height="50"></span>
									</a>
									<h5 class="text-uppercase text-center font-bold mt-4">Sign In</h5>
								</div>
								<form method="POST" action="{{ url('admin/login-post') }}">
									@csrf
									<div class="form-group mb-3">
										<label for="emailaddress">Email address</label>
										<input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}"  autocomplete="email" autofocus>
										@error('email')
										<span class="invalid-feedback" role="alert">
											<strong>{{ $message }}</strong>
										</span>
										@enderror
									</div>
									<div class="form-group mb-3">
										<!--<a href="pages-recoverpw.html" class="text-muted float-right"><small>Forgot your password?</small></a>-->
										<label for="password">Password</label>
										<input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password"  autocomplete="current-password">
										@error('password')
										<span class="invalid-feedback" role="alert">
											<strong>{{ $message }}</strong>
										</span>
										@enderror
									</div>
									<!--<div class="form-group mb-3">
										<div class="custom-control custom-checkbox checkbox-success">
										<input type="checkbox" class="custom-control-input" id="checkbox-signin" checked>
										<label class="custom-control-label" for="checkbox-signin">Remember me</label>
										</div>
									</div>-->
									<div class="form-group mb-0 text-center">
										<button class="btn btn-gradient btn-block" type="submit"> Log In </button>
									</div>
								</form>
								<!--<div class="row mt-4">
									<div class="col-sm-12 text-center">
									<p class="text-muted mb-0">Don't have an account? <a href="pages-register.html" class="text-dark ml-1"><b>Sign Up</b></a></p>
									</div>
								</div>-->
							</div> <!-- end card-body -->
						</div>
						<!-- end card -->
					</div> <!-- end col -->
				</div>
				<!-- end row -->
			</div>
			<!-- end container -->
		</div>
		<!-- end page -->
        <!-- Vendor js -->
        <script src="{{url('admin/js/vendor.min.js') }}"></script>
        <!-- App js -->
        <script src="{{url('admin/js/app.min.js') }}"></script>
	</body>
</html>