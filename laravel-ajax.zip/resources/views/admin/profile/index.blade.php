@extends('admin.layouts.admin')

@section('title','Profile - '.config('setting.website_title'))

@section('content')
<div class="content">
	<!-- Start Content-->
	<div class="container-fluid">
		<!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box">
					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Home</a></li>
							<li class="breadcrumb-item active">Profile</li>
						</ol>
					</div>
					<h4 class="page-title">Update Profile</h4>
				</div>
			</div>
		</div>     
		<!-- end page title --> 
		<div class="row">
			<div class="col-lg-6">
				<div class="card-box">
					<h4 class="header-title">Update Profile</h4>
					<form id="updateProfile" class="parsley-examples" action="{{ url('admin/update-profile') }}" method="post">
						@csrf
						<div class="form-group">
							<label for="name">Name<span class="text-danger">*</span></label>
							<input type="text" name="name" parsley-trigger="change"  placeholder="Enter name" class="form-control" id="name" value="{{ auth()->guard('admin')->user()->name }}">
						</div>
						<div class="form-group">
							<label for="email">Email <span class="text-danger">*</span></label>
							<input type="email" name="email" parsley-trigger="change"  placeholder="Enter email" class="form-control" id="email" value="{{ auth()->guard('admin')->user()->email }}">
						</div>
						<div class="form-group">
							<label for="profile">Profile <span class="text-danger">*</span></label>
							<input type="file" name="profile" class="form-control" id="profile">
							
							@if(!empty(auth()->guard('admin')->user()->profile))
								<img src="{{ url('storage/' . auth()->guard('admin')->user()->profile) }}" alt="user-image" class="rounded-circle" style="width:100px">
							@endif
						</div>
						<div class="form-group">
							<label for="password">Password<span class="text-danger">*</span></label>
							<input id="password" type="password" name="password" placeholder="Password" class="form-control">
						</div>
						<div class="form-group text-right mb-0">
							<button class="btn btn-gradient waves-effect waves-light" type="submit">Submit</button>
							<button type="reset" class="btn btn-light waves-effect ml-1">Cancel</button>
						</div>
					</form>
				</div> <!-- end card-box -->
			</div>
		</div>
	</div>
</div>
@endsection	
@push('js')
<script>
	$('#updateProfile').submit(function(event) {
        event.preventDefault();
        $(this).find('button').prop('disabled', true);
        $(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
        var formData = new FormData(this);
        formData.append('_token', "{{csrf_token()}}");
        $.ajax({
            async: true,
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            dataType: 'Json',
            success: function(res) {
                $('#updateProfile').find('button').prop('disabled', false);
                $('#updateProfile').find('button.spin-button').removeClass('loading').html('Save');
				
                if (res.status == "error") 
				{
                    toastrMsg(res.status, res.msg);
                } 
				else if(res.status == "validation")
				{
					$('.error').remove();  
					$.each(res.errors, function(key, value) {
						var inputField = $('#' + key);
						var errorSpan = $('<span>')
						.addClass('error text-danger') 
						.attr('id', key + 'Error')
						.text(value[0]);  
						inputField.parent().append(errorSpan);
					});
				}
				else
				{
                    toastrMsg(res.status, res.msg);
                    setTimeout(function(){
					   window.location.reload(1);
					}, 3000);
                }
            }
        });
    });
	</script>
@endpush