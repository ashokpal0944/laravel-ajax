@extends('admin.layouts.admin')
@section('title','Rehab - '.config('setting.website_title'))
@section('content')
<div class="content">
	<!-- Start Content-->
	<div class="container-fluid">
		<!-- start page title -->
		<div class="row">
			<div class="col-12">
				<div class="page-title-box">
					<div class="page-title-right">
						<ol class="breadcrumb m-0">
							<li class="breadcrumb-item"><a href="{{ url('admin/dashboard') }}">Home</a></li>
							<li class="breadcrumb-item active">Rehab List</li>
						</ol>
					</div>
					<h4 class="page-title">Rehab List</h4>
				</div>
			</div>
		</div>     
		<!-- end page title --> 
		<div class="row">
			<div class="col-12">
				<div class="card-box table-responsive">
					<div class="header-container">
						<h4 class="header-title"><b>Rehab List Data </b></h4>
						<div class="right-align">
							<button href="javascript:void(0);" class="btn btn-primary waves-light waves-effect width-md" onclick="addRehab()">Add Rehab</button>
						</div>
					</div>
					<table id="rehab_list" class="table table-bordered  dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
						<thead>
							<tr>
								<th>#</th>
								<th>Image</th>
								<th>Courses</th>
								<th>Duration</th>
								<th>Price</th>
								<th>Description</th>
								<th>Status</th>
								<th>Created Date</th>
								<th>Action</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection	
@push('js')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-bs4.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-bs4.min.js"></script>
<script>

	function initializeEditor() {
		$('#description').summernote({
			height: 300, // Set editor height
			minHeight: null, // Set minimum height of editor
			maxHeight: null, // Set maximum height of editor
			focus: true // Set focus to editable area after initializing summernote
		});
	}
		
	var DataTable = $('#rehab_list').DataTable({
		processing:true,
		"language": {
			'loadingRecords': '&nbsp;',
			'processing': 'Loading...'
		},
		serverSide:true,
		bLengthChange: true,
		searching: true,
		bFilter: true,
		bInfo: true,
		iDisplayLength: 25,
		order: [[0, 'desc'] ],
		bAutoWidth: false,			 
		"ajax":{
			"url": "{{ url('admin/rehab/get-rehab-ajax') }}",
			"dataType": "json",
			"type": "POST",
			"data": function (d) {
				d._token   = "{{csrf_token()}}";
				d.search   = $('input[type="search"]').val(); 
				d.filter_name   = $('#filter_name').val(); 
			}
		},
		"columns": [
		{ "data": "id" },
		{ "data": "image" },
		{ "data": "courses" },
		{ "data": "duration" },
		{ "data": "package_price" },
		{ "data": "description" },
		{ "data": "is_status" },
		{ "data": "created_at" },
		{ "data": "action" }
		]
	});
	
	function addRehab()
	{
		if (!modalOpen) 
		{
			modalOpen = true;
			closemodal();
			$.get("{{ url('admin/rehab/add')}}", function(res) {
				$('body').find('#modal-view-render').html(res.view);
				initializeEditor();
				$('#add_rehab_modal').modal('show');
				$('input[data-role="tagsinput"]').tagsinput();
			});
		}
	}
	
	function editRehab(obj,event)
	{  
		event.preventDefault(); 
		if (!modalOpen)
		{
			modalOpen = true;
			closemodal();
			$.get(obj, function(res)
			{
				$('body').find('#modal-view-render').html(res.view); 
				initializeEditor();
				$('#edit_rehab_modal').modal('show');  
				$('input[data-role="tagsinput"]').tagsinput();
			}); 
		}
	}
	
	function deleteRehab(obj,event)
	{	 
		event.preventDefault();
		Swal.fire({
			title:"Are you sure?",
			text:"You won't be able to revert this!",
			type:"warning",
			showCancelButton:!0,
			confirmButtonColor:"#3085d6",
			cancelButtonColor:"#d33",
			confirmButtonText:"Yes, delete it!"
		}).then(function(t)
		{
			t.value&&
			
			$.post(obj,{_token:"{{csrf_token()}}"},function(res)
			{ 
				if(res.status == "error")
				{
					Swal.fire("Error!",res.msg,"error")
				}
				else
				{ 
					Swal.fire("Deleted!",res.msg,"success")
					 DataTable.draw();
				}
			});
		}) 
	}
</script>
@endpush