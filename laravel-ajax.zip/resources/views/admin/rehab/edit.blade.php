
<div class="modal fade" id="edit_rehab_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Edit Rehab</h4>
			</div>
			<div class="modal-body">
				<form id="editRehabModal" class="parsley-examples" action="{{ url('admin/rehab/edit',$get_rehab->id) }}" method="post">
					@csrf
					<div class="form-group">
						<label for="courses">Courses<span class="text-danger">*</span></label>
						<input type="text" name="courses" parsley-trigger="change" required placeholder="Enter courses" class="form-control" id="courses" data-role="tagsinput" value="{{ $get_rehab->courses }}">
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="image">Image<span class="text-danger">*</span></label>
							<input type="file" name="image" parsley-trigger="change"   class="form-control" id="image">
						</div>
						<div class="col-lg-6">
							<img src="{{ url('public/storage/'.$get_rehab->image) }}" class="img-fluid mt-2" width="100px"/>
						</div>
					</div>
					<div class="form-group">
						<label for="duration">Duration<span class="text-danger">*</span></label>
						<select class="form-control" name="duration" id="duration">
							<option value="">Select Duration</option>
							<option value="1 Month" {{ $get_rehab->duration == "1 Month" ? 'selected' : '' }}>1 Month</option>
							<option value="3 Month" {{ $get_rehab->duration == "3 Month" ? 'selected' : '' }}>3 Month</option>
							<option value="6 Month" {{ $get_rehab->duration == "6 Month" ? 'selected' : '' }}>6 Month</option>
							<option value="1 Year" {{ $get_rehab->duration == "1 Year" ? 'selected' : '' }}>1 Year</option>
							<option value="2 Year" {{ $get_rehab->duration == "2 Year" ? 'selected' : '' }}>2 Year</option>
						</select>
					</div>
					<div class="form-group">
						<label for="package_price">Package Price<span class="text-danger">*</span></label>
						<input type="text" name="package_price" parsley-trigger="change" required placeholder="Enter Package Price" class="form-control" id="package_price" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ $get_rehab->package_price }}">
					</div>
					<div class="form-group">
						<label for="description">Description <span class="text-danger">*</span></label>
						<textarea name="description" id="description" class="form-control"><?php echo $get_rehab->description; ?></textarea>
					</div>
					<div class="form-group">
						<label for="is_status">Status<span class="text-danger">*</span></label>
						<select class="form-control" name="is_status" id="is_status">
							<option value="">Select Status</option>
							<option value="1" {{ $get_rehab->is_status == 1 ? 'selected' : '' }}>Active</option>
							<option value="0" {{ $get_rehab->is_status == 0 ? 'selected' : '' }}>InActive</option>
						</select>
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light spin-button" type="submit">Submit</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	
	<script>
        $('#editRehabModal').submit(function(event) {
			event.preventDefault();
			
			$(this).find('button').prop('disabled', true);
			$(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
			
			var formData = new FormData(this);
			formData.append('_token', "{{csrf_token()}}");
			
			$.ajax({
				async: true,
				type: $(this).attr('method'),
				url: $(this).attr('action'),
				data: formData,
				cache: false,
				processData: false,
				contentType: false,
				dataType: 'Json',
				success: function(res) {
					$('#editRehabModal').find('button').prop('disabled', false);
					$('#editRehabModal').find('button.spin-button').removeClass('loading').html('Save');
					if (res.status == "error") {
						toastrMsg(res.status, res.msg);
						} else if (res.status == "validation") {
						$('.error').remove();
						$.each(res.errors, function(key, value) {
							var inputField = $('#' + key);
							var errorSpan = $('<span>')
							.addClass('error text-danger')
							.attr('id', key + 'Error')
							.text(value[0]);
							inputField.parent().append(errorSpan);
						});
						} else {
						toastrMsg(res.status, res.msg);
						$('#edit_rehab_modal').modal('hide');
						$('#edit_rehab_modal').remove();
						$('.modal-backdrop').remove();
						$('body').css({
							'overflow': 'auto'
						});
						DataTable.draw();
					}
				}
			});
		});
	</script>
</div>
