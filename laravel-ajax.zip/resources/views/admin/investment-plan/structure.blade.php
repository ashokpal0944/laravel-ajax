<style>
    .structure-deta {
    	display: flex;
    	flex-direction: column;
    	row-gap: 10px;
    }
    
    .form-group.row {
    	border: 1px solid #dee2e6;
    	padding: 15px 5px;
    	margin-left: 0;
    	margin-right: 0;
    	align-items: center;
    }
</style>
<div class="modal fade" id="add_investment_plan_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myLargeModalLabel">Investment Plan Structure</h4>
			</div>
			<div class="modal-body">
				<form id="addInvestmentPlanModal" class="parsley-examples" action="{{ url('admin/investment-plan/investment-structure') }}" method="post">
					@csrf
					<h2 class="text-center mb-4" style="color: #333333;">100% Fund</h2>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="silver_bonds">Silver Bonds / Gold Bonds<span class="text-danger">*</span></label>
							<input type="text" name="silver_bonds" parsley-trigger="change" required placeholder="Enter Sliver Bonds Percentage" class="form-control" id="silver_bonds" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.silver_bonds') }}">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="real_estate">Real Estate Business<span class="text-danger">*</span></label>
							<input type="text" name="real_estate" parsley-trigger="change" required placeholder="Enter Real Estates Percentage" class="form-control" id="real_estate"oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.real_estate') }}">
						</div>
        				<div class="col-lg-6">
						    <div class="structure-deta">
								<label for="residential"  style="margin-bottom: -0.5rem !important;">Residential<span class="text-danger">*</span></label>
    							<input type="text" name="residential" parsley-trigger="change" required placeholder="Enter Residential Percentage" class="form-control" id="residential" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.residential') }}" >
								<label for="commercial" style="margin-bottom: -0.5rem !important;">Commercial<span class="text-danger">*</span></label>
    							<input type="text" name="commercial" parsley-trigger="change" required placeholder="Enter Commercial Percentage" class="form-control" id="commercial" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.commercial') }}">
						    </div>
					    </div>
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="startup_investment">Startup Investing<span class="text-danger">*</span></label>
							<input type="text" name="startup_investment" parsley-trigger="change" required placeholder="Enter Startup Investing Percentage" class="form-control" id="startup_investment" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.startup_investment') }}">
						</div>
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="stock_investment">Stocks Cryptocurrency<span class="text-danger">*</span></label>
							<input type="text" name="stock_investment" parsley-trigger="change" required placeholder="Enter Stock Investment Percentage" class="form-control" id="stock_investment" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.stock_investment') }}">
						</div>
						<div class="col-lg-6">
						    <div class="structure-deta">
								<label for="stock_equity" style="margin-bottom: -0.5rem !important;">Equity<span class="text-danger">*</span></label>
    							<input type="text" name="stock_equity" parsley-trigger="change" required placeholder="Enter Stocks Equity Percentage" class="form-control" id="stock_equity" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.stock_equity') }}">
								
								<label for="stock_assets" style="margin-bottom: -0.5rem !important;">Assets<span class="text-danger">*</span></label>
    							<input type="text" name="stock_assets" parsley-trigger="change" required placeholder="Enter Stocks Assets Percentage" class="form-control" id="stock_assets" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.stock_assets') }}">
						    </div>
					    </div>
					</div>
					<div class="form-group row">
						<div class="col-lg-6">
							<label for="trading_investment">Trading Investment<span class="text-danger">*</span></label>
							<input type="text" name="trading_investment" parsley-trigger="change" required placeholder="Enter Trading Investment Percentage" class="form-control" id="trading_investment" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.trading_investment') }}">
						</div>
						<div class="col-lg-6">
						    <div class="structure-deta">
								<label for="forex" style="margin-bottom: -0.5rem !important;">Forex<span class="text-danger">*</span></label>
    							<input type="text" name="forex" parsley-trigger="change" required placeholder="Enter Sliver bonds Percentage" class="form-control" id="forex" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.forex') }}">
								
								<label for="crypto" style="margin-bottom: -0.5rem !important;">Crypto<span class="text-danger">*</span></label>
    							<input type="text" name="crypto" parsley-trigger="change" required placeholder="Enter Sliver bonds Percentage" class="form-control" id="crypto" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.crypto') }}">
								
								<label for="stock" style="margin-bottom: -0.5rem !important;">Stock<span class="text-danger">*</span></label>
    							<input type="text" name="stock" parsley-trigger="change" required placeholder="Enter Sliver bonds Percentage" class="form-control" id="stock" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.stock') }}">
						    </div>
					    </div>
					</div>
					<div class="form-group row align-items-end">
						<div class="col-lg-6">
							<label for="reserve_fund">Reserve Fund<span class="text-danger">*</span></label>
							<input type="text" name="reserve_fund" parsley-trigger="change" required placeholder="Enter Reserve Fund Percentage" class="form-control" id="reserve_fund" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" value="{{ config('setting.reserve_fund') }}">
						</div>
					</div>
					<div class="form-group text-right mb-0">
						<button class="btn btn-gradient waves-effect waves-light" type="submit">Submit</button>
						<button type="button" class=" btn btn-light waves-effect ml-1" data-dismiss="modal" aria-hidden="true">Cancel</button>
					</div>
				</form>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
	<script>
	$('#addInvestmentPlanModal').submit(function(event) {
        event.preventDefault();
        $(this).find('button').prop('disabled', true);
        $(this).find('button.spin-button').addClass('loading').html('<span class="spinner"></span>');
        var formData = new FormData(this);
        formData.append('_token', "{{csrf_token()}}");
        $.ajax({
            async: true,
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            dataType: 'Json',
            success: function(res) {
                $('#addInvestmentPlanModal').find('button').prop('disabled', false);
                $('#addInvestmentPlanModal').find('button.spin-button').removeClass('loading').html('Save');
				
                if (res.status == "error") 
				{
                    toastrMsg(res.status, res.msg);
                } 
				else if(res.status == "validation")
				{
					$('.error').remove();  
					$.each(res.errors, function(key, value) {
						var inputField = $('#' + key);
						var errorSpan = $('<span>')
						.addClass('error text-danger') 
						.attr('id', key + 'Error')
						.text(value[0]);  
						inputField.parent().append(errorSpan);
					});
				}
				else
				{
                    toastrMsg(res.status, res.msg);
                    $('#add_investment_plan_modal').modal('hide');
                    $('#add_investment_plan_modal').remove();
                    $('.modal-backdrop').remove();
                    $('body').css({
                        'overflow': 'auto'
                    });
                    DataTable.draw();
                }
            }
        });
    });
	</script>
</div>
