<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Tymon\JWTAuth\Exceptions\JWTException;
	use Symfony\Component\HttpFoundation\Response;
	use Illuminate\Validation\Rule;
	use App\Models\User; 
	use App\Models\InvestmentPlan; 
	use App\Models\UserInvestment; 
	use App\Models\UserInvestmentBifurcation; 
	use App\Models\UserInvestmentBifurcationChild; 
	use App\Models\UserWallet; 
	
	use Auth, JWTAuth, Validator, DB, Helper, Storage;
	
	class InvestmentController extends Controller
	{
		public function getInvestmentPlans()
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				$get_investment_plan =  InvestmentPlan::where('is_status',1)->get();
				
				$is_investment_plan = UserInvestment::where('user_id', $user->id)->where('is_status', 1)->where('is_payable', 0)->exists() ? 1 : 0;
				
				return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'is_investment_plan' => $is_investment_plan, 'data' => $get_investment_plan]);
			}
		}
		
		public function getInvestmentPlansHistory()
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				$get_user_investment = UserInvestment::select('user_investments.*','investment_plans.plan_name')
				->join('investment_plans', 'investment_plans.id', '=', 'user_investments.investment_plan_id')
				->orderBy('user_investments.id','DESC')
				->where('user_investments.user_id', $user->id)
				->get();
				
				return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'data' => $get_user_investment]);
			}
		}
		
		public function getInvestmentReturnOfInterest()
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				$get_user_investments = UserInvestment::with([
				'investmentPlan:id,plan_name,investment_amount',
				'user:id,name',
				'returnInterest'])
				->withSum('returnInterest', 'total_return_of_interest')
				->where('user_id', $user->id)
				->where('is_status', 1)
				->get();
				
				return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'data' => $get_user_investments]);
			}
		}
		
		public function payInvestmentAmount(Request $request)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				try 
				{
					DB::beginTransaction();
					
					$investment_plan_id = $request->input('investment_plan_id');
					$currentTime = now();
					
					$get_investment_plans = InvestmentPlan::where('id', $investment_plan_id)->where('is_status', 1)->first();
					
					if (!$get_investment_plans) {
						return response()->json(['status' => false, 'message' => 'The selected investment plan is not available.']);
					}
					
					if ($user->wallet_balance < $get_investment_plans->investment_amount) 
					{
						return response()->json(['status' => false, 'message' => "Your wallet balance is insufficient for the investment amount of '{$get_investment_plans->investment_amount}'."]);
					}
					
					$return_on_investment = config("setting.return_on_investment");
					$estimated_time = config("setting.estimated_time");
					
					$investment_amount = $get_investment_plans->investment_amount;
					$total_recived_amount = ($investment_amount * $return_on_investment) / 100;
					
					$data = [
					'user_id' => $user->id,
					'investment_plan_id' => $get_investment_plans->id,
					'investment_amount' => $investment_amount,
					'return_on_investment' => $return_on_investment,
					'estimated_time' => $estimated_time,
					'total_recived_amount' => $total_recived_amount,
					'created_at' => $currentTime,
					'updated_at' => $currentTime,
					];
					
					// Save UserInvestment data
					$userInvestment = new UserInvestment();
					Helper::saveData($userInvestment, $data);
					$user_investment_id = $userInvestment->id;
					
					$dataBifurcation = $this->calculateBifurcation($user_investment_id, $investment_amount, $currentTime);
					
					$userInvestmentBifer = new  UserInvestmentBifurcation();
					Helper::saveData($userInvestmentBifer, $dataBifurcation);
					$user_investment_bifurcation_id = $userInvestmentBifer->id;
					
					$dataBifurcationChild = $this->calculateBifurcationChild($user_investment_bifurcation_id,$dataBifurcation['real_estate_amount'], $dataBifurcation['stock_investment_amount'], $dataBifurcation['trading_investment_amount'], $currentTime);
					
					$userInvestmentBiferChild = new  UserInvestmentBifurcationChild();
					Helper::saveData($userInvestmentBiferChild, $dataBifurcationChild);
					
					// Prepare data for UserWallet
					$uw_data = [
					'user_id' => $user->id,
					'transaction_method' => 'Investment Plan',
					'transaction_wallet_address' => $get_investment_plans->id,
					'amount' => $get_investment_plans->investment_amount,
					'transaction_type' => 'Investment',
					'is_status' => 1,
					'created_at' => $currentTime,
					'updated_at' => $currentTime,
					];
					
					// Save UserWallet data
					$user_wallet = new UserWallet();
					Helper::saveData($user_wallet, $uw_data);
					
					// Update user wallet balance
					$user->wallet_balance -= $get_investment_plans->investment_amount;
					$user->save();
					
					DB::commit();
					return response()->json(['status' => true, 'message' => 'Your Investment has been successfully submitted.']);
				}
				catch (\Throwable $e)
				{
					DB::rollBack();
					$message = $e->getMessage();
					return response()->json(['status' => false, 'message' => $message]);
				}
			}
		}
		
		private function calculateBifurcation($user_investment_id, $investment_amount, $currentTime)
		{
			$investmentConfig = [
			'silver_bonds' => 'silver_bond',
			'real_estate' => 'real_estate',
			'startup_investment' => 'startup_investment',
			'stock_investment' => 'stock_investment',
			'trading_investment' => 'trading_investment',
			'reserve_fund' => 'reserve_fund',
			];
			
			$data = ['user_investment_id' => $user_investment_id, 'created_at' => $currentTime, 'updated_at' => $currentTime];
			
			foreach ($investmentConfig as $configKey => $fieldPrefix) {
				$percentage = config("setting.$configKey", 0);
				$data["{$fieldPrefix}_percentage"] = $percentage;
				$data["{$fieldPrefix}_amount"] = ($investment_amount * $percentage) / 100;
			}
			
			return $data;
		}
		
		private function calculateBifurcationChild($user_investment_bifurcation_id,$real_estate_amount, $stock_investment_amount, $trading_investment_amount, $currentTime)
		{
			$bifurcationChildConfig = [
			'real_estate' => [
            'residential' => config('setting.residential', 0),
            'commercial' => config('setting.commercial', 0),
			],
			'stock' => [
            'equity' => config('setting.stock_equity', 0),
            'assets' => config('setting.stock_assets', 0),
			],
			'trading' => [
            'forex' => config('setting.forex', 0),
            'crypto' => config('setting.crypto', 0),
            'stock' => config('setting.stock', 0),
			],
			];
			
			return [
			'user_investment_bifurcation_id' => $user_investment_bifurcation_id,
			'residential_percentage' => $bifurcationChildConfig['real_estate']['residential'],
			'residential_investment_amount' => ($real_estate_amount * $bifurcationChildConfig['real_estate']['residential']) / 100,
			'commercial_percentage' => $bifurcationChildConfig['real_estate']['commercial'],
			'commercial_investment_amount' => ($real_estate_amount * $bifurcationChildConfig['real_estate']['commercial']) / 100,
			'equity_percentage' => $bifurcationChildConfig['stock']['equity'],
			'equity_investment_amount' => ($stock_investment_amount * $bifurcationChildConfig['stock']['equity']) / 100,
			'assets_percentage' => $bifurcationChildConfig['stock']['assets'],
			'assets_investment_amount' => ($stock_investment_amount * $bifurcationChildConfig['stock']['assets']) / 100,
			'forex_percentage' => $bifurcationChildConfig['trading']['forex'],
			'forex_investment_amount' => ($trading_investment_amount * $bifurcationChildConfig['trading']['forex']) / 100,
			'crypto_percentage' => $bifurcationChildConfig['trading']['crypto'],
			'crypto_investment_amount' => ($trading_investment_amount * $bifurcationChildConfig['trading']['crypto']) / 100,
			'stock_percentage' => $bifurcationChildConfig['trading']['stock'],
			'stock_investment_amount' => ($trading_investment_amount * $bifurcationChildConfig['trading']['stock']) / 100,
			'created_at' => $currentTime,
			'updated_at' => $currentTime,
			];
		}
	}
