<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Tymon\JWTAuth\Exceptions\JWTException;
	use Symfony\Component\HttpFoundation\Response;
	use Illuminate\Validation\Rule;
	use App\Models\User; 
	use App\Models\UserKyc; 
	use App\Models\UserWallet; 
	use App\Models\AiBots; 
	use App\Models\AiBotPurchase; 
	
	use Auth, JWTAuth, Validator, DB, Helper, Storage;
	
	class WalletController extends Controller
	{
		//Deposit
		public function getDepositHistory()
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				$get_user_wallet = UserWallet::where('user_id',$user->id)->where('transaction_type','Deposit')->orderBy('id','DESC')->get();
				
				return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'data' => $get_user_wallet]);
			} 
		} 
		
		public function depositAmount(Request $request)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				try
				{
					DB::beginTransaction();
					
					$currentTime = now();
					$data = $request->except('transaction_image','transaction_type');
					$data['updated_at'] = $currentTime;
					
					$data['user_id'] = $user->id;
					
					$data['transaction_type'] = $request->input('transaction_type') ?? 'Deposit';
					
					if ($request->hasFile('transaction_image')) 
					{
						$file = $request->file('transaction_image');
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/transaction', $filename, 'public');
						$data['transaction_image'] = $filePath; // Store the path in the database
					}
					
					$object = new UserWallet();
					Helper::saveData($object, $data);
					
					DB::commit();
					
					if($data['transaction_type'] == "Premium Subscription")
					{
						return response()->json(['status' => true, 'message' => 'Your Premium Subscription request has been successfully submitted.']);
					}
					
					return response()->json(['status' => true, 'message' => 'Your deposit request has been successfully submitted.']);
				}
				catch (\Throwable $e)
				{
					DB::rollBack();
					$message = $e->getMessage();
					return response()->json(['status' => false, 'message' => $message]);
				} 
			}
		}
		
		//Withdrawal
		public function getWithdrawalHistory()
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				$get_user_wallet = UserWallet::where('user_id',$user->id)->where('transaction_type','Withdrawal')->orderBy('id','DESC')->get();
				
				return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'data' => $get_user_wallet]);
			} 
		} 
		
		public function withdrawalAmountRequest(Request $request)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				try 
				{
					DB::beginTransaction();
					
					$amount = $request->input('amount');
					
					if ($user->wallet_balance < $amount) {
						return response()->json(['status' => false, 'message' => "Your wallet balance is insufficient for the withdrawal amount of '$amount'."]);
					}
					
					$check_user_kyc = UserKyc::firstOrNew(['user_id' => $user->id]);
					
					$transaction_method = $request->input('transaction_method');
					$transaction_wallet_address = $request->input('transaction_wallet_address');
					
					$walletMapping = [
					"Trust Wallet" => 'trust_wallet',
					"Metamask Wallet" => 'metamask_wallet',
					"Ekaum Wallet" => 'ekaum_wallet',
					"Phantom Wallet" => 'phantom_wallet',
					"1 Inch Wallet" => 'one_inch_wallet',
					"Electrum Wallet" => 'electrum_wallet',
					"UPI Address" => 'upi_address'
					];
					
					if (array_key_exists($transaction_method, $walletMapping)) {
						$walletField = $walletMapping[$transaction_method];
						if (empty($check_user_kyc->$walletField)) {
							$check_user_kyc->$walletField = $transaction_wallet_address;
							$check_user_kyc->save();
						}
					}
					
					$currentTime = now();
					$data = $request->except('transaction_image');
					$data['updated_at'] = $currentTime;
					$data['user_id'] = $user->id;
					$data['transaction_type'] = "Withdrawal";
					
					if ($request->hasFile('transaction_image')) {
						$file = $request->file('transaction_image');
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/transaction', $filename, 'public');
						$data['transaction_image'] = $filePath; // Store the path in the database
					}
					
					$object = new UserWallet();
					Helper::saveData($object, $data);
					
					// Update user wallet balance
					$user->wallet_balance -= $amount;
					$user->save();
					
					DB::commit();
					return response()->json(['status' => true, 'message' => "Your withdrawal request has been successfully submitted."]);
				} 
				catch (\Throwable $e) 
				{
					DB::rollBack();
					return response()->json(['status' => false, 'message' => $e->getMessage()]);
				}
			}
		}
		
		public function updateWithdrawalRequest(Request $request, $id)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				try {
					DB::beginTransaction();
					
					$amount = $request->input('amount');
					
					$walletEntry = UserWallet::find($id);
					
					if (!$walletEntry) 
					{
						return response()->json(['status' => false, 'message' => 'Wallet entry not found.']);
					}
					
					$user->wallet_balance += $walletEntry->amount;
					
					if ($user->wallet_balance < $amount) {
						return response()->json(['status' => false, 'message' => "Insufficient wallet balance for the withdrawal amount of '$amount'."]);
					}
					
					$user->wallet_balance -= $amount;
					$user->save();
					
					$data = $request->except('_token');
					$data['updated_at'] = now();
					$data['amount'] = $amount;
					
					// Update wallet entry
					Helper::saveData($walletEntry, $data);
					
					DB::commit();
					
					return response()->json(['status' => true, 'message' => "Your withdrawal request has been successfully Updated."]);
					} catch (\Throwable $e) {
					DB::rollBack();
					return response()->json(['status' => false, 'message' => $e->getMessage()]);
				}
			}
		}
		
		public function deleteWithdrawalRequest($id)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				try {
					DB::beginTransaction();
					
					$user_wallet = UserWallet::findOrFail($id);
					$amount = $user_wallet->amount;
					
					$user->wallet_balance += $amount;
					$user->save();
					
					$user_wallet->delete();
					
					DB::commit();
					
					return response()->json(['status' => true, 'message' => 'Withdrawal request has been successfully deleted.']);
					} catch (\Throwable $e) {
					DB::rollBack();
					
					return response()->json(['status' => false, 'message' => 'An error occurred while deleting the withdrawal request. Please try again.']);
				}
			}
		}
		
		public function purchaseAiBot(Request $request)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				try {
					DB::beginTransaction();
					$purchase_amount = $request->input('amount');
					
					if ($user->wallet_balance < $purchase_amount) 
					{
						return response()->json(['status' => false, 'msg' => "Your wallet balance is insufficient for the ai boat purchase price amount of '$purchase_amount'."]);
					}
					
					$currentTime = now();
					$data = $request->except('_token');
					$data['user_id'] = $user->id;
					$data['created_at'] = $currentTime;
					$data['updated_at'] = $currentTime;
					
					$object = new AiBotPurchase();
					Helper::saveData($object,$data);
					$id = $object->id;
					
					$get_ai_bot = AiBots::where('id',$request->input('ai_bot_id'))->first();
					
					$transaction_method = $get_ai_bot->currency_type .','. $get_ai_bot->risk_type;
					
					$uw_data = [
					'user_id' => $user->id,
					'transaction_method' => $transaction_method,
					'transaction_wallet_address' => $get_ai_bot->id,
					'amount' => $purchase_amount,
					'transaction_type' => 'Purchase Ai Bot',
					'is_status' => 1,
					'created_at' => $currentTime,
					'updated_at' => $currentTime,
					];
					
					$user_wallet = new UserWallet();
					Helper::saveData($user_wallet, $uw_data);
					
					$user->wallet_balance -= $purchase_amount;
					$user->save();
					
					DB::commit(); 
					return response()->json(['status' => true, 'message' => 'The Ai Bot Purchase has been successfully.']);
				}
				catch (\Throwable $e) {
					DB::rollBack();
					
					return response()->json(['status' => false, 'message' => 'An error occurred while deleting the withdrawal request. Please try again.']);
				} 
			}
		}
		
		public function getAiBotPurchaseHistory()
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				$get_ai_bot_purchase_history = AiBotPurchase::select('ai_bot_purchases.*', 'ai_bots.currency_type', 'ai_bots.risk_type')
				->join('ai_bots', 'ai_bots.id', '=', 'ai_bot_purchases.ai_bot_id') 
				->where('ai_bot_purchases.user_id', $user->id)
				->orderBy('ai_bot_purchases.id', 'DESC')
				->get();
				
				return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'data' => $get_ai_bot_purchase_history]);
			} 
		} 
	}
