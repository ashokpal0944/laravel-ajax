<?php
	namespace App\Http\Controllers\Api;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Hash;
	use Illuminate\Support\Facades\Validator;
	use Illuminate\Support\Facades\Password;
	use Tymon\JWTAuth\Exceptions\JWTException;
	use Illuminate\Auth\Events\Registered;
	use App\Models\User; 
	use App\Models\Otp; 
	use App\Models\UserKyc; 
	use App\Models\UserWallet; 
	use Auth, JWTAuth, DB;
	
	class AuthenticationController extends Controller
	{
		public function registerPost(Request $request)
		{
			try 
			{
				DB::beginTransaction();
				
				$currentTime = now();
				
				$email = $request->input('email');
				$mobileNo = $request->input('phone_number');
				
				$existingUser = User::where(function ($query) use ($email, $mobileNo) {
					$query->where('email', $email)
					->orWhere('phone_number', $mobileNo);
				})
				->first();
				
				if ($existingUser) 
				{
					$message = $existingUser->email === $email ? 'Email already exists' : 'Mobile Number already exists';
					return response()->json(['status' => false, 'message' => $message]);
				}
				
				$referral_code = $this->generateReferralCode();
				
				$data = $request->except('password');
				$data['created_at'] = $currentTime;
				$data['updated_at'] = $currentTime;
				$data['referral_code'] = $referral_code;
				$data['password'] = Hash::make($request->input('password'));
				
				$user = User::create($data);
				
				$user->sendEmailVerificationNotification();
				
				DB::commit();
				return response()->json(['status' => true, 'message' => 'Please verify your email. A confirmation has been sent to your registered email address.']);
			}
			catch (JWTException $e) 
			{
				return response()->json(['status' => false,'message' => 'Could not create token.']);
			}
		}
		
		function generateReferralCode($length = 6) {
			$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
			$charactersLength = strlen($characters);
			$referralCode = '';
			
			for ($i = 0; $i < $length; $i++) {
				$referralCode .= $characters[rand(0, $charactersLength - 1)];
			}
			
			return $referralCode;
		}
		
		public function checkUserName(Request $request)
		{
			$username = $request->input('username');
			
			$check_user_name = User::where('username', $username)->first();
			
			if ($check_user_name) {
				return response()->json(['status' => false, 'message' => 'Username already exists']);
			}
			
			return response()->json(['status' => true, 'message' => 'Username is valid']);
		}
		
		public function loginPost(Request $request) // Changed method name to 'login'
		{
			try 
			{
				$filed_value = $request->input('email');
				
				$check_type = filter_var($filed_value, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
				
				$check_user = User::where($check_type, $filed_value)->first();
				
				if (!$check_user) 
				{
					return response()->json([
					'status' => false,
					'message' => "The $check_type and password are incorrect. Please check your details and try again."
					]);
				}
				
				if(is_null($check_user->email_verified_at)) 
				{
					$check_user->sendEmailVerificationNotification();
					
					return response()->json(['status' => false,'msg_user' => 'We just re-sent the verification link to your email address: '.$check_user->email.'','message' => 'Please click on the link to verify your email and start using your account. If you have any questions or need further assistance, feel free to contact our support team at support@clarusventure.com.']);
				}
				
				if($check_user->is_status != 1) 
				{
					return response()->json(['status' => false,'message' => "Your account is deactivated. Please contact the admin."]);
				}
				
				$credentials = [
				$check_type => $filed_value,
				'password' => $request->input('password'),
				];
				
				if(!$token = JWTAuth::attempt($credentials)) 
				{
					return response()->json(['status' => false,'message' => 'Login credentials are invalid.']);
				}
			}
			catch (JWTException $e) 
			{
				return response()->json(['status' => false,'message' => 'Could not create token.']);
			}
			
			$get_user = User::select('users.*','countries.name as country_name','states.name as state_name','cities.name as city_name')->where($check_type, $filed_value)
			->join('countries', 'countries.id', '=', 'users.country_id')
			->join('states', 'states.id', '=', 'users.state_id')
			->join('cities', 'cities.id', '=', 'users.city_id')
			->first();
			
			$check_kyc = UserKyc::where('user_id',$get_user->id)->first();
			
			$kyc_status = 0;
			if($check_kyc)
			{
				if ($check_kyc->is_aadhaar == 2 || $check_kyc->is_pancard == 2 || $check_kyc->is_bank_account == 2) {
					$kyc_status = 2;
					} elseif ($check_kyc->is_aadhaar == 1 && $check_kyc->is_pancard == 1 && $check_kyc->is_bank_account == 1) {
					$kyc_status = 1;
					} elseif ($check_kyc->is_aadhaar == 0 && $check_kyc->is_pancard == 0 && $check_kyc->is_bank_account == 0) {
					$kyc_status = 0;
					} else {
					$kyc_status = 0;
				}
			}
			
			$get_user['is_kyc'] = $kyc_status;
			
			$check_premium_subscription = UserWallet::where('user_id',$get_user->id)->where('transaction_type',"Premium Subscription")->orderBy('id','DESC')->first();
			
			$get_user['is_premium_member'] = 0;
			if($check_premium_subscription)
			{
				if($check_premium_subscription->is_status == 0)
				{
					$is_status = 2;
				}
				else if($check_premium_subscription->is_status == 1)
				{
					$is_status = 1;
				}
				else if($check_premium_subscription->is_status == 2)
				{
					$is_status = 3;
				}
				
				$get_user['is_premium_member'] = $is_status;
			}
			
			return response()->json(['status' => true, 'token' => $token,'data' => $get_user,]);
		}
		
		public function sendOTP(Request $request)
		{
			$mobile_no = $request->input('mobile_no');
			$random_otp = random_int(100000, 999999);
			
			Otp::where('mobile_no', $mobile_no)->delete();
			
			$get_user = User::where('phone_number',$mobile_no)->first();
			
			if(empty($get_user))
			{
				return response()->json(['status' => false,'message' => 'Mobile number not registered. Please check your mobile number.']);
			}
			
			if(is_null($get_user->email_verified_at)) 
			{
				$get_user->sendEmailVerificationNotification();
				
				return response()->json(['status' => false,'msg_user' => 'We just re-sent the verification link to your email address: '.$get_user->email.'','message' => 'Please click on the link to verify your email and start using your account. If you have any questions or need further assistance, feel free to contact our support team at support@clarusventure.com.']);
			}
			
			if($get_user->is_status != 1) 
			{
				return response()->json(['status' => false,'message' => "Your account is deactivated. Please contact the admin."]);
			}
			
			Otp::insert(['mobile_no' => $mobile_no,'otp' => $random_otp]);
			
			return response()->json(['status' => true,'message' => 'An OTP has been sent to your registered mobile number. Please check your mobile.', 'otp' => $random_otp]);
		}
		
		public function verifyOTP(Request $request)
		{
			$mobile_no = $request->input('mobile_no');
			$otp = $request->input('otp');
			
			$check_otp = Otp::where('mobile_no', $mobile_no)->where('otp', $otp)->first();
			
			if (!$check_otp) 
			{
				return response()->json(['status' => false,'message' => 'Invalid OTP. Please try again.']);
			}
			
			$get_user = User::select('users.*','countries.name as country_name','states.name as state_name','cities.name as city_name')->where('users.phone_number', $mobile_no)
			->join('countries', 'countries.id', '=', 'users.country_id')
			->join('states', 'states.id', '=', 'users.state_id')
			->join('cities', 'cities.id', '=', 'users.city_id')
			->first();
			
			try {
				if (!$token = JWTAuth::fromUser($get_user)) {
					return response()->json([
					'status' => false,
					'message' => 'Could not create token.',
					]);
				}
				} catch (JWTException $e) {
				return response()->json([
				'status' => false,
				'message' => 'Could not create token.',
				]);
			}
			
			Otp::where('mobile_no', $mobile_no)->delete();
			
			$check_kyc = UserKyc::where('user_id',$get_user->id)->first();
			
			$kyc_status = 0;
			if($check_kyc)
			{
				if ($check_kyc->is_aadhaar == 2 || $check_kyc->is_pancard == 2 || $check_kyc->is_bank_account == 2) {
					$kyc_status = 2;
					} elseif ($check_kyc->is_aadhaar == 1 && $check_kyc->is_pancard == 1 && $check_kyc->is_bank_account == 1) {
					$kyc_status = 1;
					} elseif ($check_kyc->is_aadhaar == 0 && $check_kyc->is_pancard == 0 && $check_kyc->is_bank_account == 0) {
					$kyc_status = 0;
					} else {
					$kyc_status = 0;
				}
			}
			
			$get_user['is_kyc'] = $kyc_status;
			
			$check_premium_subscription = UserWallet::where('user_id',$get_user->id)->where('transaction_type',"Premium Subscription")->orderBy('id','DESC')->first();
			
			$get_user['is_premium_member'] = 0;
			if($check_premium_subscription)
			{
				if($check_premium_subscription->is_status == 0)
				{
					$is_status = 2;
				}
				else if($check_premium_subscription->is_status == 1)
				{
					$is_status = 1;
				}
				else if($check_premium_subscription->is_status == 2)
				{
					$is_status = 3;
				}
				
				$get_user['is_premium_member'] = $is_status;
			}
			
			return response()->json(['status' => true,'token' => $token,'data' => $get_user]);
		}
		
		public function forgotPassword(Request $request)
		{
			$email = $request->input('email');
			
			$get_user = User::where('email', $email)->first();
			
			if(!$get_user) 
			{
				return response()->json(['status' => false,'message' => "We can't find a user with that email address."]);
			}
			
			$status = Password::sendResetLink(['email' => $email]);
			
			if ($status === Password::RESET_LINK_SENT) {
				return response()->json(['status' => true, 'message' => __($status)]);
				} else {
				return response()->json(['status' => false, 'message' => __($status)]);
			}
		}
	}
