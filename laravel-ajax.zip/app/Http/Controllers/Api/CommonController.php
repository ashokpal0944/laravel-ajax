<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Tymon\JWTAuth\Exceptions\JWTException;
	use Symfony\Component\HttpFoundation\Response;
	use Illuminate\Validation\Rule;
	use App\Models\User; 
	use App\Models\InvestmentPlan; 
	use App\Models\LiveTrade; 
	use App\Models\PastTrade; 
	use App\Models\News; 
	use App\Models\TopCategory; 
	use App\Models\Video; 
	use App\Models\StockBuzz;
	use App\Models\Country;
	use App\Models\State;
	use App\Models\City;
	use App\Models\Setting;
	
	use Auth, JWTAuth, Validator, DB, Helper, Storage;
	
	class CommonController extends Controller
	{
		public function getCountry()
		{
			$countries = Country::all();

			return response()->json(['status' => true,'message' => 'Data fetched successfully!','data' => $countries]);
		}
		
		public function getState(Request $request)
		{
			$country_id = $request->input('country_id');
			
			$get_state = State::where('country_id',$country_id)->get();
			
			return response()->json(['status' => true,'message' => 'Data fetched successfully!','data' => $get_state]);
		}
		
		public function getCity(Request $request)
		{
			$state_id = $request->input('state_id');
			
			$get_city = City::where('state_id',$state_id)->get();
			
			return response()->json(['status' => true,'message' => 'Data fetched successfully!','data' => $get_city]);
		}
	}
