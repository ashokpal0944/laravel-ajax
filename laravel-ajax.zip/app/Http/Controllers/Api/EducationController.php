<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Tymon\JWTAuth\Exceptions\JWTException;
	use Symfony\Component\HttpFoundation\Response;
	use Illuminate\Validation\Rule;
	use App\Models\User; 
	use App\Models\Trading; 
	use App\Models\Rehab;
	use App\Models\Business;
	use App\Models\PurchaseCourse;
	use App\Models\UserWallet;
	
	use Auth, JWTAuth, Validator, DB, Helper, Storage;
	
	class EducationController extends Controller
	{
		public function getEducation()
		{
			$get_tradings  = Trading::where('is_status',1)->get();
			$get_rehabs  = Rehab::where('is_status',1)->get();
			$get_business  = Business::where('is_status',1)->get();
			
			$data = [
				'tradings' => $get_tradings,
				'rehabs' => $get_rehabs,
				'business' => $get_business,
			];
			
			return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'data' => $data]);
		}
		
		public function getEducationHistory()
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				$get_purchase_course = PurchaseCourse::where('purchase_courses.user_id', $user->id)->orderBy('id','DESC')->get();
				
				$my_array = array();
				foreach($get_purchase_course as $get_purchase_cours)
				{
					if($get_purchase_cours->course_type == "Trading")
					{
						$course_name = Trading::where('id',$get_purchase_cours->course_id)->first()->title;
					}
					else if($get_purchase_cours->course_type == "Rehab")
					{
						$course_name = Rehab::where('id',$get_purchase_cours->course_id)->first()->courses;
					}
					else
					{
						$course_name = Business::where('id',$get_purchase_cours->course_id)->first()->title;
					}
					
					$data['id'] = $get_purchase_cours->id;
					$data['course_id'] = $get_purchase_cours->course_id;
					$data['course_name'] = $course_name;
					$data['course_type'] = $get_purchase_cours->course_type;
					$data['course_price'] = $get_purchase_cours->course_price;
					$data['start_date'] = $get_purchase_cours->start_date;
					$data['expire_date'] = $get_purchase_cours->expire_date;
					$data['is_status'] = $get_purchase_cours->is_status;
					$data['created_at'] = $get_purchase_cours->created_at;
					
					$my_array[] = $data;
				}
				
				return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'data' => $my_array]);
			}
		}
		
		public function purchaseEducationPlan(Request $request)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				try 
				{
					DB::beginTransaction();
					
					$course_id = $request->input('course_id');
					$course_type = $request->input('course_type');
					$course_price = $request->input('course_price');
					$start_date = $request->input('start_date');
					$expire_date = $request->input('expire_date');
					
					if ($user->wallet_balance < $course_price) 
					{
						return response()->json(['status' => false, 'message' => "Your wallet balance is insufficient for the course price amount of '$course_price'."]);
					}
					
					$currentTime = now();
					$data = [
						'user_id' => $user->id,
						'course_id' => $course_id,
						'course_type' => $course_type,
						'course_price' => $course_price,
						'start_date' => $start_date,
						'expire_date' => $expire_date,
						'created_at' => $currentTime,
						'updated_at' => $currentTime,
					];
					
					// Save PurchaseCourse data
					$object = new PurchaseCourse();
					Helper::saveData($object, $data);
					
					$uw_data = [
					'user_id' => $user->id,
					'transaction_method' => $course_type,
					'transaction_wallet_address' => $course_id,
					'amount' => $course_price,
					'transaction_type' => 'Purchase',
					'is_status' => 1,
					'created_at' => $currentTime,
					'updated_at' => $currentTime,
					];
					
					// Save UserWallet data
					$user_wallet = new UserWallet();
					Helper::saveData($user_wallet, $uw_data);
					
					// Update user wallet balance
					$user->wallet_balance -= $course_price;
					$user->save();
					
					// Commit transaction
					DB::commit();
					return response()->json(['status' => true, 'message' => "The course has been purchased successfully."]);
				} 
				catch (\Throwable $e) 
				{
					// Rollback transaction on error
					DB::rollBack();
					return response()->json(['status' => false, 'message' => 'An error occurred: ' . $e->getMessage()]);
				}
			}
		}
	}
