<?php
	
	namespace App\Http\Controllers\Api;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Tymon\JWTAuth\Exceptions\JWTException;
	use Symfony\Component\HttpFoundation\Response;
	use Illuminate\Support\Facades\Hash;
	use Illuminate\Validation\Rule;
	use App\Models\User; 
	use App\Models\InvestmentPlan; 
	use App\Models\LiveTrade; 
	use App\Models\PastTrade; 
	use App\Models\News; 
	use App\Models\TopCategory; 
	use App\Models\Video; 
	use App\Models\StockBuzz;
	use App\Models\Country;
	use App\Models\State;
	use App\Models\City;
	use App\Models\Setting;
	use App\Models\UserKyc;
	use App\Models\UserWallet; 
	use App\Models\AiBots; 
	use App\Models\UserInvestment; 
	use App\Models\AiBotPurchase; 
	
	use Auth, JWTAuth, Validator, DB, Helper, Storage;
	
	class HomeController extends Controller
	{
		public function getDashboardData()
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				$get_categorys = TopCategory::where('is_status',1)->get();
				$get_videos = Video::where('is_status',1)->get();
				$get_past_trades = PastTrade::orderBy('id', 'DESC')->take(6)->get();
				$get_live_trades = LiveTrade::orderBy('id', 'DESC')->take(6)->get();
				$get_stock_buzzs = StockBuzz::orderBy('id', 'DESC')->take(6)->get();
				$get_newss = News::orderBy('id', 'DESC')->take(6)->get();
				
				$investment_banner_first = [];
				if (config('setting.investment_banner_first')) {
					$investment_banner_first = json_decode(config('setting.investment_banner_first'), true); // Ensure array return
				}
				
				$investment_banner_second = [];
				if (config('setting.investment_banner_second')) {
					$investment_banner_second = json_decode(config('setting.investment_banner_second'), true); // Ensure array return
				}
			
				$get_aibots = AiBots::where('is_status', 1)->get()->groupBy('currency_type');
				$user_ai_purchases = AiBotPurchase::where('user_id', $user->id)->pluck('ai_bot_id')->toArray();
				
				$get_ai_bots_array = [];
				foreach ($get_aibots as $currency_type => $bots) {
					$currency_data = [];
					foreach ($bots as $bot) {
						$is_purchase = in_array($bot->id, $user_ai_purchases) ? 1 : 0;
						$bot['is_purchase'] = $is_purchase;
						$currency_data[] = $bot;
					}
				
					$data['currency_type'] = $currency_type;
					$data['all_currency_data'] = $currency_data;
					
					$get_ai_bots_array[] = $data;
				}
				
				$is_investment_plan = UserInvestment::where('user_id', $user->id)->where('is_status', 1)->where('is_payable', 0)->exists() ? 1 : 0;
				
				// Organize data into an associative array
				$data = [
				'top_categorys' => $get_categorys,
				'videos' => $get_videos,
				'past_trade' => $get_past_trades,
				'live_trades' => $get_live_trades,
				'stock_buzzs' => $get_stock_buzzs,
				'news' => $get_newss,
				'past_top_trade_title' => config('setting.past_top_trade_title'),
				'past_top_trade_title_percentag' => config('setting.past_top_trade_title_percentag'),
				'past_trade_information' => config('setting.past_top_trade_information'),
				'explore_the_exclusive_banner' => config('setting.explore_the_exclusive_banner'),
				'investment_banner_first' => $investment_banner_first,
				'investment_banner_second' => $investment_banner_second,
				'get_investment_ai_bots' => $get_ai_bots_array,
				'is_investment_plan' => $is_investment_plan,
				];
				
				// Return the response with a success message and data
				return response()->json(['status' => true, 'message' => 'Data fetched successfully!','data' => $data]);
			}
		}
		
		public function getProfile()
		{
			try 
			{
				$user = JWTAuth::parseToken()->authenticate();
				
				if(!$user)
				{
					return response()->json(['status' => false, 'message' => 'User not authenticated.']);
				}
				
				$get_user = User::select('users.*','countries.name as country_name','states.name as state_name','cities.name as city_name')->where('users.id', $user->id)
				->join('countries', 'countries.id', '=', 'users.country_id')
				->join('states', 'states.id', '=', 'users.state_id')
				->join('cities', 'cities.id', '=', 'users.city_id')
				->first();
				
				$check_kyc = UserKyc::where('user_id',$get_user->id)->first();
				
				$kyc_status = 0;
				if($check_kyc)
				{
					if ($check_kyc->is_aadhaar == 2 || $check_kyc->is_pancard == 2 || $check_kyc->is_bank_account == 2) {
						$kyc_status = 2;
						} elseif ($check_kyc->is_aadhaar == 1 && $check_kyc->is_pancard == 1 && $check_kyc->is_bank_account == 1) {
						$kyc_status = 1;
						} elseif ($check_kyc->is_aadhaar == 0 && $check_kyc->is_pancard == 0 && $check_kyc->is_bank_account == 0) {
						$kyc_status = 0;
						} else {
						$kyc_status = 0;
					}
				}
				
				$get_user['is_kyc'] = $kyc_status;
				
				$check_premium_subscription = UserWallet::where('user_id',$get_user->id)->where('transaction_type',"Premium Subscription")->orderBy('id','DESC')->first();
				
				$get_user['is_premium_member'] = 0;
				if($check_premium_subscription)
				{
					if($check_premium_subscription->is_status == 0)
					{
						$is_status = 2;
					}
					else if($check_premium_subscription->is_status == 1)
					{
						$is_status = 1;
					}
					else if($check_premium_subscription->is_status == 2)
					{
						$is_status = 3;
					}
					
					$get_user['is_premium_member'] = $is_status;
				}
				
				return response()->json(['status' => true,'message' => 'Data fetched successfully!','data' => $get_user]);
				
			}
			catch (JWTException $e) 
			{
				return response()->json(['status' => false, 'message' => 'Token is invalid or expired. Please log in again.']);
			}
		}
		
		public function updateProfile(Request $request)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				/* $validator = Validator::make($request->all(), [
					'email' => ['required', 'email', Rule::unique('users', 'email')->ignore($user->id)],
					'phone_number' => ['required', 'integer', Rule::unique('users', 'phone_number')->ignore($user->id)],
					'name' => 'required|string',
					'profile' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
					]);
					
					if ($validator->fails()) {
					return response()->json(['error' => $validator->messages()]);
				} */
				
				try
				{
					DB::beginTransaction();
					
					$data = $request->except('profile');
					$email = $request->input('email');
					$mobileNo = $request->input('phone_number');
					
					$existingUser = User::where('id', '!=', $user->id)
					->where(function ($query) use ($email, $mobileNo) {
						$query->where('email', $email)
						->orWhere('phone_number', $mobileNo);
					})
					->first();
					
					if ($existingUser) 
					{
						$message = $existingUser->email === $email ? 'Email already exists' : 'Mobile Number already exists';
						return response()->json(['status' => false, 'message' => $message]);
					}
					
					$object = User::findOrFail($user->id);
					$oldImagePath = $object->image;
					
					if ($request->hasFile('profile')) {
						$file = $request->file('profile');
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/profile', $filename, 'public');
						
						$data['profile'] = $filePath;
						
						if ($oldImagePath && Storage::disk('public')->exists($oldImagePath)) {
							Storage::disk('public')->delete($oldImagePath);
						}
					}
					
					Helper::saveData($object,$data);
					
					$get_user = User::select('users.*','countries.name as country_name','states.name as state_name','cities.name as city_name')->where('users.id', $user->id)
					->join('countries', 'countries.id', '=', 'users.country_id')
					->join('states', 'states.id', '=', 'users.state_id')
					->join('cities', 'cities.id', '=', 'users.city_id')
					->first();
					
					$check_kyc = UserKyc::where('user_id',$get_user->id)->first();
					
					$kyc_status = 0;
					if($check_kyc)
					{
						if ($check_kyc->is_aadhaar == 2 || $check_kyc->is_pancard == 2 || $check_kyc->is_bank_account == 2) {
							$kyc_status = 2;
							} elseif ($check_kyc->is_aadhaar == 1 && $check_kyc->is_pancard == 1 && $check_kyc->is_bank_account == 1) {
							$kyc_status = 1;
							} elseif ($check_kyc->is_aadhaar == 0 && $check_kyc->is_pancard == 0 && $check_kyc->is_bank_account == 0) {
							$kyc_status = 0;
							} else {
							$kyc_status = 0;
						}
					}
					
					$get_user['is_kyc'] = $kyc_status;
					
					$check_premium_subscription = UserWallet::where('user_id',$get_user->id)->where('transaction_type',"Premium Subscription")->orderBy('id','DESC')->first();
					
					$get_user['is_premium_member'] = 0;
					if($check_premium_subscription)
					{
						if($check_premium_subscription->is_status == 0)
						{
							$is_status = 2;
						}
						else if($check_premium_subscription->is_status == 1)
						{
							$is_status = 1;
						}
						else if($check_premium_subscription->is_status == 2)
						{
							$is_status = 3;
						}
						
						$get_user['is_premium_member'] = $is_status;
					}
					
					DB::commit();
					return response()->json(['status' => true, 'message' => 'The Profile has been successfully Updated.', 'data' => $get_user]);
				}
				catch (\Throwable $e)
				{
					DB::rollBack();
					$message = $e->getMessage();
					return response()->json(['status' => false, 'message' => $message]);
				} 
			}
		}
		
		public function changePassword(Request $request)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				try
				{
					DB::beginTransaction();
					
					if (!Hash::check($request->input('old_password'), $user->password)) {
						return response()->json(['status' => false, 'message' => 'The old password is incorrect.']);
					}
					
					$data['password'] = Hash::make($request->input('password'));
					
					$object = User::find($user->id);
					Helper::saveData($object,$data);
					
					DB::commit();
					return response()->json(['status' => true, 'message' => 'Password updated successfully.']);
				}
				catch (\Throwable $e)
				{
					DB::rollBack();
					$message = $e->getMessage();
					return response()->json(['status' => false, 'message' => $message]);
				} 
			}
		}
		
		public function getWalletDetails()
		{
			$upi_details = ['upi_address' => config('setting.upi_address'),'upi_qr_code' => config('setting.qr_code')];
			$bank_details = ['bank_holder_name' => config('setting.bank_holder_name'),'bank_name' => config('setting.bank_name'),'account_number' => config('setting.account_number'),'ifsc_code' => config('setting.ifsc_code')];
			
			$wallet_data[] = ['title' => "Trust Wallet",'wallet_address' => config('setting.trust_wallet'),'qr_code' => config('setting.trust_wallet_qr_code')];
			$wallet_data[] = ['title' => "Metamask Wallet",'wallet_address' => config('setting.metamask_wallet'),'qr_code' => config('setting.metamask_wallet_qr_code')];
			$wallet_data[] = ['title' => "Ekaum Wallet",'wallet_address' => config('setting.ekaum_wallet'),'qr_code' => config('setting.ekaum_wallet_qr_code')];
			$wallet_data[] = ['title' => "Phantom Wallet",'wallet_address' => config('setting.phantom_wallet'),'qr_code' => config('setting.phantom_wallet_qr_code')];
			$wallet_data[] = ['title' => "1 Inch Wallet",'wallet_address' => config('setting.one_inch_wallet'),'qr_code' => config('setting.one_inch_wallet_qr_code')]; 
			$wallet_data[] = ['title' => "Electrum Wallet",'wallet_address' => config('setting.electrum_wallet'),'qr_code' => config('setting.electrum_wallet_qr_code')]; 
			
			$wallet_details = $wallet_data;
			
			$fees_taxes_data[] = ['title' => "Crypto Tax",'percentage' => config('setting.crypto_tax_percentage')];
			$fees_taxes_data[] = ['title' => "CESS",'percentage' => config('setting.cess_tax_percentage')];
			$fees_taxes_data[] = ['title' => "TDS",'percentage' => config('setting.tds_tax_percentage')];
			$fees_taxes_data[] = ['title' => "WC",'percentage' => config('setting.wc_tax_percentage')];
			$fees_taxes_data[] = ['title' => "Maintenance",'percentage' => config('setting.maintenance_tax_percentage')];
			
			$fees_taxes = $fees_taxes_data;
			
			$data = [
			'upi_details' => $upi_details,
			'bank_details' => $bank_details,
			'wallet_details' => $wallet_details,
			'fees_taxes' => $fees_taxes,
			];
			
			return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'data' => $data]);
		}
		
		public function getUserKyc()
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				$get_user_kyc = UserKyc::where('user_id', $user->id)->first();
				
				if($get_user_kyc)
				{
					$user_kyc['aadhaar_front'] = $get_user_kyc->aadhaar_front;
					$user_kyc['aadhaar_back'] = $get_user_kyc->aadhaar_back;
					$user_kyc['aadhaar_number'] = $get_user_kyc->aadhaar_number;
					$user_kyc['is_aadhaar'] = $get_user_kyc->is_aadhaar;
					$user_kyc['aadhaar_note'] = $get_user_kyc->aadhaar_note;
					$user_kyc['pancard_image'] = $get_user_kyc->pancard_image;
					$user_kyc['pancard_number'] = $get_user_kyc->pancard_number;
					$user_kyc['is_pancard'] = $get_user_kyc->is_pancard;
					$user_kyc['pancard_note'] = $get_user_kyc->pancard_note;
					$user_kyc['bank_details'] = ['bank_name' => $get_user_kyc->bank_name,'account_number' => $get_user_kyc->account_number,'ifsc_code' => $get_user_kyc->ifsc_code,'account_type' => $get_user_kyc->account_type,'is_bank_account' => $get_user_kyc->is_bank_account,'bank_account_note' => $get_user_kyc->bank_account_note];
					
					$wallet_details[] = ['title' => 'Trust Wallet', 'wallet_address' => $get_user_kyc->trust_wallet, 'qr_code' => ''];
					$wallet_details[] = ['title' => 'Metamask Wallet', 'wallet_address' => $get_user_kyc->metamask_wallet, 'qr_code' => ''];
					$wallet_details[] = ['title' => 'Ekaum Wallet', 'wallet_address' => $get_user_kyc->ekaum_wallet, 'qr_code' => ''];
					$wallet_details[] = ['title' => 'Phantom Wallet', 'wallet_address' => $get_user_kyc->phantom_wallet, 'qr_code' => ''];
					$wallet_details[] = ['title' => '1 Inch Wallet', 'wallet_address' => $get_user_kyc->one_inch_wallet, 'qr_code' => ''];
					$wallet_details[] = ['title' => 'Electrum Wallet', 'wallet_address' => $get_user_kyc->electrum_wallet, 'qr_code' => ''];
					
					$user_kyc['wallet_details'] = $wallet_details;
					$user_kyc['upi_details'] = ['upi_address' => $get_user_kyc->upi_address, 'qr_code' => ''];
				}
				
				$user_kyc['profile'] = $user->profile;
				$user_kyc['dob'] = $user->dob;
				
				return response()->json(['status' => true,'message' => 'Data Featch Successfully.!', 'data' => $user_kyc]);
			}
		}
		
		public function userKYC(Request $request)
		{
			if($user = JWTAuth::parseToken()->authenticate())
			{
				try 
				{
					DB::beginTransaction();
					
					$currentTime = now();
					$data = $request->except('aadhaar_front', 'aadhaar_back', 'pancard_image','profile','dob');
					$data['updated_at'] = $currentTime;
					
					$object = UserKyc::where('user_id', $user->id)->first();
					
					$fields = [
					'aadhaar_front' => 'aadhaar_front',
					'aadhaar_back' => 'aadhaar_back',
					'pancard_image' => 'pancard_image'
					];
					
					if(!$object) 
					{
						$object = new UserKyc(); // Create a new KYC record if none exists
						$data['user_id'] = $user->id; // Set the user ID for a new record
					}
					
					foreach ($fields as $inputName => $dbFieldName) 
					{
						if ($request->hasFile($inputName)) 
						{
							if ($object->$dbFieldName && Storage::disk('public')->exists($object->$dbFieldName)) {
								Storage::disk('public')->delete($object->$dbFieldName);
							}
							
							$file = $request->file($inputName);
							$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
							$filePath = $file->storeAs('uploads/kyc', $filename, 'public');
							$data[$dbFieldName] = $filePath;
						}
					}
					
					Helper::saveData($object, $data);
					
					$get_user = User::findOrFail($user->id);
					$oldImagePath = $get_user->image;
					$user_data = [];
					
					if ($request->hasFile('profile')) {
						$file = $request->file('profile');
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/profile', $filename, 'public');
						
						$user_data['profile'] = $filePath;
						
						if ($oldImagePath && Storage::disk('public')->exists($oldImagePath)) {
							Storage::disk('public')->delete($oldImagePath);
						}
					}
					
					if($request->input('dob'))
					{
						$user_data['dob'] = date('Y-m-d',strtotime($request->input('dob')));
					}
					
					Helper::saveData($get_user,$user_data);
					
					$get_user_kyc = UserKyc::with('user:id,name,profile,dob')->where('user_id', $user->id)->first();
					
					$user_kyc[] = '';
					
					if($get_user_kyc)
					{
						$user_kyc['aadhaar_front'] = $get_user_kyc->aadhaar_front;
						$user_kyc['aadhaar_back'] = $get_user_kyc->aadhaar_back;
						$user_kyc['aadhaar_number'] = $get_user_kyc->aadhaar_number;
						$user_kyc['is_aadhaar'] = $get_user_kyc->is_aadhaar;
						$user_kyc['aadhaar_note'] = $get_user_kyc->aadhaar_note;
						$user_kyc['pancard_image'] = $get_user_kyc->pancard_image;
						$user_kyc['pancard_number'] = $get_user_kyc->pancard_number;
						$user_kyc['is_pancard'] = $get_user_kyc->is_pancard;
						$user_kyc['pancard_note'] = $get_user_kyc->pancard_note;
						$user_kyc['bank_details'] = ['bank_name' => $get_user_kyc->bank_name,'account_number' => $get_user_kyc->account_number,'ifsc_code' => $get_user_kyc->ifsc_code,'account_type' => $get_user_kyc->account_type,'is_bank_account' => $get_user_kyc->is_bank_account,'bank_account_note' => $get_user_kyc->bank_account_note];
						
						$wallet_details[] = ['title' => 'Trust Wallet', 'wallet_address' => $get_user_kyc->trust_wallet, 'qr_code' => ''];
						$wallet_details[] = ['title' => 'Metamask Wallet', 'wallet_address' => $get_user_kyc->metamask_wallet, 'qr_code' => ''];
						$wallet_details[] = ['title' => 'Ekaum Wallet', 'wallet_address' => $get_user_kyc->ekaum_wallet, 'qr_code' => ''];
						$wallet_details[] = ['title' => 'Phantom Wallet', 'wallet_address' => $get_user_kyc->phantom_wallet, 'qr_code' => ''];
						$wallet_details[] = ['title' => '1 Inch Wallet', 'wallet_address' => $get_user_kyc->one_inch_wallet, 'qr_code' => ''];
						$wallet_details[] = ['title' => 'Electrum Wallet', 'wallet_address' => $get_user_kyc->electrum_wallet, 'qr_code' => ''];
						
						$user_kyc['wallet_details'] = $wallet_details;
						$user_kyc['upi_details'] = ['upi_address' => $get_user_kyc->upi_address, 'qr_code' => ''];
						$user_kyc['profile'] = $get_user_kyc->user->profile;
						$user_kyc['dob'] = $get_user_kyc->user->dob;
					}
					
					DB::commit();
					return response()->json(['status' => true, 'message' => 'The User KYC Information Send successfully.', 'data' => $user_kyc]);
				}
				catch (\Throwable $e)
				{
					DB::rollBack();
					$message = $e->getMessage();
					return response()->json(['status' => false, 'message' => $message]);
				}
			}
		}
	}
