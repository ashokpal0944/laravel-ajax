<?php
	
	namespace App\Http\Controllers\Admin;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use App\Models\User;
	use App\Models\UserKyc;
	use App\Models\UserWallet;
	use App\Models\PurchaseCourse;
	use App\Models\Trading;
	use App\Models\Rehab;
	use App\Models\Business;
	use App\Models\UserInvestment;
	use App\Models\UserReturnOnInterest;
	use Helper, DB, Validator;
	
	class UserController extends Controller
	{
		public function __construct()
		{
			$this->middleware('admin');
		}
		
		public function index()
		{
			return view('admin.user.index');
		}
		
		public function add()
		{
			$view = view('admin.live-trade.add')->render();
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function getUserDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = auth()->guard('admin')->user();
			
			$query = User::where('id','!=','');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('name', 'LIKE', "%{$search}%")
					->orWhere('username', 'LIKE', "%{$search}%")
					->orWhere('email', 'LIKE', "%{$search}%")
					->orWhere('phone_number', 'LIKE', "%{$search}%")
					->orWhere('referral_code', 'LIKE', "%{$search}%")
					->orWhere('created_at', 'LIKE', "%{$search}%");
				});
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if($value->profile)
					{
						$image = '<img src="'. url('public/storage/'.$value->profile) .'" class="img-fluid " width="50px"/>';	
					}
					else
					{
						$firstCharacter = strtolower(substr($value->name, 0, 1));
						$image = '<img src="'. url('front/images/letter/'.$firstCharacter.'.png') .'" class="img-fluid " width="50px"/>';
					}
					
					
					$mainData['id'] = $i;  
					$mainData['profile'] = $image;
					$mainData['name'] = $value->name;
					$mainData['username'] = $value->username;
					$mainData['email'] = $value->email;
					$mainData['phone_number'] = $value->phone_number;
					$mainData['referral_code'] = $value->referral_code;
					$mainData['is_status'] = $value->is_status == 1 ? '<span class="badge badge-success badge-pill">Active</span>' : '<span class="badge badge-danger badge-pill">In Active</span>';
					$mainData['email_verify'] = $value->email_verified_at != '' ? '<span class="badge badge-success badge-pill">Yes</span>' : '<span class="badge badge-danger badge-pill">No</span>';
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$mainData['action'] = '<a href="'.url('admin/user/view',$value->id).'" onclick="viewUserData(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-pencil-alt" aria-hidden="true"></i></button></a>';
					
					if(empty($value->email_verified_at))
					{
						$mainData['action'] .= '<a href="'.url('admin/user/email-verify',$value->id).'" onclick="emailVerify(this,event)"><button type="button" class="btn btn-success waves-effect">Email Verify</button></a>';
					}
					
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		} 
		
		public function viewUser($id)
		{
			$get_user = User::with('country:id,name','state:id,name','city:id,name')->whereId($id)->first();  
			$view = view('admin.user.view',compact('get_user'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function emailVerify($id)
		{
			$user = User::findOrFail($id);
			
			$currentTime = now();
			
			$user->email_verified_at = $currentTime;
			$user->updated_at = $currentTime;
			$user->save();
			
			return response()->json(['status' => 'success','msg' => 'Email verified successfully.']);
		}
		
		public function viewUpdateData(Request $request, $id)
		{
			$validation = Validator::make($request->all(), [
			'email' => "required|string|email|unique:users,email,$id,id",
			'phone_number' => "required|string|unique:users,phone_number,$id,id",
			'dob' => "required|string",
			'is_status' => 'required|numeric', 
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try
			{  	
				DB::beginTransaction();
				
				$object = User::find($id);
				
				if ($object) 
				{
					$currentTime = now();
					$data = $request->except('_token');
					$data['updated_at'] = $currentTime;
					
					Helper::saveData($object,$data);	
					
					DB::commit();
					return response()->json(['status' => 'success', 'msg' => 'The User Information has been successfully Updated.']);
				}
				else
				{
					return response()->json(['status' => 'error', 'msg' => 'Use Data not found.']);
				}
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		//User KYC list
		public function userKYCList()
		{
			return view('admin.user.kyc.index');
		}
		
		public function getUserKycDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = auth()->guard('admin')->user();
			
			$query = UserKyc::with('user:id,name')->where('id','!=','');
			
			if($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) {
					$q->where('aadhaar_number', 'LIKE', "%{$search}%")
					->orWhere('pancard_number', 'LIKE', "%{$search}%")
					->orWhere('account_number', 'LIKE', "%{$search}%")
					->orWhere('bank_name', 'LIKE', "%{$search}%")
					->orWhere('ifsc_code', 'LIKE', "%{$search}%")
					->orWhere('account_type', 'LIKE', "%{$search}%")
					->orWhere('created_at', 'LIKE', "%{$search}%")
					->orWhereHas('user', function ($query) use ($search) {
						$query->where('name', 'LIKE', "%{$search}%");
					});
				});
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_aadhaar == 2 || $value->is_pancard == 2 || $value->is_bank_account == 2) {
						$kyc_status = '<span class="badge badge-danger badge-pill">Reject</span>';
						} elseif ($value->is_aadhaar == 1 && $value->is_pancard == 1 && $value->is_bank_account == 1) {
						$kyc_status = '<span class="badge badge-success badge-pill">Approve</span>';
						} elseif ($value->is_aadhaar == 0 && $value->is_pancard == 0 && $value->is_bank_account == 0) {
						$kyc_status = '<span class="badge badge-warning badge-pill">Pending</span>';
						} else {
						$kyc_status = '<span class="badge badge-warning badge-pill">Re - Submitted</span>';
					}
					
					$mainData['id'] = $i;  
					$mainData['name'] = $value->user->name;
					$mainData['aadhaar_number'] = $value->aadhaar_number;
					$mainData['pancard_number'] = $value->pancard_number;
					$mainData['bank_details'] = "Bank Name: <b>" . $value->bank_name .'</b><br>'. "Account Number: <b>" . $value->account_number . '</b><br>' . "IFSC Code: <b>" .$value->ifsc_code . '</b><br>' . 'Account Type: <b>'.$value->account_type . '</b>';
					$mainData['kyc_status'] = $kyc_status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$mainData['action'] = '<a href="'.url('admin/user/kyc/edit',$value->id).'"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-pencil-alt" aria-hidden="true"></i></button></a>';  
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		public function editUserKYC($id)
		{
			$get_user_kyc = UserKyc::with('user:id,name')->whereId($id)->first();  
			return view('admin.user.kyc.edit',compact('get_user_kyc'));
		}
		
		public function changeKycStatus(Request $request)
		{
			try {
				DB::beginTransaction();
				
				$id = $request->input('id');
				$object = UserKyc::find($id);
				
				if (!$object) {
					return response()->json(['status' => 'error', 'msg' => 'User Kyc Data not found.']);
				}
				
				$currentTime = now();
				$statusname = $request->input('statusname');
				$code = $request->input('code');
				$note = $request->input('note');
				
				// Prepare data for update
				$data = [
				'updated_at' => $currentTime
				];
				
				switch ($statusname) {
					case 'Pan Card':
					$data['is_pancard'] = $code;
					$data['pancard_note'] = $note;
					break;
					case 'Bank Account':
					$data['is_bank_account'] = $code;
					$data['bank_account_note'] = $note;
					break;
					case 'Aadhaar Card':
					$data['is_aadhaar'] = $code;
					$data['aadhaar_note'] = $note;
					break;
					default:
					return response()->json(['status' => 'error', 'msg' => 'Invalid status name.']);
				}
				
				Helper::saveData($object, $data);
				DB::commit();
				
				$message = ($code == 1) ? 'The User Kyc has been Approved successfully.' : 'The User Kyc has been Rejected successfully.';
				return response()->json(['status' => 'success', 'msg' => $message]);
				
				} catch (\Throwable $e) {
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => $e->getMessage()]);
			}
		}
		
		//Premium Subscription
		public function userPremiumSubscriptionList()
		{
			$get_users = User::where('email_verified_at','!=',NULL)->get();
			return view('admin.user.premium-subscription.index',compact('get_users'));
		}
		
		public function getUserPremiumSubscriptionDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$query = UserWallet::with('user:id,name')->where('transaction_type','Premium Subscription');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('transaction_method', 'LIKE', "%{$search}%")->orWhere('amount', 'LIKE', "%{$search}%")->orWhere('transaction_id', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%")->orWhereHas('user', function ($uq) use ($search) { // Filter by user name
						$uq->where('name', 'LIKE', "%{$search}%");
					});
				});
			}
			
			if ($userId = $request->input('user_id')) {
				$query->where('user_id', $userId); // Use $query instead of $q
			}
			
			$status = $request->input('status');
			
			if (isset($status)) {
				$query->where('is_status', $status); 
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Approved</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$transaction_image = 'N/A';
					if($value->transaction_image)
					{
						$transaction_image = '<img src="'. url('public/storage/'.$value->transaction_image) .'" class="img-fluid " width="100px"/>';
					}
					
					$mainData['id'] = $i;
					$mainData['user_name'] = $value->user->name;
					$mainData['transaction_method'] = $value->transaction_method;
					$mainData['transaction_wallet_address'] = $value->transaction_wallet_address;
					$mainData['amount'] = $value->amount;
					$mainData['transaction_id'] = $value->transaction_id;
					$mainData['is_status'] = $status;
					$mainData['transaction_image'] = $transaction_image;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					if ($value->is_status == 0)
					{
						$mainData['action'] = '<a href="'.url('admin/user/premium-subscription/approve',$value->id).'" onclick="approveDeposit(this,event)" ><button type="button" class="btn btn-primary btn-xs"> Approve </button></a> | <a href="'.url('admin/user/premium-subscription/reject',$value->id).'" onclick="rejectDepositAmount(this,event)"><button type="button" class="btn btn-danger btn-xs"> Reject</button></a>';  
					}
					else
					{
						$mainData['action'] = 'N/A';
					}
					
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		public function approvePremiumSubscription(Request $request, $id)
		{
			try 
			{
				DB::beginTransaction();
				
				$userWallet = UserWallet::findOrFail($id);
				
				$user = User::findOrFail($userWallet->user_id);
				$user->is_premium_member = 1;
				$user->save();
				
				$data = $request->except('_token');
				$data['updated_at'] = now();
				$data['is_status'] = 1; 
				
				Helper::saveData($userWallet, $data);
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => 'Premium Subscription Approved successfully.']);
			} 
			catch (\Throwable $e) 
			{
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => 'An error occurred: ' . $e->getMessage()]);
			}
		}
		
		public function rejectPremiumSubscription($id)
		{
			$get_user_wallet = UserWallet::whereId($id)->first();  
			$view = view('admin.user.deposit.reject',compact('get_user_wallet'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function rejectPremiumSubscriptionData(Request $request, $id)
		{
			$validation = Validator::make($request->all(), [
			'transaction_note' => "required|string",
			]);
			
			if ($validation->fails()) {
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			try {
				DB::beginTransaction();
				
				$userWallet = UserWallet::findOrFail($id);
				
				$data = $request->except('_token');
				$data['updated_at'] = now();
				$data['is_status'] = 2; // Set status to rejected
				
				Helper::saveData($userWallet, $data);
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => 'The Premium Subscription request has been successfully rejected.']);
				} catch (\Throwable $e) {
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => 'An error occurred: ' . $e->getMessage()]);
			}
		}
		
		//Deposit
		public function userDepositList()
		{
			$get_users = User::where('email_verified_at','!=',NULL)->get();
			return view('admin.user.deposit.index',compact('get_users'));
		}
		
		public function getUserDepositDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$query = UserWallet::with('user:id,name')->where('transaction_type','Deposit');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('transaction_method', 'LIKE', "%{$search}%")->orWhere('amount', 'LIKE', "%{$search}%")->orWhere('transaction_id', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%")->orWhereHas('user', function ($uq) use ($search) { // Filter by user name
						$uq->where('name', 'LIKE', "%{$search}%");
					});
				});
			}
			
			if ($userId = $request->input('user_id')) {
				$query->where('user_id', $userId); // Use $query instead of $q
			}
			
			$status = $request->input('status');
			
			if (isset($status)) {
				$query->where('is_status', $status); 
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Approved</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$transaction_image = 'N/A';
					if($value->transaction_image)
					{
						$transaction_image = '<img src="'. url('public/storage/'.$value->transaction_image) .'" class="img-fluid " width="100px"/>';
					}
					
					$mainData['id'] = $i;
					$mainData['user_name'] = $value->user->name;
					$mainData['transaction_method'] = $value->transaction_method;
					$mainData['transaction_wallet_address'] = $value->transaction_wallet_address;
					$mainData['amount'] = $value->amount;
					$mainData['transaction_id'] = $value->transaction_id;
					$mainData['is_status'] = $status;
					$mainData['transaction_image'] = $transaction_image;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					if ($value->is_status == 0)
					{
						$mainData['action'] = '<a href="'.url('admin/user/deposit/approve',$value->id).'" onclick="approveDeposit(this,event)" ><button type="button" class="btn btn-primary btn-xs"> Approve </button></a> | <a href="'.url('admin/user/deposit/reject',$value->id).'" onclick="rejectDepositAmount(this,event)"><button type="button" class="btn btn-danger btn-xs"> Reject</button></a>';  
					}
					else
					{
						$mainData['action'] = 'N/A';
					}
					
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		public function approveDeposit(Request $request, $id)
		{
			try 
			{
				DB::beginTransaction();
				
				$userWallet = UserWallet::findOrFail($id);
				
				$user = User::findOrFail($userWallet->user_id);
				$user->wallet_balance += $userWallet->amount;
				$user->save();
				
				$data = $request->except('_token');
				$data['updated_at'] = now();
				$data['is_status'] = 1; 
				
				Helper::saveData($userWallet, $data);
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => 'Deposit approved successfully.']);
			} 
			catch (\Throwable $e) 
			{
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => 'An error occurred: ' . $e->getMessage()]);
			}
		}
		
		public function rejectDeposit($id)
		{
			$get_user_wallet = UserWallet::whereId($id)->first();  
			$view = view('admin.user.deposit.reject',compact('get_user_wallet'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function rejectDepositData(Request $request, $id)
		{
			$validation = Validator::make($request->all(), [
			'transaction_note' => "required|string",
			]);
			
			if ($validation->fails()) {
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			try {
				DB::beginTransaction();
				
				$userWallet = UserWallet::findOrFail($id);
				
				$data = $request->except('_token');
				$data['updated_at'] = now();
				$data['is_status'] = 2; // Set status to rejected
				
				Helper::saveData($userWallet, $data);
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => 'The deposit request has been successfully rejected.']);
				} catch (\Throwable $e) {
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => 'An error occurred: ' . $e->getMessage()]);
			}
		}
		
		//withdrawal
		public function userWithdrawalList()
		{
			$get_users = User::where('email_verified_at','!=',NULL)->get();
			return view('admin.user.withdrawal.index',compact('get_users'));
		}
		
		public function getUserWithdrawalDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$query = UserWallet::with('user:id,name')->where('transaction_type','Withdrawal');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('transaction_method', 'LIKE', "%{$search}%")->orWhere('amount', 'LIKE', "%{$search}%")->orWhere('transaction_id', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%")->orWhereHas('user', function ($uq) use ($search) { // Filter by user name
						$uq->where('name', 'LIKE', "%{$search}%");
					});
				});
			}
			
			if ($userId = $request->input('user_id')) {
				$query->where('user_id', $userId); // Use $query instead of $q
			}
			
			$status = $request->input('status');
			
			if (isset($status)) {
				$query->where('is_status', $status); 
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Approved</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$transaction_image = 'N/A';
					if($value->transaction_image)
					{
						$transaction_image = '<img src="'. url('public/storage/'.$value->transaction_image) .'" class="img-fluid " width="100px"/>';
					}
					
					$mainData['id'] = $i;
					$mainData['user_name'] = $value->user->name;
					$mainData['transaction_method'] = $value->transaction_method;
					$mainData['transaction_wallet_address'] = $value->transaction_wallet_address;
					$mainData['amount'] = $value->amount;
					$mainData['transaction_id'] = $value->transaction_id;
					$mainData['is_status'] = $status;
					$mainData['transaction_image'] = $transaction_image;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					if ($value->is_status == 0)
					{
						$mainData['action'] = '<a href="'.url('admin/user/withdrawal/approve',$value->id).'" onclick="approveWithdrawal(this,event)" ><button type="button" class="btn btn-primary btn-xs"> Approve </button></a> | <a href="'.url('admin/user/withdrawal/reject',$value->id).'" onclick="rejectWithdrawalAmount(this,event)"><button type="button" class="btn btn-danger btn-xs"> Reject</button></a>';  
					}
					else
					{
						$mainData['action'] = 'N/A';
					}
					
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		public function approveWithdrawal(Request $request, $id)
		{
			try 
			{
				DB::beginTransaction();
				
				$userWallet = UserWallet::findOrFail($id);
				
				$data = $request->except('_token');
				$data['updated_at'] = now();
				$data['is_status'] = 1; 
				
				Helper::saveData($userWallet, $data);
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => 'Withdrawal Request approved successfully.']);
			} 
			catch (\Throwable $e) 
			{
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => 'An error occurred: ' . $e->getMessage()]);
			}
		}
		
		public function rejectWithdrawal($id)
		{
			$get_user_wallet = UserWallet::whereId($id)->first();  
			$view = view('admin.user.withdrawal.reject',compact('get_user_wallet'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function rejectWithdrawalData(Request $request, $id)
		{
			// Validate the input data
			$validation = Validator::make($request->all(), [
			'transaction_note' => "required|string",
			]);
			
			if ($validation->fails()) {
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			try {
				DB::beginTransaction();
				
				$userWallet = UserWallet::findOrFail($id);
				
				$user = User::findOrFail($userWallet->user_id);
				
				$user->wallet_balance += $userWallet->amount;
				$user->save();
				
				$data = $request->except('_token');
				$data['updated_at'] = now();
				$data['is_status'] = 2;
				
				Helper::saveData($userWallet, $data);
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => 'The withdrawal request has been successfully rejected.']);
				} catch (\Throwable $e) {
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => 'An error occurred: ' . $e->getMessage()]);
			}
		}
		
		//Purchase
		public function userPurchaseList()
		{
			return view('admin.user.purchase.index');
		}
		
		public function getUserPurchaseDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$query = PurchaseCourse::with('user:id,name');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('course_type', 'LIKE', "%{$search}%")
					->orWhere('course_price', 'LIKE', "%{$search}%")
					->orWhere('start_date', 'LIKE', "%{$search}%")
					->orWhere('start_date', 'LIKE', "%{$search}%")
					->orWhere('expire_date', 'LIKE', "%{$search}%")
					->orWhereHas('user', function ($userQuery) use ($search) {
						$userQuery->where('name', 'LIKE', "%{$search}%");
					});
				});
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) 
					{
						$status = '<span class="badge badge-success badge-pill">Active</span>';
					}
					elseif ($value->is_status == 2) 
					{
						$status = '<span class="badge badge-danger badge-pill">Expire</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					if($value->course_type == "Trading")
					{
						$course_name = Trading::where('id',$value->course_id)->first()->title;
					}
					else if($value->course_type == "Rehab")
					{
						$course_name = Rehab::where('id',$value->course_id)->first()->courses;
					}
					else
					{
						$course_name = Business::where('id',$value->course_id)->first()->title;
					}
					
					$mainData['id'] = $i;
					$mainData['user_name'] = $value->user->name;
					$mainData['course_name'] = $course_name;
					$mainData['course_type'] = $value->course_type;
					$mainData['course_price'] = $value->course_price;
					$mainData['start_date'] = $value->start_date;
					$mainData['expire_date'] = $value->expire_date;
					$mainData['is_status'] = $status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at));
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		//Investment
		public function userInvestmentList()
		{
			return view('admin.user.investment.index');
		}
		
		public function getUserInvestmentDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$query = UserInvestment::with('investmentPlan:id,plan_name,investment_amount','user:id,name');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('investment_amount', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%")->orWhereHas('investmentPlan', function ($userQuery) use ($search) {
						$userQuery->where('plan_name', 'LIKE', "%{$search}%");
						}) ->orWhereHas('user', function ($userQuery) use ($search) {
						$userQuery->where('name', 'LIKE', "%{$search}%");
					});
				});
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Approved</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$mainData['id'] = $i;
					$mainData['user_name'] = $value->user->name;
					$mainData['investment_plan'] = $value->investmentPlan->plan_name;
					$mainData['investment_amount'] = $value->investment_amount;
					$mainData['is_status'] = $status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at));
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		//Return On investment
		public function userROIList()
		{
			return view('admin.user.roi-investment.index');
		}
		
		public function getUserRoiDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$query = UserReturnOnInterest::with('userinvestment:id,user_id,investment_plan_id','userinvestment.investmentPlan:id,plan_name,investment_amount','userinvestment.user:id,name');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) {
					$q->where('total_return_of_interest', 'LIKE', "%{$search}%")
					->orWhere('total_payable_amount', 'LIKE', "%{$search}%")
					->orWhere('created_at', 'LIKE', "%{$search}%")
					->orWhereHas('userinvestment.investmentPlan', function ($userQuery) use ($search) {
						$userQuery->where('plan_name', 'LIKE', "%{$search}%")
						->orWhere('investment_amount', 'LIKE', "%{$search}%");
					})
					->orWhereHas('userinvestment.user', function ($userQuery) use ($search) {
						$userQuery->where('name', 'LIKE', "%{$search}%");
					});
				});
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Approved</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$mainData['id'] = $i;
					$mainData['user_name'] = $value->userinvestment->user->name;
					$mainData['investment_plan'] = $value->userinvestment->investmentPlan->plan_name;
					$mainData['investment_amount'] = $value->userinvestment->investmentPlan->investment_amount;
					$mainData['roi_interest'] = number_format($value->total_return_of_interest,2) ;
					$mainData['roi_amount'] = $value->total_payable_amount;
					$mainData['is_status'] = $status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at));
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		function interestPay()
		{
			$view = view('admin.user.roi-investment.interest-pay')->render();
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		function payInterestAmount(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'total_return_of_interest' => 'required',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try 
			{
				DB::beginTransaction();
				
				$total_return_of_interest = $request->input('total_return_of_interest');
				$currentTime = now();
				
				UserInvestment::with('user:id,name,wallet_balance')
				->where('is_status', 1)
				->where('is_payable', 0)
				->chunk(1000, function ($investments) use ($total_return_of_interest, $currentTime) {
					
					$user_wallet_updates = [];
					$return_on_interest_inserts = [];
					
					foreach ($investments as $investment) 
					{
						$returnOfInterest =  UserReturnOnInterest::where('user_investment_id',$investment->id)->sum('total_return_of_interest');
						$returnOnInvestment = $investment->return_on_investment;
						
						if ($returnOnInvestment < ($returnOfInterest + $total_return_of_interest)) 
						{
							$totalReturnOfInterest = $returnOnInvestment - $returnOfInterest;
							
							$investment->is_payable = 1;
							$investment->save();
						} 
						else 
						{
							$totalReturnOfInterest = $total_return_of_interest;
						}
						
						$total_payable_amount = ($investment->investment_amount * $totalReturnOfInterest) / 100;
						
						$investment->increment('total_payable_amount', $total_payable_amount);
						
						$return_on_interest_inserts[] = [
						'user_investment_id' => $investment->id,
						'total_return_of_interest' => $totalReturnOfInterest,
						'total_payable_amount' => $total_payable_amount,
						'created_at' => $currentTime,
						'updated_at' => $currentTime,
						];
						
						$user_wallet_updates[] = [
						'user_id' => $investment->user->id,
						'transaction_method' => 'Return On Investment',
						'transaction_wallet_address' => $investment->id,
						'amount' => $total_payable_amount,
						'transaction_type' => 'Return Of Interest',
						'is_status' => 1,
						'created_at' => $currentTime,
						'updated_at' => $currentTime,
						];
						
						$investment->user->wallet_balance += $total_payable_amount;
						$investment->user->save(); // Save the updated wallet balance
					}
					
					if (!empty($return_on_interest_inserts)) {
						UserReturnOnInterest::insert($return_on_interest_inserts);
					}
					
					if (!empty($user_wallet_updates)) {
						UserWallet::insert($user_wallet_updates);
					} 
				});
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'Return Of Intrest successfully added.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
	}												