<?php
	
	namespace App\Http\Controllers\Admin;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use App\Models\Admin;
	use Validator, DB, HASH, Helper;
	
	class ProfileController extends Controller
	{
		public function __construct()
		{
			$this->middleware('admin');
		}
		
		public function index()
		{
			return view('admin.profile.index');
		}
		
		public function updateProfile(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'name' => 'required|string|max:255',
			'email' => 'required|email|max:255',
			'password' => 'nullable|string|min:6|max:50',
			'profile' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try 
			{
				DB::beginTransaction();
				
				$currentTime = now();
				$data = $request->except('_token', 'profile', 'password');
				$data['updated_at'] = $currentTime;
				
				if ($request->hasFile('profile')) {
					$file = $request->file('profile');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/profile', $filename, 'public');
					$data['profile'] = $filePath; // Store the path in the database
				}
				
				if ($request->filled('password')) {
					$data['password'] = Hash::make($request->input('password'));
				} 
				
				$admin_id = auth()->guard('admin')->id();
			
				$object = Admin::find($admin_id);
				Helper::saveData($object, $data);
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => 'The profile has been successfully updated.'], 200);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			}
		}
	}					