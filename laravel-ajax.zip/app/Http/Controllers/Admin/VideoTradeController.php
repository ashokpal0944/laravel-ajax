<?php
	
	namespace App\Http\Controllers\Admin;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use Illuminate\Validation\Rule;
	use App\Models\Video;
	use Helper, DB, Validator;
	
	class VideoTradeController extends Controller
	{
		public function __construct()
		{
			$this->middleware('admin');
		}
		
		public function index()
		{
			return view('admin.video.index');
		}
		
		public function add()
		{
			$view = view('admin.video.add')->render();
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function getVideoDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = auth()->guard('admin')->user();
			
			$query = Video::where('admin_id', $user->id);

			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('title', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%");
				});
			}

			$totalData = $query->count();

			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();

			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					$thumbnail = '<img src="'. url('public/storage/'.$value->thumbnail) .'" class="img-fluid " width="100px"/>';
					
					 $video = '<video width="220" height="140" controls autoplay>
						  <source src="'. url('public/storage/'.$value->video) .'" type="video/mp4">
						</video>';
					
					$mainData['id'] = $i;  
					$mainData['title'] = $value->title;
					$mainData['thumbnail'] = $thumbnail;
					$mainData['video'] = $video;
					$mainData['is_status'] = $value->is_status == 1 ? '<span class="badge badge-success badge-pill">Active</span>' : '<span class="badge badge-danger badge-pill">In-active</span>';
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$mainData['action'] = '<a href="'.url('admin/video/edit',$value->id).'" onclick="editVideo(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-pencil-alt" aria-hidden="true"></i></button></a> | <a href="'.url('admin/video/delete',$value->id).'" onclick="deleteVideo(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-trash-alt" aria-hidden="true"></i></button></a>';  
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		} 
		
		public function insert(Request $request)
		{
			$validation = Validator::make($request->all(), [
				//'title' => "required|string|unique:videos,title,NULL,id",
				'thumbnail' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
				'video' => 'nullable|file|mimes:mp4|max:51200', // max size in KB (50 MB)
				'is_status' => 'required|numeric', 
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			  
			try
			{  	
				DB::beginTransaction();
				
				$user = auth()->guard('admin')->user();
				$currentTime = now();
				$data = $request->except('_token','thumbnail','video');
				$data['admin_id'] = $user->id;
				$data['created_at'] = $currentTime;
				$data['updated_at'] = $currentTime;
				
				if ($request->hasFile('thumbnail')) {
					$file = $request->file('thumbnail');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/thumbnail', $filename, 'public');
					$data['thumbnail'] = $filePath; // Store the path in the database
				}
				
				if ($request->hasFile('video')) {
					$file = $request->file('video');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/video', $filename, 'public');
					$data['video'] = $filePath; // Store the path in the database
				}
				
				$object = new Video();
				Helper::saveData($object,$data);
				$id = $object->id; 
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Video has been successfully added.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function edit($id)
		{
			$get_video = Video::whereId($id)->first();  
			$view = view('admin.video.edit',compact('get_video'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function update(Request $request, $id)
		{
			$validation = Validator::make($request->all(), [
				//'title' => ['required','string',Rule::unique('videos', 'title')->ignore($id)],
				'thumbnail' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
				'video' => 'nullable|file|mimes:mp4',
				'is_status' => 'required|numeric',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			  
			try
			{  	
				DB::beginTransaction();
				
				$currentTime = now();
				$data = $request->except('_token','thumbnail','video');
				$data['updated_at'] = $currentTime;
				
				if ($request->hasFile('thumbnail')) {
					$file = $request->file('thumbnail');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/thumbnail', $filename, 'public');
					$data['thumbnail'] = $filePath; // Store the path in the database
				}
				
				if ($request->hasFile('video')) {
					$file = $request->file('video');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/video', $filename, 'public');
					$data['video'] = $filePath; // Store the path in the database
				}
				
				$object = Video::find($id);
				Helper::saveData($object,$data);	
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Video has been successfully Updated.']);
				
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function delete(Request $request, $id)
		{
			try
			{
				DB::beginTransaction(); 
				Video::find($id)->delete();
				
				DB::commit();
				return response()->json(['status'=>'success','msg'=>'The Video has been successfully deleted.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			}
		}
	}				