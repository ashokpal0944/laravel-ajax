<?php
	
	namespace App\Http\Controllers\Admin;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use Illuminate\Validation\Rule;
	use App\Models\AiBots;
	use App\Models\AiStrategy;
	use App\Models\AiBotPurchase;
	use Helper, DB, Validator, Storage;
	
	class AiBotsController extends Controller
	{
		public function __construct()
		{
			$this->middleware('admin');
		}
		
		public function index()
		{
			return view('admin.ai-bots.index');
		}
		
		public function add()
		{
			$view = view('admin.ai-bots.add')->render();
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function getAiBotsAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = auth()->guard('admin')->user();
			
			$query = AiBots::where('admin_id', $user->id);
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('title', 'LIKE', "%{$search}%")->orWhere('currency_type', 'LIKE', "%{$search}%")->orWhere('risk_type', 'LIKE', "%{$search}%")->orWhere('min_amount', 'LIKE', "%{$search}%")->orWhere('max_amount', 'LIKE', "%{$search}%")->orWhere('yearly_return', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%");
				});
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					$icon = '<img src="'. url('public/storage/'.$value->icon) .'" class="img-fluid " width="100px"/>';
					
					$mainData['id'] = $i;  
					$mainData['icon'] = $icon;
					$mainData['title'] = $value->title;
					$mainData['currency_type'] = $value->currency_type;
					$mainData['risk_type'] = $value->risk_type;
					$mainData['min_amount'] = $value->min_amount;
					$mainData['max_amount'] = $value->max_amount;
					$mainData['yearly_return'] = $value->yearly_return;
					$mainData['description'] = substr($value->description, 0, 30);
					$mainData['is_status'] = $value->is_status == 1 ? '<span class="badge badge-success badge-pill">Active</span>' : '<span class="badge badge-danger badge-pill">In-active</span>';
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$mainData['action'] = '<a href="'.url('admin/ai-bots/edit',$value->id).'" onclick="editAiBots(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-pencil-alt" aria-hidden="true"></i></button></a> | <a href="'.url('admin/ai-bots/delete',$value->id).'" onclick="deleteAiBots(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-trash-alt" aria-hidden="true"></i></button></a> <br><a href="'.url('admin/ai-bots/strategy',$value->id).'"><button type="button" class="btn btn-light waves-effect">Strategy</button></a> | <a href="javascript:void(0);"><button type="button" class="btn btn-light waves-effect">Copying</button></a>';  
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		} 
		
		public function insert(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'currency_type' => "required|string",
			'risk_type' => "required|string",
			'title' => "required|string",
			'icon' => 'required|file|mimes:jpeg,png,jpg|max:2048',
			'min_amount' => 'required', 
			'max_amount' => 'required', 
			'yearly_return' => 'required', 
			'description' => 'required|string', 
			'is_status' => 'required|numeric', 
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			$check_ai_bots = AiBots::where('currency_type',$request->input('currency_type'))->where('risk_type',$request->input('risk_type'))->first();
				
			if($check_ai_bots)
			{
				return response()->json(['status' => 'error', 'msg' => 'The AI bots have already been added.']);
			}
			
			try
			{  	
				DB::beginTransaction();
				
				$user = auth()->guard('admin')->user();
				$currentTime = now();
				$data = $request->except('_token','icon');
				$data['admin_id'] = $user->id;
				$data['created_at'] = $currentTime;
				$data['updated_at'] = $currentTime;
				
				if ($request->hasFile('icon')) {
					$file = $request->file('icon');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/icon', $filename, 'public');
					$data['icon'] = $filePath; // Store the path in the database
				}
				
				$object = new AiBots();
				Helper::saveData($object,$data);
				$id = $object->id; 
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Ai Bots has been successfully added.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function edit($id)
		{
			$get_ai_bots = AiBots::whereId($id)->first();  
			$view = view('admin.ai-bots.edit',compact('get_ai_bots'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function update(Request $request, $id)
		{
			$validation = Validator::make($request->all(), [
			'currency_type' => "required|string",
			'risk_type' => "required|string",
			'title' => "required|string",
			'icon' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			'min_amount' => 'required', 
			'max_amount' => 'required', 
			'yearly_return' => 'required', 
			'description' => 'required|string', 
			'is_status' => 'required|numeric', 
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			$check_ai_bots = AiBots::where('id','!=',$id)->where('currency_type',$request->input('currency_type'))->where('risk_type',$request->input('risk_type'))->first();
				
			if($check_ai_bots)
			{
				return response()->json(['status' => 'error', 'msg' => 'The AI bots have already been added.']);
			}
			
			try
			{  	
				DB::beginTransaction();
				
				$object = AiBots::find($id);
				
				if ($object) 
				{
					$currentTime = now();
					$data = $request->except('_token','icon');
					$data['updated_at'] = $currentTime;
					
					$oldImagePath = $object->icon;
					
					if ($request->hasFile('icon')) {
						$file = $request->file('icon');
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/icon', $filename, 'public');
						$data['icon'] = $filePath; // Store the path in the database
						
						if ($oldImagePath && Storage::disk('public')->exists($oldImagePath)) {
							Storage::disk('public')->delete($oldImagePath);
						}
					}
					
					Helper::saveData($object,$data);	
					
					DB::commit();
					return response()->json(['status' => 'success', 'msg' => 'The Ai Bots has been successfully Updated.']);
				}
				else
				{
					return response()->json(['status' => 'error', 'msg' => 'Ai Bots Data not found.']);
				}
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function delete(Request $request, $id)
		{
			try
			{
				DB::beginTransaction(); 
				
				$aibots = AiBots::findOrFail($id);
				
				$oldImagePath = $aibots->icon;
				
				$aibots->delete();
				
				if($oldImagePath && Storage::disk('public')->exists($oldImagePath)) 
				{
					Storage::disk('public')->delete($oldImagePath);
				}
				
				DB::commit();
				return response()->json(['status'=>'success','msg'=>'The Ai Bots has been successfully deleted.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			}
		}
		
		//Ai Bot Purchase
		public function aiBotPurchaseList()
		{
			return view('admin.ai-bots.purchase.index');
		}
		
		public function getAiBotsPurchaseDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = auth()->guard('admin')->user();
			
			$query = AiBotPurchase::with('aibot:id,currency_type,risk_type','user:id,name');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('amount', 'LIKE', "%{$search}%")->orWhere('account_holder_name', 'LIKE', "%{$search}%")->orWhere('email', 'LIKE', "%{$search}%")->orWhere('server_name', 'LIKE', "%{$search}%")->orWhere('account_number', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%")->orWhereHas('aibot', function ($userQuery) use ($search) {
						$userQuery->where('currency_type', 'LIKE', "%{$search}%")->orWhere('risk_type', 'LIKE', "%{$search}%");
					})
					->orWhereHas('user', function ($userQuery) use ($search) {
						$userQuery->where('name', 'LIKE', "%{$search}%");
					});
				});
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					$icon = '<img src="'. url('public/storage/'.$value->icon) .'" class="img-fluid " width="100px"/>';
					
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Active</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$mainData['id'] = $i;
					$mainData['user_id'] = $value->user->name;
					$mainData['ai_bot_id'] = $value->aibot->currency_type .','. $value->aibot->risk_type;
					$mainData['amount'] = $value->amount;
					$mainData['account_holder_name'] = $value->account_holder_name;
					$mainData['email'] = $value->email;
					$mainData['server_name'] = $value->server_name;
					$mainData['account_number'] = $value->account_number;
					$mainData['main_password'] = $value->main_password;
					$mainData['investor_password'] = $value->investor_password;
					$mainData['is_status'] = $status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		} 
		
		//Strategy Module
		public function strategyListing($id)
		{
			$get_ai_boat = AiBots::where('id',$id)->first();
			return view('admin.ai-bots.strategy.index',compact('get_ai_boat'));
		}
		
		public function getAiBotsStrategyAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = auth()->guard('admin')->user();
			
			$ai_boat_id = $request->get('ai_boat_id');
			
			$query = AiStrategy::where('ai_boat_id', $ai_boat_id);
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('title', 'LIKE', "%{$search}%")->orWhere('icon_name', 'LIKE', "%{$search}%")->orWhere('investment_price', 'LIKE', "%{$search}%")->orWhere('return_of_intrest', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%");
				});
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					$icon = '<img src="'. url('public/storage/'.$value->icon) .'" class="img-fluid " width="100px"/>';
					
					$mainData['id'] = $i;  
					$mainData['icon'] = $icon;
					$mainData['title'] = $value->title;
					$mainData['icon_name'] = $value->icon_name;
					$mainData['investment_price'] = $value->investment_price;
					$mainData['return_of_intrest'] = $value->return_of_intrest;
					$mainData['chart_data'] = $value->chart_data;
					$mainData['chart_label'] = $value->chart_label;
					$mainData['is_status'] = $value->is_status == 1 ? '<span class="badge badge-success badge-pill">Active</span>' : '<span class="badge badge-danger badge-pill">In-active</span>';
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$mainData['action'] = '<a href="'.url('admin/ai-bots/edit-strategy',$value->id).'" onclick="editAiBotStrategy(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-pencil-alt" aria-hidden="true"></i></button></a> | <a href="'.url('admin/ai-bots/delete-strategy',$value->id).'" onclick="deleteAiBotStrategy(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-trash-alt" aria-hidden="true"></i></button></a>';  
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		} 
		
		public function addStrategy()
		{
			$view = view('admin.ai-bots.strategy.add')->render();
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function addStrategyInsert(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'title' => "required|string",
			'icon_name' => "required|string",
			'icon' => 'required|file|mimes:jpeg,png,jpg|max:2048',
			'investment_price' => 'required', 
			'return_of_intrest' => 'required', 
			'chart_data' => 'required', 
			'chart_label' => 'required|string', 
			'is_status' => 'required|numeric', 
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try
			{  	
				DB::beginTransaction();
				
				$user = auth()->guard('admin')->user();
				$currentTime = now();
				$data = $request->except('_token','icon');
				$data['created_at'] = $currentTime;
				$data['updated_at'] = $currentTime;
				
				if ($request->hasFile('icon')) {
					$file = $request->file('icon');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/icon', $filename, 'public');
					$data['icon'] = $filePath; // Store the path in the database
				}
				
				$object = new AiStrategy();
				Helper::saveData($object,$data);
				$id = $object->id; 
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Ai Bots Strategy has been successfully added.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function editStrategy($id)
		{
			$get_ai_bot_strategy = AiStrategy::whereId($id)->first();  
			$view = view('admin.ai-bots.strategy.edit',compact('get_ai_bot_strategy'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function updateStrategy(Request $request, $id)
		{
			$validation = Validator::make($request->all(), [
				'title' => "required|string",
				'icon_name' => "required|string",
				'icon' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
				'investment_price' => 'required', 
				'return_of_intrest' => 'required', 
				'chart_data' => 'required', 
				'chart_label' => 'required|string', 
				'is_status' => 'required|numeric', 
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try
			{  	
				DB::beginTransaction();
				
				$object = AiStrategy::find($id);
				
				if ($object) 
				{
					$currentTime = now();
					$data = $request->except('_token','icon');
					$data['updated_at'] = $currentTime;
					
					$oldImagePath = $object->icon;
					
					if ($request->hasFile('icon')) {
						$file = $request->file('icon');
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/icon', $filename, 'public');
						$data['icon'] = $filePath; // Store the path in the database
						
						if ($oldImagePath && Storage::disk('public')->exists($oldImagePath)) {
							Storage::disk('public')->delete($oldImagePath);
						}
					}
					
					Helper::saveData($object,$data);	
					
					DB::commit();
					return response()->json(['status' => 'success', 'msg' => 'The Ai Bots Strategy has been successfully Updated.']);
				}
				else
				{
					return response()->json(['status' => 'error', 'msg' => 'Ai Bots Strategy Data not found.']);
				}
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function deleteStrategy($id)
		{
			try
			{
				DB::beginTransaction(); 
				
				$aibotStrategy = AiStrategy::findOrFail($id);
				
				$oldImagePath = $aibotStrategy->icon;
				
				$aibotStrategy->delete();
				
				if($oldImagePath && Storage::disk('public')->exists($oldImagePath)) 
				{
					Storage::disk('public')->delete($oldImagePath);
				}
				
				DB::commit();
				return response()->json(['status'=>'success','msg'=>'The Ai Bots Strategy has been successfully deleted.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			}
		}
	}				