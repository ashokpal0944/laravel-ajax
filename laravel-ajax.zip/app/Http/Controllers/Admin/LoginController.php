<?php
	
	namespace App\Http\Controllers\Admin;
	
	use Illuminate\Support\Facades\Validator;
	use App\Http\Controllers\Controller;
	use Illuminate\Foundation\Auth\AuthenticatesUsers;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Redirect;
	use Illuminate\Support\Facades\Hash;
	use Illuminate\Support\Str;
	
	class LoginController extends Controller
	{
		use AuthenticatesUsers;
		
		//todo: admin login form
		public function show()
		{
			return view('admin.auth.login');
		}
		
		//todo: admin login functionality
		public function loginPost(Request $request)
		{
			$request->validate([
            'email'=>'required',
            'password'=>'required',
			]);
			
			if (Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password])) 
			{
				return redirect()->route('admin.dashboard');
			}
			else
			{
				toastr()->error('Invalid Email or Password');
				return back()->withInput();
			}
		}
		
		//todo: admin logout functionality
		public function logout()
		{
			Auth::guard('admin')->logout();
			return redirect()->route('admin.login');
		}
	}		