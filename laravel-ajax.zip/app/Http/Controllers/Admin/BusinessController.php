<?php
	
	namespace App\Http\Controllers\Admin;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use Illuminate\Validation\Rule;
	use App\Models\Business;
	use Helper, DB, Validator, Storage;
	
	class BusinessController extends Controller
	{
		public function __construct()
		{
			$this->middleware('admin');
		}
		
		public function index()
		{
			return view('admin.business.index');
		}
		
		public function add()
		{
			$view = view('admin.business.add')->render();
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function getBusinessAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = auth()->guard('admin')->user();
			
			$query = Business::where('admin_id', $user->id);
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('title', 'LIKE', "%{$search}%")->orWhere('business_title', 'LIKE', "%{$search}%")->orWhere('duration', 'LIKE', "%{$search}%")->orWhere('package_price', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%");
				});
			}
			
			$totalData = $query->count();
			
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					$image = '<img src="'. url('public/storage/'.$value->image) .'" class="img-fluid " width="100px"/>';
					
					$mainData['id'] = $i;  
					$mainData['image'] = $image;
					$mainData['title'] = $value->title;
					$mainData['business_title'] = $value->business_title;
					$mainData['duration'] = $value->duration;
					$mainData['package_price'] = $value->package_price;
					$mainData['description'] = substr($value->description, 0, 30);
					$mainData['is_status'] = $value->is_status == 1 ? '<span class="badge badge-success badge-pill">Active</span>' : '<span class="badge badge-danger badge-pill">In-active</span>';
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$mainData['action'] = '<a href="'.url('admin/business/edit',$value->id).'" onclick="editBusiness(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-pencil-alt" aria-hidden="true"></i></button></a> | <a href="'.url('admin/business/delete',$value->id).'" onclick="deleteBusiness(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-trash-alt" aria-hidden="true"></i></button></a>';  
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		} 
		
		public function insert(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'title' => "required|string|unique:businesses,title,NULL,id",
			'business_title' => "required|string",
			'image' => 'required|file|mimes:jpeg,png,jpg|max:2048',
			'duration' => 'required|string', 
			'package_price' => 'required', 
			'is_status' => 'required|numeric', 
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try
			{  	
				DB::beginTransaction();
				
				$user = auth()->guard('admin')->user();
				$currentTime = now();
				$data = $request->except('_token','image');
				$data['admin_id'] = $user->id;
				$data['created_at'] = $currentTime;
				$data['updated_at'] = $currentTime;
				
				if ($request->hasFile('image')) {
					$file = $request->file('image');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/image', $filename, 'public');
					$data['image'] = $filePath; // Store the path in the database
				}
				
				$object = new Business();
				Helper::saveData($object,$data);
				$id = $object->id; 
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Business has been successfully added.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function edit($id)
		{
			$get_business = Business::whereId($id)->first();  
			$view = view('admin.business.edit',compact('get_business'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function update(Request $request, $id)
		{
			$validation = Validator::make($request->all(), [
			'title' => "required|string|unique:businesses,title,$id,id",
			'business_title' => "required|string",
			'image' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			'duration' => 'required|string', 
			'package_price' => 'required', 
			'is_status' => 'required|numeric',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try
			{  	
				DB::beginTransaction();
				
				$object = Business::find($id);
				
				if ($object) 
				{
					$currentTime = now();
					$data = $request->except('_token','image');
					$data['updated_at'] = $currentTime;
					
					$oldImagePath = $object->image;
					
					if ($request->hasFile('image')) {
						$file = $request->file('image');
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/image', $filename, 'public');
						$data['image'] = $filePath; // Store the path in the database
						
						if ($oldImagePath && Storage::disk('public')->exists($oldImagePath)) {
							Storage::disk('public')->delete($oldImagePath);
						}
					}
					
					Helper::saveData($object,$data);	
					
					DB::commit();
					return response()->json(['status' => 'success', 'msg' => 'The Business has been successfully Updated.']);
				}
				else
				{
					return response()->json(['status' => 'error', 'msg' => 'Business Data not found.']);
				}
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function delete(Request $request, $id)
		{
			try
			{
				DB::beginTransaction(); 
				
				$business = Business::findOrFail($id);
				
				$oldImagePath = $business->image;
				
				$business->delete();
				
				if($oldImagePath && Storage::disk('public')->exists($oldImagePath)) 
				{
					Storage::disk('public')->delete($oldImagePath);
				}
				
				DB::commit();
				return response()->json(['status'=>'success','msg'=>'The Business has been successfully deleted.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			}
		}
	}				