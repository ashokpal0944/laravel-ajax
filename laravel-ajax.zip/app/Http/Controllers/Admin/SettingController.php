<?php
	
	namespace App\Http\Controllers\Admin;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use App\Models\Admin;
	use App\Models\Setting;
	use Validator, DB, HASH, Helper, Storage;
	
	class SettingController extends Controller
	{
		public function __construct()
		{
			$this->middleware('admin');
		}
		
		public function index()
		{
			
			return view('admin.setting.index');
		}
		
		public function updateSettingData(Request $request)
		{
			/* $validation = Validator::make($request->all(), [
				'website_title' => 'required|string|max:255',
				'email' => 'nullable|email|max:255',
				'contact_number' => 'nullable|string',
				'logo' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
				'fevicon_icon' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
				'address' => 'nullable|string',
				]);
				
				if ($validation->fails()) 
				{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}  */
			
			try 
			{
				DB::beginTransaction();
				
				$currentTime = now();
				$data = $request->except('_token', 'logo', 'fevicon_icon','qr_code','trust_wallet_qr_code','metamask_wallet_qr_code','ekaum_wallet_qr_code','phantom_wallet_qr_code','one_inch_wallet_qr_code','electrum_wallet_qr_code', 'investment_banner_first', 'investment_banner_second', 'explore_the_exclusive_banner');
				$data['updated_at'] = $currentTime;
				
				$fileFields = [
				'logo',
				'fevicon_icon',
				'qr_code',
				'trust_wallet_qr_code',
				'metamask_wallet_qr_code',
				'ekaum_wallet_qr_code',
				'phantom_wallet_qr_code',
				'one_inch_wallet_qr_code',
				'electrum_wallet_qr_code',
				'explore_the_exclusive_banner'
				];
				
				// Handle file uploads in a loop
				foreach ($fileFields as $field) {
					if ($request->hasFile($field)) {
						$file = $request->file($field);
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/setting', $filename, 'public');
						$data[$field] = $filePath; // Store the path in the database
					}
				}
				
				if ($request->hasFile('investment_banner_first')) {
					$files = $request->file('investment_banner_first'); // Get the uploaded files
					$filePaths = []; // Array to store file paths
					
					foreach ($files as $file) {
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/banner', $filename, 'public');
						$filePaths[] = $filePath; // Add file path to array
					}
					
					// Convert array of file paths to a JSON string before storing
					$data['investment_banner_first'] = json_encode($filePaths); 
				}
				
				// Handle multiple images for 'investment_banner_second'
				if ($request->hasFile('investment_banner_second')) {
					$files = $request->file('investment_banner_second'); // Get the uploaded files
					$filePaths = []; // Array to store file paths
					
					foreach ($files as $file) {
						$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
						$filePath = $file->storeAs('uploads/banner', $filename, 'public');
						$filePaths[] = $filePath; // Add file path to array
					}
					
					// Convert array of file paths to a JSON string before storing
					$data['investment_banner_second'] = json_encode($filePaths); 
				}
				
				if ($request->filled('password')) {
					$data['password'] = Hash::make($request->input('password'));
				} 
				
				// Update or create settings
				foreach ($data as $key => $value) {
					Setting::updateOrCreate(
					['name' => $key], // Condition to check if the record exists
					[
					'value' => $value,
					'updated_at' => $currentTime
					]
					);
				}
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => 'The information has been successfully updated.'], 200);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			}
		}
		
		public function deleteFirstBanner(Request $request)
		{
			// Decode the image path from the request
			$imagePath = urldecode($request->input('image'));
		
			// Check if the image exists in the storage
			if (Storage::disk('public')->exists($imagePath)) {
				// Delete the image from storage
				Storage::disk('public')->delete($imagePath);
				
				// Retrieve the current setting value from the database
				$setting = Setting::where('name', 'investment_banner_first')->first();
				
				if ($setting) 
				{
					$investment_banner_first = json_decode($setting->value, true);
					
					// Remove the deleted image path from the setting
					$updatedImages = array_filter($investment_banner_first, function ($path) use ($imagePath) {
						return $path !== $imagePath;
					});
					
					// Save the updated setting back to the database
					$setting->update(['value' => json_encode(array_values($updatedImages))]);
					
					return response()->json(['status' => 'success', 'msg' => 'Banner image deleted successfully.']);
				}
				
				return response()->json(['status' => 'error', 'msg' => 'Setting not found.']);
			}
			
			return response()->json(['status' => 'error', 'msg' => 'Image not found.']);
		}
		
		public function deleteSecondBanner(Request $request)
		{
			// Decode the image path from the request
			$imagePath = urldecode($request->input('image'));
		
			// Check if the image exists in the storage
			if (Storage::disk('public')->exists($imagePath)) {
				// Delete the image from storage
				Storage::disk('public')->delete($imagePath);
				
				// Retrieve the current setting value from the database
				$setting = Setting::where('name', 'investment_banner_second')->first();
				
				if ($setting) 
				{
					$investment_banner_second = json_decode($setting->value, true);
					
					// Remove the deleted image path from the setting
					$updatedImages = array_filter($investment_banner_second, function ($path) use ($imagePath) {
						return $path !== $imagePath;
					});
					
					// Save the updated setting back to the database
					$setting->update(['value' => json_encode(array_values($updatedImages))]);
					
					return response()->json(['status' => 'success', 'msg' => 'Banner image deleted successfully.']);
				}
				
				return response()->json(['status' => 'error', 'msg' => 'Setting not found.']);
			}
			
			return response()->json(['status' => 'error', 'msg' => 'Image not found.']);
		}
	}							