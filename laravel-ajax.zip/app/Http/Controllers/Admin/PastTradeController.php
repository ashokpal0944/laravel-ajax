<?php
	
	namespace App\Http\Controllers\Admin;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use App\Models\PastTrade;
	use Helper, DB, Validator;
	
	class PastTradeController extends Controller
	{
		public function __construct()
		{
			$this->middleware('admin');
		}
		
		public function index()
		{
			return view('admin.past-trade.index');
		}
		
		public function add()
		{
			$view = view('admin.past-trade.add')->render();
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function getPastTradeDataAjax(Request $request)
		{	 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = auth()->guard('admin')->user();
			
			$query = PastTrade::where('admin_id', $user->id);

			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('title', 'LIKE', "%{$search}%")
					  ->orWhere('sub_title', 'LIKE', "%{$search}%")
					  ->orWhere('trade_percentage', 'LIKE', "%{$search}%")
					  ->orWhere('created_at', 'LIKE', "%{$search}%");
				});
			}

			$totalData = $query->count();

			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();

			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					$image = '<img src="'. url('public/storage/'.$value->icon) .'" class="img-fluid " width="100px"/>';
					
					$mainData['id'] = $i;  
					$mainData['icon'] = $image;
					$mainData['title'] = $value->title;
					$mainData['sub_title'] = $value->sub_title;
					$mainData['trade_percentage'] = $value->trade_percentage;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$mainData['action'] = '<a href="'.url('admin/past-trade/edit',$value->id).'" onclick="editPastTrade(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-pencil-alt" aria-hidden="true"></i></button></a> | <a href="'.url('admin/past-trade/delete',$value->id).'" onclick="deletePastTrade(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-trash-alt" aria-hidden="true"></i></button></a>';  
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		} 
		
		public function insert(Request $request)
		{
			$validation = Validator::make($request->all(), [
				'icon' => 'required|file|mimes:jpeg,png,jpg|max:2048',
				'title' => "required|string|unique:past_trades,title,NULL,id",
				'sub_title' => 'nullable|string', // Sub-title is nullable based on your migration
				'trade_percentage' => 'required|numeric', // 'intiger' should be 'numeric' for decimal values
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			  
			try
			{  	
				DB::beginTransaction();
				
				$user = auth()->guard('admin')->user();
				$currentTime = now();
				$data = $request->except('_token');
				$data['admin_id'] = $user->id;
				$data['created_at'] = $currentTime;
				$data['updated_at'] = $currentTime;
				
				// Handle file upload
				if ($request->hasFile('icon')) {
					$file = $request->file('icon');
					$filename = time() . '-' . $file->getClientOriginalName();
					$filePath = $file->storeAs('uploads/icons', $filename, 'public');
					$data['icon'] = $filePath; // Store the path in the database
				}
			
				$object = new PastTrade();
				Helper::saveData($object,$data);
				$id = $object->id; 
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Past Trade has been successfully added.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function edit($id)
		{
			$get_past_trade = PastTrade::whereId($id)->first();  
			$view = view('admin.past-trade.edit',compact('get_past_trade'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function update(Request $request, $id)
		{
			$validation = Validator::make($request->all(), [
				'icon' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
				'title' => "required|string|unique:past_trades,title,$id,id",
				'sub_title' => 'nullable|string', // Sub-title is nullable based on your migration
				'trade_percentage' => 'required|numeric', // 'intiger' should be 'numeric' for decimal values
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			  
			try
			{  	
				DB::beginTransaction();
				
				$currentTime = now();
				$data = $request->except('_token');
				$data['updated_at'] = $currentTime;
				
				if ($request->hasFile('icon')) 
				{
					$file = $request->file('icon');
					$filename = time() . '-' . $file->getClientOriginalName();
					$filePath = $file->storeAs('uploads/icons', $filename, 'public');
					$data['icon'] = $filePath; // Store the path in the database
				}
				
				$object = PastTrade::find($id);
				Helper::saveData($object,$data);	
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Past Trade has been successfully Updated.']);
				
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function delete(Request $request, $id)
		{
			try
			{
				DB::beginTransaction(); 
				PastTrade::find($id)->delete();
				
				DB::commit();
				return response()->json(['status'=>'success','msg'=>'The Past Trade has been successfully deleted.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			}
		}
	}				