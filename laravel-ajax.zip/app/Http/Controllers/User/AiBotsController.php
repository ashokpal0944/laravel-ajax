<?php
	namespace App\Http\Controllers\User;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use App\Models\AiBots;
	use App\Models\AiStrategy;
	use App\Models\AiBotPurchase;
	use App\Models\UserWallet;
	use Helper, DB, Validator;
	
	class AiBotsController extends Controller
	{
		public function __construct()
		{
			$this->middleware('auth');
		}
		
		public function aiBotsList()
		{
			$get_aibots = AiBots::where('is_status', 1)->groupBy('currency_type')->get(['currency_type']);

			return view('user.ai-bot.index',compact('get_aibots'));
		}
		
		public function viewAiBoat(Request $request, $currency_type)
		{
			$get_aibots = AiBots::with('aiStrategies')->where('is_status', 1)->where('currency_type',$currency_type)->get();
			
			$risk_type = $request->risk_type;
			
			return view('user.ai-bot.view',compact('get_aibots','risk_type','currency_type'));
		}
		
		public function viewStrategy($id)
		{
			$get_ai_strategy = AiBots::with('aiStrategies')->where('is_status', 1)->where('id',$id)->first();
		
			return view('user.ai-bot.view-strategy',compact('get_ai_strategy'));
		}
		
		public function purchaseAiBot(Request $request)
		{
			$validation = Validator::make($request->all(), [
				'ai_bot_id' => 'required',
				'amount' => 'required|numeric', 
				'account_holder_name' => 'required|string',
				'email' => 'required|email',
				'server_name' => 'required',
				'account_number' => 'required',
				'main_password' => 'required',
				'investor_password' => 'required',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try
			{  	
				DB::beginTransaction();
				
				$user = Auth::user();
				
				$purchase_amount = $request->input('amount');
				
				if ($user->wallet_balance < $purchase_amount) 
				{
					return response()->json(['status' => 'error', 'msg' => "Your wallet balance is insufficient for the ai boat purchase price amount of '$purchase_amount'."]);
				}
				
				$currentTime = now();
				$data = $request->except('_token');
				$data['user_id'] = $user->id;
				$data['created_at'] = $currentTime;
				$data['updated_at'] = $currentTime;
				
				$object = new AiBotPurchase();
				Helper::saveData($object,$data);
				$id = $object->id; 
				
				$get_ai_bot = AiBots::where('id',$request->input('ai_bot_id'))->first();
				
				$transaction_method = $get_ai_bot->currency_type .','. $get_ai_bot->risk_type;
				
				$uw_data = [
					'user_id' => $user->id,
					'transaction_method' => $transaction_method,
					'transaction_wallet_address' => $get_ai_bot->id,
					'amount' => $purchase_amount,
					'transaction_type' => 'Purchase Ai Bot',
					'is_status' => 1,
					'created_at' => $currentTime,
					'updated_at' => $currentTime,
				];
				
				$user_wallet = new UserWallet();
				Helper::saveData($user_wallet, $uw_data);
				
				$user->wallet_balance -= $purchase_amount;
				$user->save();
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Ai Bot Purchase has been successfully.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function aiBotPurchaseHistory()
		{
			return view('user.ai-bot.purchase.ai_purchase_history');
		}
		
		public function getAiBoatPurchaseHistoryDataAjax(Request $request)
		{ 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length");
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = Auth::user();
			$query = AiBotPurchase::with('aibot:id,currency_type,risk_type')->where('user_id', $user->id);
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('amount', 'LIKE', "%{$search}%")->orWhere('account_holder_name', 'LIKE', "%{$search}%")->orWhere('email', 'LIKE', "%{$search}%")->orWhere('server_name', 'LIKE', "%{$search}%")->orWhere('account_number', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%")->orWhereHas('aibot', function ($userQuery) use ($search) {
						$userQuery->where('currency_type', 'LIKE', "%{$search}%")->orWhere('risk_type', 'LIKE', "%{$search}%");
					});
				});
			}
			
			$totalData = $query->count();
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Active</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$mainData['id'] = $i;
					$mainData['ai_bot_id'] = $value->aibot->currency_type .','. $value->aibot->risk_type;
					$mainData['amount'] = $value->amount;
					$mainData['account_holder_name'] = $value->account_holder_name;
					$mainData['email'] = $value->email;
					$mainData['server_name'] = $value->server_name;
					$mainData['account_number'] = $value->account_number;
					$mainData['main_password'] = $value->main_password;
					$mainData['investor_password'] = $value->investor_password;
					$mainData['is_status'] = $status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
	}
