<?php
	namespace App\Http\Controllers\User;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use Illuminate\Support\Facades\Validator;
	use App\Models\InvestmentPlan;
	use App\Models\User;
	use App\Models\Setting;
	use App\Models\UserWallet;
	use App\Models\UserKyc;
	use App\Models\UserInvestment;
	use App\Models\UserInvestmentBifurcation;
	use App\Models\UserInvestmentBifurcationChild;
	use DB, Helper, Storage;
	
	class WalletController extends Controller
	{
		public function __construct()
		{
			$this->middleware('auth');
		}
		
		public function index()
		{
			return view('user.wallet.index');
		}
		
		public function walletBalance()
		{
			return view('user.wallet.wallet_balance');
		}
		
		public function topPlan()
		{
			return view('user.wallet.top_plan');
		}
		
		public function investmentPrice()
		{
			$user = Auth::user();
			
			$get_investment_plans = InvestmentPlan::where('is_status',1)->get();
			
			$total_investment = UserInvestment::where('user_id',$user->id)->where('is_status',1)->where('is_payable',0)->count();
		
			return view('user.wallet.investment.index',compact('get_investment_plans','total_investment'));
		}
		
		public function payInvestmentAmount(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'investment_plan_id' => 'required|exists:investment_plans,id', // Ensures the investment_plan_id exists in the investment_plans table
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => "Please select at least one investment plan."]);
			}
			
			try 
			{
				DB::beginTransaction();
				
				$user = Auth::user();
				$investment_plan_id = $request->input('investment_plan_id');
				
				$get_investment_plans = InvestmentPlan::where('id', $investment_plan_id)->where('is_status', 1)->first();
				
				if (!$get_investment_plans) {
					return response()->json(['status' => 'error', 'msg' => 'The selected investment plan is not available.']);
				}
				
				if ($user->wallet_balance < $get_investment_plans->investment_amount) 
				{
					return response()->json(['status' => 'error', 'msg' => "Your wallet balance is insufficient for the investment amount of '{$get_investment_plans->investment_amount}'."]);
				}
				
				$currentTime = now();
				
				$return_on_investment = config("setting.return_on_investment");
				$estimated_time = config("setting.estimated_time");
				
				$investment_amount = $get_investment_plans->investment_amount;
				$total_recived_amount = ($investment_amount * $return_on_investment) / 100;
				
				$data = [
				'user_id' => $user->id,
				'investment_plan_id' => $get_investment_plans->id,
				'investment_amount' => $investment_amount,
				'return_on_investment' => $return_on_investment,
				'estimated_time' => $estimated_time,
				'total_recived_amount' => $total_recived_amount,
				'created_at' => $currentTime,
				'updated_at' => $currentTime,
				];
				
				$userInvestment = new UserInvestment();
				Helper::saveData($userInvestment, $data);
				$user_investment_id = $userInvestment->id;
				
				$dataBifurcation = $this->calculateBifurcation($user_investment_id, $investment_amount, $currentTime);
				
				$userInvestmentBifer = new  UserInvestmentBifurcation();
				Helper::saveData($userInvestmentBifer, $dataBifurcation);
				$user_investment_bifurcation_id = $userInvestmentBifer->id;
				
				$dataBifurcationChild = $this->calculateBifurcationChild($user_investment_bifurcation_id,$dataBifurcation['real_estate_amount'], $dataBifurcation['stock_investment_amount'], $dataBifurcation['trading_investment_amount'], $currentTime);
				
				$userInvestmentBiferChild = new  UserInvestmentBifurcationChild();
				Helper::saveData($userInvestmentBiferChild, $dataBifurcationChild);
				
				$uw_data = [
				'user_id' => $user->id,
				'transaction_method' => 'Investment Plan',
				'transaction_wallet_address' => $get_investment_plans->id,
				'amount' => $investment_amount,
				'transaction_type' => 'Investment',
				'is_status' => 1,
				'created_at' => $currentTime,
				'updated_at' => $currentTime,
				];
				
				$user_wallet = new UserWallet();
				Helper::saveData($user_wallet, $uw_data);
				
				$user->wallet_balance -= $investment_amount;
				$user->save();
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'Your Investment has been successfully submitted.']);
			} 
			catch (\Throwable $e) 
			{
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => 'An error occurred: ' . $e->getMessage()]);
			}
		}
		
		private function calculateBifurcation($user_investment_id, $investment_amount, $currentTime)
		{
			$investmentConfig = [
			'silver_bonds' => 'silver_bond',
			'real_estate' => 'real_estate',
			'startup_investment' => 'startup_investment',
			'stock_investment' => 'stock_investment',
			'trading_investment' => 'trading_investment',
			'reserve_fund' => 'reserve_fund',
			];
			
			$data = ['user_investment_id' => $user_investment_id, 'created_at' => $currentTime, 'updated_at' => $currentTime];
			
			foreach ($investmentConfig as $configKey => $fieldPrefix) {
				$percentage = config("setting.$configKey", 0);
				$data["{$fieldPrefix}_percentage"] = $percentage;
				$data["{$fieldPrefix}_amount"] = ($investment_amount * $percentage) / 100;
			}
			
			return $data;
		}
		
		private function calculateBifurcationChild($user_investment_bifurcation_id,$real_estate_amount, $stock_investment_amount, $trading_investment_amount, $currentTime)
		{
			$bifurcationChildConfig = [
			'real_estate' => [
            'residential' => config('setting.residential', 0),
            'commercial' => config('setting.commercial', 0),
			],
			'stock' => [
            'equity' => config('setting.stock_equity', 0),
            'assets' => config('setting.stock_assets', 0),
			],
			'trading' => [
            'forex' => config('setting.forex', 0),
            'crypto' => config('setting.crypto', 0),
            'stock' => config('setting.stock', 0),
			],
			];
			
			return [
			'user_investment_bifurcation_id' => $user_investment_bifurcation_id,
			'residential_percentage' => $bifurcationChildConfig['real_estate']['residential'],
			'residential_investment_amount' => ($real_estate_amount * $bifurcationChildConfig['real_estate']['residential']) / 100,
			'commercial_percentage' => $bifurcationChildConfig['real_estate']['commercial'],
			'commercial_investment_amount' => ($real_estate_amount * $bifurcationChildConfig['real_estate']['commercial']) / 100,
			'equity_percentage' => $bifurcationChildConfig['stock']['equity'],
			'equity_investment_amount' => ($stock_investment_amount * $bifurcationChildConfig['stock']['equity']) / 100,
			'assets_percentage' => $bifurcationChildConfig['stock']['assets'],
			'assets_investment_amount' => ($stock_investment_amount * $bifurcationChildConfig['stock']['assets']) / 100,
			'forex_percentage' => $bifurcationChildConfig['trading']['forex'],
			'forex_investment_amount' => ($trading_investment_amount * $bifurcationChildConfig['trading']['forex']) / 100,
			'crypto_percentage' => $bifurcationChildConfig['trading']['crypto'],
			'crypto_investment_amount' => ($trading_investment_amount * $bifurcationChildConfig['trading']['crypto']) / 100,
			'stock_percentage' => $bifurcationChildConfig['trading']['stock'],
			'stock_investment_amount' => ($trading_investment_amount * $bifurcationChildConfig['trading']['stock']) / 100,
			'created_at' => $currentTime,
			'updated_at' => $currentTime,
			];
		}
		
		public function investmentHistory()
		{
			return view('user.wallet.investment.investment_history');
		}
		
		public function getInvestmentHistoryDataAjax(Request $request)
		{ 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length");
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = Auth::user();
			$query = UserInvestment::with('investmentPlan:id,plan_name,investment_amount')->where('user_id', $user->id);
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('investment_amount', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%")->orWhereHas('investmentPlan', function ($userQuery) use ($search) {
						$userQuery->where('plan_name', 'LIKE', "%{$search}%");
					});
				});
			}
			
			$totalData = $query->count();
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Approved</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$mainData['id'] = $i;
					$mainData['investment_plan'] = $value->investmentPlan->plan_name;
					$mainData['investment_amount'] = $value->investment_amount;
					$mainData['is_status'] = $status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		//Deposit
		public function depositHistory()
		{
			return view('user.wallet.deposit.deposit_history');
		}
		
		public function getDepositHistoryDataAjax(Request $request)
		{ 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = Auth::user();
			$query = UserWallet::where('user_id', $user->id)->where('transaction_type','Deposit');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('transaction_method', 'LIKE', "%{$search}%")->orWhere('amount', 'LIKE', "%{$search}%")->orWhere('transaction_id', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%");
				});
			}
			
			$totalData = $query->count();
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Approved</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$mainData['id'] = $i;
					$mainData['transaction_method'] = $value->transaction_method;
					$mainData['amount'] = $value->amount;
					$mainData['transaction_id'] = $value->transaction_id;
					$mainData['is_status'] = $status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					$mainData['action'] = '<a href="'.url('view-deposit',$value->id).'" onclick="viewDeposit(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-pencil-alt" aria-hidden="true"></i> View </button></a>';  
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		public function viewDeposit($id)
		{
			$get_user_wallet = UserWallet::whereId($id)->first();  
			$view = view('user.wallet.deposit.view_deposit',compact('get_user_wallet'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function depositMethod()
		{
			$admin_wallet_address = array();
			if(config('setting.trust_wallet') != '' && config('setting.trust_wallet_qr_code') != '')
			{
				$admin_wallet_address['Trust Wallet'] = ["wallet_address" => config('setting.trust_wallet'), "qr_code" => url('storage/' . config('setting.trust_wallet_qr_code'))];
			}
			
			if(config('setting.metamask_wallet') != '' && config('setting.metamask_wallet_qr_code') != '')
			{
				$admin_wallet_address['Metamask Wallet'] = ["wallet_address" => config('setting.metamask_wallet'), "qr_code" => url('storage/' . config('setting.metamask_wallet_qr_code'))];
			}
			
			if(config('setting.ekaum_wallet') != '' && config('setting.ekaum_wallet_qr_code') != '')
			{
				$admin_wallet_address['Ekaum Wallet'] = ["wallet_address" => config('setting.ekaum_wallet'), "qr_code" => url('storage/' . config('setting.ekaum_wallet_qr_code'))];
			}
			
			if(config('setting.phantom_wallet') != '' && config('setting.phantom_wallet_qr_code') != '')
			{
				$admin_wallet_address['Phantom Wallet'] = ["wallet_address" => config('setting.phantom_wallet'), "qr_code" => url('storage/' . config('setting.phantom_wallet_qr_code'))];
			}
			
			if(config('setting.one_inch_wallet') != '' && config('setting.one_inch_wallet_qr_code') != '')
			{
				$admin_wallet_address['1 Inch Wallet'] = ["wallet_address" => config('setting.one_inch_wallet'), "qr_code" => url('storage/' . config('setting.one_inch_wallet_qr_code'))];
			}
			
			if(config('setting.electrum_wallet') != '' && config('setting.electrum_wallet_qr_code') != '')
			{
				$admin_wallet_address['Electrum Wallet'] = ["wallet_address" => config('setting.electrum_wallet'), "qr_code" => url('storage/' . config('setting.electrum_wallet_qr_code'))];
			}
			
			return view('user.wallet.deposit.deposit',compact('admin_wallet_address'));
		}
		
		public function sendDepositMethod(Request $request)
		{
			$wallet_address = $request->input('wallet_address');
			
			if(empty($wallet_address))
			{
				toastr()->error('Please select at least one deposit method.');
				return back();
			}
			
			if(config('setting.trust_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Trust Wallet";
				$wallet_details['address'] = config('setting.trust_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.trust_wallet_qr_code'));
			}
			
			if(config('setting.metamask_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Metamask Wallet";
				$wallet_details['address'] = config('setting.metamask_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.metamask_wallet_qr_code'));
			}
			
			if(config('setting.ekaum_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Ekaum Wallet";
				$wallet_details['address'] = config('setting.ekaum_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.ekaum_wallet_qr_code'));
			}
			
			if(config('setting.phantom_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Phantom Wallet";
				$wallet_details['address'] = config('setting.phantom_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.phantom_wallet_qr_code'));
			}
			
			if(config('setting.one_inch_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "1 Inch Wallet";
				$wallet_details['address'] = config('setting.one_inch_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.one_inch_wallet_qr_code'));
			}
			
			if(config('setting.electrum_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Electrum Wallet";
				$wallet_details['address'] = config('setting.electrum_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.electrum_wallet_qr_code'));
			}
			
			if(config('setting.account_number') == $wallet_address)
			{
				$wallet_details['title'] = "Bank Account";
				$wallet_details['bank_holder_name'] = config('setting.bank_holder_name');
				$wallet_details['bank_name'] = config('setting.bank_name');
				$wallet_details['account_number'] = config('setting.account_number');
				$wallet_details['ifsc_code'] = config('setting.ifsc_code');
			}
			
			if(config('setting.upi_address') == $wallet_address)
			{
				$wallet_details['title'] = "UPI Address";
				$wallet_details['address'] = config('setting.upi_address');
				$wallet_details['qr_code'] = url('storage/' . config('setting.qr_code'));
			}
			
			return view('user.wallet.deposit.deposit-request',compact('wallet_details','wallet_address'));
		}
		
		public function sendDepositRequest(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'transaction_method' => 'required|string',
			'transaction_wallet_address' => 'required|string',
			'amount' => 'required|string',
			'transaction_id' => 'required|string',
			'transaction_image' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			try 
			{
				DB::beginTransaction();
				
				$currentTime = now();
				$data = $request->except('_token','transaction_image');
				$data['updated_at'] = $currentTime;
				$user = Auth::user();
				$data['user_id'] = $user->id;
				$data['transaction_type'] = "Deposit";
				
				if ($request->hasFile('transaction_image')) 
				{
					$file = $request->file('transaction_image');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/transaction', $filename, 'public');
					$data['transaction_image'] = $filePath; // Store the path in the database
				}
				
				$object = new UserWallet();
				Helper::saveData($object, $data);
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => "Your deposit request has been successfully submitted."]);
			} 
			catch (\Throwable $e) 
			{
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => $e->getMessage()]);
			}
		}
		
		//Withdrawal
		public function withdrawalHistory()
		{
			return view('user.wallet.withdrawal.withdrawal_history');
		}
		
		public function getWithdrawalHistoryDataAjax(Request $request)
		{ 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = Auth::user();
			$query = UserWallet::where('user_id', $user->id)->where('transaction_type','Withdrawal');
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('transaction_method', 'LIKE', "%{$search}%")->orWhere('amount', 'LIKE', "%{$search}%")->orWhere('transaction_wallet_address', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%");
				});
			}
			
			$totalData = $query->count();
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) {
						$status = '<span class="badge badge-success badge-pill">Approved</span>';
						} elseif ($value->is_status == 2) {
						$status = '<span class="badge badge-danger badge-pill">Rejected</span>';
						} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					$mainData['id'] = $i;
					$mainData['transaction_method'] = $value->transaction_method;
					$mainData['amount'] = $value->amount;
					$mainData['transaction_wallet_address'] = $value->transaction_wallet_address;
					$mainData['is_status'] = $status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at)); 
					$mainData['action'] = '';  
					
					if($value->is_status == 0)
					{
						$mainData['action'] .= '<a href="'.url('edit-withdrawal',$value->id).'" onclick="editWithdrawal(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-pencil-alt" aria-hidden="true"></i> Edit </button></a> | <a href="'.url('delete-withdrawal',$value->id).'" onclick="deleteWithdrawal(this,event)"><button type="button" class="btn btn-light waves-effect"><i class="fas fa-trash-alt" aria-hidden="true"></i>Delete</button></a>';
					}
					
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		public function withdrawal()
		{
			$user = Auth::user();
			
			$check_user_kyc = UserKyc::where('user_id',$user->id)->first();
			
			if(!$check_user_kyc) {
				toastr()->error('Please submit your KYC details.');
				return redirect('kyc');
			}
			
			if ($check_user_kyc->is_aadhaar == 2 || $check_user_kyc->is_pancard == 2 || $check_user_kyc->is_bank_account == 2) {
				toastr()->error('Please check your KYC details. Your KYC details have been rejected.');
				return redirect('kyc');
			}
			
			if ($check_user_kyc->is_aadhaar == 0 && $check_user_kyc->is_pancard == 0 && $check_user_kyc->is_bank_account == 0) {
				toastr()->error('Your KYC is pending. Please contact the admin.');
				return back();
			}
			
			$user_wallet_address = [];
			
			$wallets = [
			'Trust Wallet' => 'trust_wallet',
			'Metamask Wallet' => 'metamask_wallet',
			'Ekaum Wallet' => 'ekaum_wallet',
			'Phantom Wallet' => 'phantom_wallet',
			'1 Inch Wallet' => 'one_inch_wallet',
			'Electrum Wallet' => 'electrum_wallet',
			];
			
			foreach ($wallets as $walletName => $walletField) {
				/* if (!empty($check_user_kyc->$walletField)) { */
				$user_wallet_address[$walletName] = ["wallet_address" => $check_user_kyc->$walletField,"wallet_kye" => $walletField];
				/* } */
			}
			
			return view('user.wallet.withdrawal.withdrawal',compact('check_user_kyc','user_wallet_address'));
		}
		
		public function sendWithdrawalRequest(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'amount' => 'required|numeric|min:0',
			]);
			
			if ($validation->fails()) {
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			try 
			{
				DB::beginTransaction();
				
				$user = Auth::user();
				$amount = $request->input('amount');
				$wallet_type = $request->input('wallet_type');
				$wallet_address = $request->input('wallet_address');
				
				if(empty($wallet_type))
				{
					return response()->json(['status' => 'error', 'msg' => "Something is wrong. Please refresh your browser."]);
				}
				
				if (empty($wallet_address)) 
				{
					return response()->json(['status' => 'error', 'msg' => "Please select at least one Withdrawal method."]);
				}
				
				if ($user->wallet_balance < $amount) 
				{
					return response()->json(['status' => 'error', 'msg' => "Your wallet balance is insufficient for the withdrawal amount of '$amount'."]);
				}
				
				$check_user_kyc = UserKyc::firstOrNew(['user_id' => $user->id]);
				
				$walletMapping = [
				"Trust Wallet" => 'trust_wallet',
				"Metamask Wallet" => 'metamask_wallet',
				"Ekaum Wallet" => 'ekaum_wallet',
				"Phantom Wallet" => 'phantom_wallet',
				"1 Inch Wallet" => 'one_inch_wallet',
				"Electrum Wallet" => 'electrum_wallet',
				"UPI Address" => 'upi_address'
				];
				
				if (array_key_exists($wallet_type, $walletMapping)) {
					$walletField = $walletMapping[$wallet_type];
					if (empty($check_user_kyc->$walletField)) {
						$check_user_kyc->$walletField = $wallet_address;
						$check_user_kyc->save();
					}
				}
				
				// Create a new transaction entry
				$data = [
				'user_id' => $user->id,
				'transaction_method' => $wallet_type,
				'transaction_wallet_address' => $wallet_address,
				'amount' => $amount,
				'transaction_type' => "Withdrawal",
				'created_at' => now(),
				'updated_at' => now()
				];
				
				$object = new UserWallet();
				Helper::saveData($object, $data);
				
				// Update user wallet balance
				$user->wallet_balance -= $amount;
				$user->save();
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => "Your withdrawal request has been successfully submitted."]);
				} catch (\Throwable $e) {
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => $e->getMessage()]);
			}
		}
		
		public function editWithdrawal($id)
		{
			$get_user_wallet = UserWallet::whereId($id)->first();  
			$view = view('user.wallet.withdrawal.edit_withdrawal',compact('get_user_wallet'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
		
		public function updateWithdrawal(Request $request, $id)
		{
			$validation = Validator::make($request->all(), [
			'amount' => 'required|numeric|min:0.01',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			try {
				DB::beginTransaction();
				
				$user = Auth::user();
				$amount = $request->input('amount');
				
				$walletEntry = UserWallet::find($id);
				
				if (!$walletEntry) {
					return response()->json(['status' => 'error', 'msg' => 'Wallet entry not found.']);
				}
				
				// Refund the previous amount to the user's balance
				$user->wallet_balance += $walletEntry->amount;
				
				// Check if the updated balance is sufficient for the new withdrawal
				if ($user->wallet_balance < $amount) {
					return response()->json(['status' => 'error', 'msg' => "Insufficient wallet balance for the withdrawal amount of '$amount'."]);
				}
				
				// Deduct the new amount from the wallet
				$user->wallet_balance -= $amount;
				$user->save();
				
				// Prepare data for the update
				$data = $request->except('_token');
				$data['updated_at'] = now();
				$data['amount'] = $amount;
				
				// Update wallet entry
				Helper::saveData($walletEntry, $data);
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => "Your withdrawal request has been successfully submitted."]);
				} catch (\Throwable $e) {
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => $e->getMessage()]);
			}
		}
		
		public function deleteWithdrawal(Request $request, $id)
		{
			try {
				DB::beginTransaction();
				
				$user_wallet = UserWallet::findOrFail($id);
				$amount = $user_wallet->amount;
				
				// Retrieve the authenticated user
				$user = Auth::user();
				
				// Update user's wallet balance by adding the amount back
				$user->wallet_balance += $amount;
				$user->save();
				
				// Delete the wallet entry
				$user_wallet->delete();
				
				DB::commit();
				
				return response()->json(['status' => 'success', 'msg' => 'Withdrawal request has been successfully deleted.']);
				} catch (\Throwable $e) {
				DB::rollBack();
				
				return response()->json(['status' => 'error', 'msg' => 'An error occurred while deleting the withdrawal request. Please try again.']);
			}
		}
		
		public function premiumSubscription()
		{
			$admin_wallet_address = array();
			if(config('setting.trust_wallet') != '' && config('setting.trust_wallet_qr_code') != '')
			{
				$admin_wallet_address['Trust Wallet'] = ["wallet_address" => config('setting.trust_wallet'), "qr_code" => url('storage/' . config('setting.trust_wallet_qr_code'))];
			}
			
			if(config('setting.metamask_wallet') != '' && config('setting.metamask_wallet_qr_code') != '')
			{
				$admin_wallet_address['Metamask Wallet'] = ["wallet_address" => config('setting.metamask_wallet'), "qr_code" => url('storage/' . config('setting.metamask_wallet_qr_code'))];
			}
			
			if(config('setting.ekaum_wallet') != '' && config('setting.ekaum_wallet_qr_code') != '')
			{
				$admin_wallet_address['Ekaum Wallet'] = ["wallet_address" => config('setting.ekaum_wallet'), "qr_code" => url('storage/' . config('setting.ekaum_wallet_qr_code'))];
			}
			
			if(config('setting.phantom_wallet') != '' && config('setting.phantom_wallet_qr_code') != '')
			{
				$admin_wallet_address['Phantom Wallet'] = ["wallet_address" => config('setting.phantom_wallet'), "qr_code" => url('storage/' . config('setting.phantom_wallet_qr_code'))];
			}
			
			if(config('setting.one_inch_wallet') != '' && config('setting.one_inch_wallet_qr_code') != '')
			{
				$admin_wallet_address['1 Inch Wallet'] = ["wallet_address" => config('setting.one_inch_wallet'), "qr_code" => url('storage/' . config('setting.one_inch_wallet_qr_code'))];
			}
			
			if(config('setting.electrum_wallet') != '' && config('setting.electrum_wallet_qr_code') != '')
			{
				$admin_wallet_address['Electrum Wallet'] = ["wallet_address" => config('setting.electrum_wallet'), "qr_code" => url('storage/' . config('setting.electrum_wallet_qr_code'))];
			}
			
			return view('user.wallet.premium.premium_subscription',compact('admin_wallet_address'));
		}
		
		public function premiumSubscriptionAmountDetails(Request $request)
		{
			$wallet_address = $request->input('wallet_address');
			
			if(empty($wallet_address))
			{
				toastr()->error('Please select at least one deposit method.');
				return back();
			}
			
			if(config('setting.trust_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Trust Wallet";
				$wallet_details['address'] = config('setting.trust_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.trust_wallet_qr_code'));
			}
			
			if(config('setting.metamask_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Metamask Wallet";
				$wallet_details['address'] = config('setting.metamask_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.metamask_wallet_qr_code'));
			}
			
			if(config('setting.ekaum_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Ekaum Wallet";
				$wallet_details['address'] = config('setting.ekaum_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.ekaum_wallet_qr_code'));
			}
			
			if(config('setting.phantom_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Phantom Wallet";
				$wallet_details['address'] = config('setting.phantom_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.phantom_wallet_qr_code'));
			}
			
			if(config('setting.one_inch_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "1 Inch Wallet";
				$wallet_details['address'] = config('setting.one_inch_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.one_inch_wallet_qr_code'));
			}
			
			if(config('setting.electrum_wallet') == $wallet_address)
			{
				$wallet_details['title'] = "Electrum Wallet";
				$wallet_details['address'] = config('setting.electrum_wallet');
				$wallet_details['qr_code'] = url('storage/' . config('setting.electrum_wallet_qr_code'));
			}
			
			if(config('setting.account_number') == $wallet_address)
			{
				$wallet_details['title'] = "Bank Account";
				$wallet_details['bank_holder_name'] = config('setting.bank_holder_name');
				$wallet_details['bank_name'] = config('setting.bank_name');
				$wallet_details['account_number'] = config('setting.account_number');
				$wallet_details['ifsc_code'] = config('setting.ifsc_code');
			}
			
			if(config('setting.upi_address') == $wallet_address)
			{
				$wallet_details['title'] = "UPI Address";
				$wallet_details['address'] = config('setting.upi_address');
				$wallet_details['qr_code'] = url('storage/' . config('setting.qr_code'));
			}
			
			return view('user.wallet.premium.premium-request',compact('wallet_details','wallet_address'));
		}
		
		public function sendPremiumSubScription(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'transaction_method' => 'required|string',
			'transaction_wallet_address' => 'required|string',
			'amount' => 'required|string',
			'transaction_id' => 'required|string',
			'transaction_image' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			try 
			{
				DB::beginTransaction();
				
				$currentTime = now();
				$data = $request->except('_token','transaction_image');
				$data['updated_at'] = $currentTime;
				$user = Auth::user();
				$data['user_id'] = $user->id;
				$data['transaction_type'] = "Premium Subscription";
				
				if ($request->hasFile('transaction_image')) 
				{
					$file = $request->file('transaction_image');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/transaction', $filename, 'public');
					$data['transaction_image'] = $filePath; // Store the path in the database
				}
				
				$object = new UserWallet();
				Helper::saveData($object, $data);
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => "Your Premium Sub Scription request has been successfully submitted."]);
			} 
			catch (\Throwable $e) 
			{
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => $e->getMessage()]);
			}
		}
	}
