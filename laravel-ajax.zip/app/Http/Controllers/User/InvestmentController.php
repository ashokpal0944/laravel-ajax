<?php
	namespace App\Http\Controllers\User;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use App\Models\AiBots;
	use App\Models\UserInvestment;
	use App\Models\UserReturnOnInterest;
	
	class InvestmentController extends Controller
	{
		public function __construct()
		{
			$this->middleware('auth');
		}
		
		public function index()
		{
			$user = Auth::user();
			$total_user_investment = UserInvestment::where('user_id',$user->id)->where('is_status',1)->where('is_payable',0)->count();
			
			$get_user_investments = UserInvestment::with([
				'investmentPlan:id,plan_name,investment_amount',
				'user:id,name',
				'returnInterest' => function ($query) {
					$query->orderBy('created_at', 'desc')->limit(1);
				}
			])
			->withSum('returnInterest', 'total_return_of_interest')
			->where('user_id', $user->id)
			->where('is_status', 1)
			->get();
					
			$get_aibots = AiBots::where('is_status', 1)->get()->groupBy('currency_type');

			$get_ai_bots_array = [];
			foreach ($get_aibots as $currency_type => $bots) {
				$data['currency_type'] = $currency_type;
				$data['all_currency_data'] = $bots;
				$get_ai_bots_array[] = $data;
			}
			
			return view('user.investment.index',compact('get_ai_bots_array','total_user_investment','get_user_investments'));
		}
		
		public function getReturnOfInterest($id)
		{
			$get_user_return_of_interests = UserReturnOnInterest::where('user_investment_id',$id)->orderBy('id','DESC')->get();  
			
			$get_user_interests = UserInvestment::where('id',$id)->first();
			
			
			$view = view('user.investment.return-of-interest',compact('get_user_return_of_interests','get_user_interests'))->render();
			
			return response()->json(['status'=>'success','view'=>$view]);
		}
	}
