<?php
	namespace App\Http\Controllers\User;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use Illuminate\Support\Facades\Hash;
	use Illuminate\Support\Facades\Mail;
	use Illuminate\Support\Facades\Validator;
	use App\Models\User;
	use App\Models\UserKyc;
	use App\Models\Country;
	use App\Models\State;
	use App\Models\City;
	use DB, Helper, Storage;
	
	class ProfileController extends Controller
	{
		public function __construct()
		{
			$this->middleware('auth');
		}
		
		public function index()
		{
			$user = Auth::user();
			
			return view('user.profile.index',compact('user'));
		}
		
		public function profileData()
		{
			$user = Auth::user();
			
			$get_country = Country::all();
			$get_states = State::where('country_id',$user->country_id)->get();
			$get_citys = City::where('state_id',$user->state_id)->get();
			
			return view('user.profile.profile-data',compact('get_country','get_states','get_citys'));
		}
		
		public function updateProfile(Request $request)
		{
			$user = Auth::user();
			
			$validation = Validator::make($request->all(), [
			'name' => "required|string",
			'phone_number' => "required|string|unique:users,phone_number,$user->id,id",
			'country_id' => 'required|numeric', 
			'state_id' => 'required|numeric', 
			'city_id' => 'required|numeric', 
			'occupation' => 'required|string', 
			'profile' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try
			{
				DB::beginTransaction();
				
				$currentTime = now();
				
				$data = $request->except('_token');
				$data['updated_at'] = $currentTime;
				
				$object = User::find($user->id);
				
				$oldImagePath = $object->image;
				
				if ($request->hasFile('profile')) 
				{
					$file = $request->file('profile');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/profile', $filename, 'public');
					$data['profile'] = $filePath; // Store the path in the database
					
					if ($oldImagePath && Storage::disk('public')->exists($oldImagePath)) {
						Storage::disk('public')->delete($oldImagePath);
					}
				}
				
				Helper::saveData($object,$data);	
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Profile Update successfully Updated.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function changePassword()
		{
			return view('user.profile.change-password');
		}
		
		public function updatePassword(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'old_password' => "required|min:6",
			'password' => 'required|min:6',
			'confirm_password' => 'required_with:password|same:password|min:6'
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			$user = Auth::user();
			
			if (!Hash::check($request->input('old_password'), $user->password)) {
				return response()->json(['status' => 'error', 'msg' => 'The old password is incorrect.']);
			}
			
			try
			{
				DB::beginTransaction();
				
				$data['password'] = Hash::make($request->input('password'));
				
				$object = User::find($user->id);
				Helper::saveData($object,$data);
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'Password updated successfully.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		public function userKYC()
		{
			$user = Auth::user();
			
			$get_user_kyc = UserKyc::where('user_id', $user->id)->first();
			
			return view('user.profile.kyc',compact('get_user_kyc'));
		}
		
		public function updateProfileImage(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'profile' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try 
			{
				DB::beginTransaction();
				
				$currentTime = now();
				
				$user = Auth::user();
				
				$data = $request->except('_token');
				$data['updated_at'] = $currentTime;
				
				$object = User::find($user->id);
				
				$oldImagePath = $object->image;
				
				if ($request->hasFile('profile')) 
				{
					$file = $request->file('profile');
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/profile', $filename, 'public');
					$data['profile'] = $filePath; // Store the path in the database
					
					if ($oldImagePath && Storage::disk('public')->exists($oldImagePath)) {
						Storage::disk('public')->delete($oldImagePath);
					}
				}
				
				Helper::saveData($object,$data);	
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The Profile Update successfully Updated.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			}
		}
		
		public function updateUserKyc(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'aadhaar_front' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			'aadhaar_back' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			'pancard_image' => 'nullable|file|mimes:jpeg,png,jpg|max:2048',
			'account_number' => 'nullable|numeric|digits_between:9,18',
			'confirmation_account_number' => 'nullable|numeric|same:account_number',
			]);
			
			if ($validation->fails()) {
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			/* try {
			DB::beginTransaction(); */
			
			$currentTime = now();
			$data = $request->except('_token', 'aadhaar_front', 'aadhaar_back', 'pancard_image', 'confirmation_account_number');
			$data['updated_at'] = $currentTime;
			
			$user = Auth::user();
			$object = UserKyc::where('user_id', $user->id)->first();
			
			$fields = [
			'aadhaar_front' => 'aadhaar_front',
			'aadhaar_back' => 'aadhaar_back',
			'pancard_image' => 'pancard_image'
			];
			
			if (!$object) {
				$object = new UserKyc(); // Create a new KYC record if none exists
				$data['user_id'] = $user->id; // Set the user ID for a new record
			}
			
			foreach ($fields as $inputName => $dbFieldName) {
				if ($request->hasFile($inputName)) {
					// Delete the old file if it exists
					if (isset($object->$dbFieldName) && $object->$dbFieldName && Storage::disk('public')->exists($object->$dbFieldName)) {
						Storage::disk('public')->delete($object->$dbFieldName);
					}
					
					// Store the new file and update the path
					$file = $request->file($inputName);
					$filename = time() . '-' . uniqid() . '.' . $file->getClientOriginalExtension();
					$filePath = $file->storeAs('uploads/kyc', $filename, 'public');
					$data[$dbFieldName] = $filePath;
				}
			}
			
			Helper::saveData($object, $data); // Save data whether it's new or existing
			
			DB::commit();
			return response()->json(['status' => 'success', 'msg' => 'The User KYC updated successfully.']);
			/* } 
				catch (\Throwable $e) 
				{
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => $e->getMessage()]);
			} */
		}
		
		public function updateBankAccountDetails(Request $request)
		{
			$validation = Validator::make($request->all(), [
			'bank_name' => 'required|string',
			'ifsc_code' => 'required|string',
			'account_type' => 'required|string',
			'account_number' => 'required|numeric|digits_between:9,18',
			'confirmation_account_number' => 'required|numeric|same:account_number',
			]);
			
			if ($validation->fails()) {
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			/* try {
				DB::beginTransaction(); */
				
				$data = $request->except('_token', 'confirmation_account_number');
				$data['updated_at'] = now();
				
				$user = Auth::user();
				
				$kyc = UserKyc::firstOrNew(['user_id' => $user->id]);
				$kyc->fill($data);
				$kyc->save();
				
				//DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'The User KYC updated successfully.']);
				/* } catch (\Throwable $e) {
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => 'Failed to update KYC details.']);
			} */
		}
		
		public function referralCode()
		{
			return view('user.profile.referral-code');
		}
	}
