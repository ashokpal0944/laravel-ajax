<?php
	namespace App\Http\Controllers\User;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use App\Models\User;
	use App\Models\Trading;
	use App\Models\Rehab;
	use App\Models\Business;
	use App\Models\PurchaseCourse;
	use App\Models\UserWallet;
	
	use DB, Helper, Storage;
	
	class EducationController extends Controller
	{
		public function __construct()
		{
			$this->middleware('auth');
		}
		
		public function educationsList()
		{
			return view('user.education.index');
		}
		
		public function educationsTrading()
		{
			$get_tradings  = Trading::where('is_status',1)->get();
			
			return view('user.education.trading-course',compact('get_tradings'));
		}
		
		public function educationRehab()
		{
			$get_rehabs  = Rehab::where('is_status',1)->get();
			
			return view('user.education.rehab-course',compact('get_rehabs'));
		}
		
		public function educationsBusiness()
		{
			$get_business  = Business::where('is_status',1)->get();
			
			return view('user.education.business-course',compact('get_business'));
		}
		
		public function educationsTradingCourseView($id)
		{
			$course_type = "Trading";
			$get_data  = Trading::where('id',$id)->first();
			
			return view('user.education.course-view',compact('course_type', 'get_data'));
		}
		
		public function educationRehabCourseView($id)
		{
			$course_type = "Rehab";
			$get_data  = Rehab::where('id',$id)->first();
			
			return view('user.education.course-view',compact('course_type', 'get_data'));
		}
		
		public function educationsBusinessCourseView($id)
		{
			$course_type = "Business";
			$get_data  = Business::where('id',$id)->first();
			
			return view('user.education.course-view',compact('course_type', 'get_data'));
		}
		
		public function purchaseHistory()
		{
			return view('user.purchase.index');
		}
		
		public function getPurchaseHistoryDataAjax(Request $request)
		{ 
			$draw = $request->get('draw');
			$start = $request->get("start");
			$limit = $request->get("length"); // Rows display per page
			
			$columnIndex_arr = $request->get('order');
			$columnName_arr = $request->get('columns');
			$order_arr = $request->get('order');
			$search_arr = $request->get('search');
			
			$columnIndex = $columnIndex_arr[0]['column']; // Column index
			$order = $columnName_arr[$columnIndex]['data']; // Column name
			$dir = $order_arr[0]['dir']; // asc or desc
			if($order == "action")
			{
				$order = 'id';
			}
			
			$user = Auth::user();
			$query = PurchaseCourse::where('user_id', $user->id);
			
			if ($search = $request->input('search')) 
			{
				$query->where(function ($q) use ($search) 
				{
					$q->where('course_type', 'LIKE', "%{$search}%")->orWhere('course_price', 'LIKE', "%{$search}%")->orWhere('start_date', 'LIKE', "%{$search}%")->orWhere('expire_date', 'LIKE', "%{$search}%")->orWhere('created_at', 'LIKE', "%{$search}%");
				});
			}
			
			$totalData = $query->count();
			$values = $query->offset($start)->limit($limit)->orderBy($order, $dir)->get();
			$totalFiltered = $totalData;
			
			$data = array();
			if(!empty($values))
			{
				$i = $start+1;
				$j = 1;
				foreach ($values as $value)
				{    
					if ($value->is_status == 1) 
					{
						$status = '<span class="badge badge-success badge-pill">Active</span>';
					}
					elseif ($value->is_status == 2) 
					{
						$status = '<span class="badge badge-danger badge-pill">Expire</span>';
					} else {
						$status = '<span class="badge badge-warning badge-pill">Pending</span>';
					}
					
					if($value->course_type == "Trading")
					{
						$course_name = Trading::where('id',$value->course_id)->first()->title;
					}
					else if($value->course_type == "Rehab")
					{
						$course_name = Rehab::where('id',$value->course_id)->first()->courses;
					}
					else
					{
						$course_name = Business::where('id',$value->course_id)->first()->title;
					}
					
					$mainData['id'] = $i;
					$mainData['course_name'] = $course_name;
					$mainData['course_type'] = $value->course_type;
					$mainData['course_price'] = $value->course_price;
					$mainData['start_date'] = $value->start_date;
					$mainData['expire_date'] = $value->expire_date;
					$mainData['is_status'] = $status;
					$mainData['created_at'] = date('Y-m-d h:i A',strtotime($value->created_at));
					$data[] = $mainData;
					($j == 3)?$j = 1:$j++;
					$i++;
				}
			}
			
			$response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalData,
            "iTotalDisplayRecords" => $totalFiltered,
            "aaData" => $data
			); 
			
			echo json_encode($response);
			exit;
		}
		
		public function purchaseEducationCourse(Request $request)
		{
			try 
			{
				DB::beginTransaction();
				
				$user = Auth::user();
				
				$course_id = $request->input('course_id');
				$course_type = $request->input('course_type');
				$course_price = $request->input('course_price');
				$start_date = $request->input('start_date');
				$expire_date = $request->input('expire_date');
				
				if ($user->wallet_balance < $course_price) 
				{
					return response()->json(['status' => 'error', 'msg' => "Your wallet balance is insufficient for the course price amount of '$course_price'."]);
				}
				
				// Prepare data for PurchaseCourse
				$currentTime = now();
				$data = [
					'user_id' => $user->id,
					'course_id' => $course_id,
					'course_type' => $course_type,
					'course_price' => $course_price,
					'start_date' => $start_date,
					'expire_date' => $expire_date,
					'created_at' => $currentTime,
					'updated_at' => $currentTime,
				];
				
				// Save PurchaseCourse data
				$object = new PurchaseCourse();
				Helper::saveData($object, $data);
				
				// Prepare data for UserWallet
				$uw_data = [
					'user_id' => $user->id,
					'transaction_method' => $course_type,
					'transaction_wallet_address' => $course_id,
					'amount' => $course_price,
					'transaction_type' => 'Purchase',
					'is_status' => 1,
					'created_at' => $currentTime,
					'updated_at' => $currentTime,
				];
				
				// Save UserWallet data
				$user_wallet = new UserWallet();
				Helper::saveData($user_wallet, $uw_data);
				
				// Update user wallet balance
				$user->wallet_balance -= $course_price;
				$user->save();
				
				// Commit transaction
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => "The course has been purchased successfully."]);
			} 
			catch (\Throwable $e) 
			{
				// Rollback transaction on error
				DB::rollBack();
				return response()->json(['status' => 'error', 'msg' => 'An error occurred: ' . $e->getMessage()]);
			}
		}
	}
