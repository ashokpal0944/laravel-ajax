<?php
	namespace App\Http\Controllers\User;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\Session;
	use App\Models\TopCategory;
	use App\Models\Video;
	use App\Models\PastTrade;
	use App\Models\LiveTrade;
	use App\Models\StockBuzz;
	use App\Models\News;
	
	class HomeController extends Controller
	{
		public function __construct()
		{
			$this->middleware('auth');
		}
		
		public function index()
		{
			$get_categorys = TopCategory::where('is_status',1)->get();
			$get_videos = Video::where('is_status',1)->get();
			$get_past_trades = PastTrade::orderBy('id', 'DESC')->take(6)->get();
			$get_live_trades = LiveTrade::orderBy('id', 'DESC')->take(6)->get();
			$get_stock_buzzs = StockBuzz::orderBy('id', 'DESC')->take(6)->get();
			$get_newss = News::orderBy('id', 'DESC')->take(6)->get();
			
			return view('home',compact('get_categorys','get_videos','get_past_trades','get_live_trades','get_stock_buzzs','get_newss'));
		}
		
		public function viewPortfolioBuzz()
		{
			return view('user.view-buzz');
		}
		public function viewHealth()
		{
			return view('user.view-health');
		}
		public function viewBasket()
		{
			return view('user.view-basket');
		}
	}
