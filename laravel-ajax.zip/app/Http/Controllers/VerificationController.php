<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Auth\Events\Verified;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

use App\Models\User;

class VerificationController extends Controller
{
    public function verify(Request $request, $id, $hash)
    {
        $user = User::findOrFail($id);
		
        // Check if the URL signature is valid
        if (! URL::hasValidSignature($request)) 
		{
			toastr()->error('Invalid or expired URL.');
            return redirect('/')->withErrors(['message' => 'Invalid or expired URL.']);
        }

        // Verify the user's email if it is not already verified
        if ($user->hasVerifiedEmail())
		{
			toastr()->error('Email already verified.');
            return redirect('/')->with('status', 'Email already verified.');
        }

        // Verify the user's email
        if ($user->markEmailAsVerified()) 
		{
            event(new Verified($user));

            // Optionally log the user in
            Auth::login($user);
            
            toastr()->success('Email verified successfully.');
            return redirect('/home')->with('status', 'Email verified successfully.');
        }

        // Log the user in if you want to automatically log them in
        Auth::login($user);
	
		toastr()->success('Email verified successfully.');
        return redirect('/home');
    }
}
