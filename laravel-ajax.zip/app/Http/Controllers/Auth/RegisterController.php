<?php
	
	namespace App\Http\Controllers\Auth;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Foundation\Auth\RegistersUsers;
	use Illuminate\Support\Facades\Hash;
	use Illuminate\Support\Facades\Mail;
	use Illuminate\Support\Facades\Validator;
	use Illuminate\Validation\Rule;
	use Illuminate\Http\Request;
	use Illuminate\Auth\Events\Registered;
	use App\Models\User;
	use DB, Helper;
	
	class RegisterController extends Controller
	{
		/*
			|--------------------------------------------------------------------------
			| Register Controller
			|--------------------------------------------------------------------------
			|
			| This controller handles the registration of new users as well as their
			| validation and creation. By default this controller uses a trait to
			| provide this functionality without requiring any additional code.
			|
		*/
		
		use RegistersUsers;
		
		/**
			* Where to redirect users after registration.
			*
			* @var string
		*/
		protected $redirectTo = '/home';
		
		/**
			* Create a new controller instance.
			*
			* @return void
		*/
		public function __construct()
		{
			$this->middleware('guest');
		}
		
		public function userRegister(Request $request)
		{
			$validation = Validator::make($request->all(), [
				'name' => 'required|string',
				'phone_number' => 'required|string|unique:users,phone_number',
				'username' => 'required|string|min:6|max:20|regex:/^[a-zA-Z0-9_]+$/|unique:users,username',
				'email' => 'required|string|email|unique:users,email',
				'password' => 'required|min:6|max:20',
				'country_id' => 'required|numeric',
				'state_id' => 'required|numeric',
				'city_id' => 'required|numeric',
				'occupation' => 'required|string',
				'is_agree' => 'required|string',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			} 
			
			try
			{
				DB::beginTransaction();
				
				$currentTime = now();
				
				$referral_code = $this->generateReferralCode();
				
				$data = $request->except('_token','is_agree','password');
				$data['created_at'] = $currentTime;
				$data['updated_at'] = $currentTime;
				$data['referral_code'] = $referral_code;
				$data['password'] = Hash::make($request->input('password'));
				
				$user = User::create($data);
				
				$user->sendEmailVerificationNotification();
				
				DB::commit();
				return response()->json(['status' => 'success', 'msg' => 'Please verify your email. A confirmation has been sent to your registered email address.']);
			}
			catch (\Throwable $e)
			{
				DB::rollBack();
				$message = $e->getMessage();
				return response()->json(['status' => 'error', 'msg' => $message]);
			} 
		}
		
		function generateReferralCode($length = 6) {
			$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
			$charactersLength = strlen($characters);
			$referralCode = '';
			// Generate the referral code
			for ($i = 0; $i < $length; $i++) {
				$referralCode .= $characters[rand(0, $charactersLength - 1)];
			}
			
			return $referralCode;
		}
		
		
		protected function validator(array $data)
		{
			return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
			]);
		}
		
		protected function create(array $data)
		{
			return User::create([
            'name' => $data['name'],
            'phone_number' => $data['phone_number'],
            'username' => $data['username'],
            'email' => $data['email'],
            'country_id' => $data['country_id'],
            'state_id' => $data['state_id'],
            'city_id' => $data['city_id'],
            'occupation' => $data['occupation'],
            'password' => Hash::make($data['password']),
			]);
		}
	}
