<?php
	namespace App\Http\Controllers\Auth;
	
	use App\Http\Controllers\Controller;
	use Illuminate\Foundation\Auth\RegistersUsers;
	use Illuminate\Foundation\Auth\AuthenticatesUsers;
	use Illuminate\Support\Facades\Hash;
	use Illuminate\Support\Facades\Mail;
	use Illuminate\Support\Facades\Validator;
	use Illuminate\Validation\Rule;
	use Illuminate\Http\Request;
	use Illuminate\Auth\Events\Registered;
	use App\Models\User;
	use App\Models\Otp;
	use DB, Helper, Auth;
	
	class LoginController extends Controller
	{
		/*
			|--------------------------------------------------------------------------
			| Login Controller
			|--------------------------------------------------------------------------
			|
			| This controller handles authenticating users for the application and
			| redirecting them to your home screen. The controller uses a trait
			| to conveniently provide its functionality to your applications.
			|
		*/
		
		use AuthenticatesUsers;
		
		/**
			* Where to redirect users after login.
			*
			* @var string
		*/
		protected $redirectTo = '/home';
		
		public function userLogin(Request $request)
		{
			if($request->mobile_number)
			{
				$validation = Validator::make($request->all(), [
				'mobile_number' => 'required|numeric',
				]);
			}
			else
			{
				$validation = Validator::make($request->all(), [
				'email' => 'required|string',
				'password' => 'required|string|min:6|max:20',
				]);
			}
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			if($request->mobile_number)
			{
				$mobile_no = $request->input('mobile_number');
				$random_otp = random_int(100000, 999999);
				
				Otp::where('mobile_no', $mobile_no)->delete();
				
				$get_user = User::where('phone_number',$mobile_no)->first();
				
				if(empty($get_user))
				{
					return response()->json(['status' => 'error', 'msg' => 'Mobile number not registered. Please check your mobile number.']);
				}
				
				if(is_null($get_user->email_verified_at)) 
				{
					$get_user->sendEmailVerificationNotification();
					
					return response()->json(['status' => 'email_validation','msg' => 'We just re-sent the verification link to your email address: '.$get_user->email.'']);
				}
				
				Otp::insert(['mobile_no' => $mobile_no,'otp' => $random_otp]);
				
				return response()->json(['status' => 'success', 'msg' => 'An OTP has been sent to your registered mobile number. Please check your mobile.', 'otp' => $random_otp], 200);
			}
			else
			{
				$filed_value = $request->input('email');
				
				$check_type = filter_var($filed_value, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
				
				$check_user = User::where($check_type, $filed_value)->first();
				
				if (!$check_user) 
				{
					return response()->json([
					'status' => 'error',
					'msg' => "The $check_type and password are incorrect. Please check your details and try again."
					]);
				}
				
				if(is_null($check_user->email_verified_at)) 
				{
					$check_user->sendEmailVerificationNotification();
					
					return response()->json(['status' => 'email_validation','msg' => 'We just re-sent the verification link to your email address: '.$check_user->email.'']);
				}
				
				if($check_user->is_status != 1) 
				{
					return response()->json(['status' => 'error','msg' => "Your account is deactivated. Please contact the admin."]);
				}
				
				$credentials = [
				$check_type => $filed_value,
				'password' => $request->input('password'),
				];
				
				if(Auth::attempt($credentials)) 
				{
					return response()->json(['status' => 'success', 'msg' => 'Login Successfully.']);
				} 
				else 
				{
					return response()->json(['status' => 'error','msg' => "The $check_type and password are incorrect. Please check your details and try again."]);
				}
			}
		}
		
		public function userOtpVerification(Request $request)
		{
			$validation = Validator::make($request->all(), [
				'otp' => 'required|numeric',
				'mobile_number' => 'required|numeric',
			]);
			
			if ($validation->fails()) 
			{
				return response()->json(['status' => 'validation', 'errors' => $validation->errors()]);
			}
			
			$get_otp = Otp::where('mobile_no', $request->mobile_number)->where('otp', $request->otp)->first();
			
			if(empty($get_otp))
			{
				return response()->json(['status' => 'error','msg' => "The OTP is invalid. Please try again."]);
			}
			
			$user = User::where('phone_number', $request->mobile_number)->first();
			
			Auth::login($user);
			
			$get_otp->delete();
			
			return response()->json(['status' => 'success', 'msg' => 'Login Successfully.']);
		}
		
		/**
			* Create a new controller instance.
			*
			* @return void
		*/
		public function __construct()
		{
			$this->middleware('guest')->except('logout');
			$this->middleware('auth')->only('logout');
		}
	}
