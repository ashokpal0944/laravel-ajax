<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserInvestmentBifurcation extends Model
{
    use HasFactory;
	
	protected $fillable = [
        'user_investment_id',
        'silver_bond_percentage',
        'silver_bond_amount',
        'real_estate_percentage',
        'real_estate_amount',
        'startup_investment_percentage',
        'startup_investment_amount',
        'stock_investment_percentage',
        'stock_investment_amount',
        'trading_investment_percentage',
        'trading_investment_amount',
        'reserve_fund_percentage',
        'reserve_fund_amount',
    ];
}
