<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail as MustVerifyEmailContract;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Support\Facades\Hash;
use App\Notifications\CustomVerificationNotification;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

class User extends Authenticatable implements JWTSubject, MustVerifyEmailContract
{
    use HasFactory, Notifiable;
	
	/* protected static $recordEvents = ['created', 'deleted', 'updated']; 
	
	public function getActivitylogOptions(string $logName = 'User'): LogOptions
	{  
		if (auth()->guard('admin')->check()) {
			$user_name = auth()->guard('admin')->user()->name;
			} elseif (auth()->check()) {
			$user_name = auth()->user()->name;
		}
		return LogOptions::defaults()
		->logOnly(['*'])
		->logOnlyDirty()
		->dontSubmitEmptyLogs()
		->useLogName($logName)
		->setDescriptionForEvent(function (string $eventName) use ($logName,$user_name) {
			return " has been {$eventName} by {$user_name}";
		});
	} */

    protected $fillable = [
        'name',
        'phone_number',
        'username',
        'email',
        'password',
        'country_id',
        'state_id',
        'city_id',
        'occupation',
        'referral_code',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
	
	public function sendEmailVerificationNotification()
    {
        $this->notify(new CustomVerificationNotification);
    }
	
	 public function getJWTIdentifier()
    {
        return $this->getKey();
    }
    public function getJWTCustomClaims()
    {
        return [];
    }
	
	public function country()
	{
		return $this->belongsTo(Country::class, 'country_id');
	}
	
	public function state()
	{
		return $this->belongsTo(State::class, 'state_id');
	}
	
	public function city()
	{
		return $this->belongsTo(City::class, 'city_id');
	}
}
