<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

class AiStrategy extends Model
{
     use HasFactory, LogsActivity; 
	
	protected static $recordEvents = ['created', 'deleted', 'updated']; 
	
	public function getActivitylogOptions(string $logName = 'Ai Strategy'): LogOptions
	{  
		$user_name = '';

        if (auth()->guard('admin')->check()) {
            $user_name = auth()->guard('admin')->user()->name;
        } elseif (auth()->check()) {
            $user_name = auth()->user()->name;
        }
		return LogOptions::defaults()
		->logOnly(['*'])
		->logOnlyDirty()
		->dontSubmitEmptyLogs()
		->useLogName($logName)
		->setDescriptionForEvent(function (string $eventName) use ($logName,$user_name) {
			return " has been {$eventName} by {$user_name}";
		});
	}
}
