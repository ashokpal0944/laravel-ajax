<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

class News extends Model
{
    use HasFactory, LogsActivity;  
	protected static $recordEvents = ['created', 'deleted', 'updated']; 
	public function getActivitylogOptions(string $logName = 'News'): LogOptions
	{  
		$user_name = auth()->guard('admin')->user()->name;
		return LogOptions::defaults()
		->logOnly(['*','admin.name'])
		->logOnlyDirty()
		->dontSubmitEmptyLogs()
		->useLogName($logName)
		->setDescriptionForEvent(function (string $eventName) use ($logName,$user_name) {
			return " has been {$eventName} by {$user_name}";
		});
	}
	
	public function admin()
	{
		return $this->belongsTo(Admin::class, 'admin_id');
	}
	
	public function newsCategory()
	{
		return $this->belongsTo(NewsCategory::class, 'news_category_id');
	}
}
