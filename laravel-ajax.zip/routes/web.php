<?php
	
	use Illuminate\Support\Facades\Route;
	use Illuminate\Auth\Notifications\VerifyEmail;
	
	/*
		|--------------------------------------------------------------------------
		| Web Routes
		|--------------------------------------------------------------------------
		|
		| Here is where you can register web routes for your application. These
		| routes are loaded by the RouteServiceProvider and all of them will
		| be assigned to the "web" middleware group. Make something great!
		|
	*/
	
	Route::get('/', function () {
		//\Artisan::call('storage:link');
		return redirect('login');
		//return view('welcome');
	});
	
	Route::group(['namespace' => 'App\Http\Controllers\Admin'], function () {
		Route::group(['prefix' => 'admin', 'as' => 'admin.'], function () 
		{
			Route::get('/login', 'LoginController@show')->name('login');
			Route::post('/login-post', 'LoginController@loginPost')->name('login-post');
			
			Route::group(['middleware'=>'admin'],function()
			{
				Route::get('logout', 'LoginController@logout')->name('logout');
				Route::get('dashboard','DashboardController@index')->name('dashboard');
				
				//Profile
				Route::get('profile','ProfileController@index')->name('profile');
				Route::post('update-profile','ProfileController@updateProfile');
				
				//Setting
				Route::get('setting','SettingController@index')->name('setting');
				Route::post('update-setting','SettingController@updateSettingData');
				Route::post('delete-first-banner','SettingController@deleteFirstBanner');
				Route::post('delete-second-banner','SettingController@deleteSecondBanner');
				 
				//user_error
				Route::group(['prefix' => 'user', 'as' => 'user.'], function () 
				{
					Route::get('list','UserController@index')->name('list');
					Route::post('get-user-data-ajax','UserController@getUserDataAjax');
					Route::get('view/{id}','UserController@viewUser');
					Route::post('edit/{id}','UserController@viewUpdateData');
					Route::get('email-verify/{id}','UserController@emailVerify');
					
					Route::group(['prefix' => 'kyc', 'as' => 'kyc.'], function () 
					{
						Route::get('list','UserController@userKYCList')->name('list');
						Route::post('get-user-kyc-data-ajax','UserController@getUserKycDataAjax');
						Route::get('edit/{id}','UserController@editUserKYC');
						Route::post('change-status','UserController@changeKycStatus');
					});
					
					Route::group(['prefix' => 'premium-subscription', 'as' => 'premium-subscription.'], function () 
					{
						Route::get('list','UserController@userPremiumSubscriptionList')->name('list');
						Route::post('get-user-premium-subscription-data-ajax','UserController@getUserPremiumSubscriptionDataAjax');
						Route::post('approve/{id}','UserController@approvePremiumSubscription');
						Route::get('reject/{id}','UserController@rejectPremiumSubscription');
						Route::post('reject/{id}','UserController@rejectPremiumSubscriptionData');
					});
					
					Route::group(['prefix' => 'deposit', 'as' => 'deposit.'], function () 
					{
						Route::get('list','UserController@userDepositList')->name('list');
						Route::post('get-user-deposit-data-ajax','UserController@getUserDepositDataAjax');
						Route::post('approve/{id}','UserController@approveDeposit');
						Route::get('reject/{id}','UserController@rejectDeposit');
						Route::post('reject/{id}','UserController@rejectDepositData');
					});
					
					Route::group(['prefix' => 'withdrawal', 'as' => 'withdrawal.'], function () 
					{
						Route::get('list','UserController@userWithdrawalList')->name('list');
						Route::post('get-user-withdrawal-data-ajax','UserController@getUserWithdrawalDataAjax');
						Route::post('approve/{id}','UserController@approveWithdrawal');
						Route::get('reject/{id}','UserController@rejectWithdrawal');
						Route::post('reject/{id}','UserController@rejectWithdrawalData');
					});
					
					Route::group(['prefix' => 'purchase', 'as' => 'purchase.'], function () 
					{
						Route::get('list','UserController@userPurchaseList')->name('list');
						Route::post('get-user-purchase-data-ajax','UserController@getUserPurchaseDataAjax');
					});
					
					Route::group(['prefix' => 'investment', 'as' => 'investment.'], function () 
					{
						Route::get('list','UserController@userInvestmentList')->name('list');
						Route::post('get-user-investment-data-ajax','UserController@getUserInvestmentDataAjax');
					});
				
					Route::group(['prefix' => 'return-on-investment', 'as' => 'return-on-investment.'], function () 
					{
						Route::get('list','UserController@userROIList')->name('list');
						Route::post('get-user-roi-data-ajax','UserController@getUserRoiDataAjax');
						Route::get('interest-pay','UserController@interestPay');
						Route::post('pay-interest-amount','UserController@payInterestAmount');
					});
				});
				
				//Videos
				Route::group(['prefix' => 'video', 'as' => 'video.'], function () 
				{
					Route::get('list','VideoTradeController@index')->name('list');
					Route::post('get-video-data-ajax','VideoTradeController@getVideoDataAjax');
					Route::get('add','VideoTradeController@add')->name('add');
					Route::post('add','VideoTradeController@insert');
					Route::get('edit/{id}','VideoTradeController@edit');
					Route::post('edit/{id}','VideoTradeController@update');
					Route::post('delete/{id}','VideoTradeController@delete');
				});
				
				//Past Traded
				Route::group(['prefix' => 'past-trade', 'as' => 'past-trade.'], function () 
				{
					Route::get('list','PastTradeController@index')->name('list');
					Route::post('get-past-trade-data-ajax','PastTradeController@getPastTradeDataAjax');
					Route::get('add','PastTradeController@add')->name('add');
					Route::post('add','PastTradeController@insert');
					Route::get('edit/{id}','PastTradeController@edit');
					Route::post('edit/{id}','PastTradeController@update');
					Route::post('delete/{id}','PastTradeController@delete');
				});
				
				//Live Trade
				Route::group(['prefix' => 'live-trade', 'as' => 'live-trade.'], function () 
				{
					Route::get('list','LiveTradeController@index')->name('list');
					Route::post('get-live-trade-data-ajax','LiveTradeController@getLiveTradeDataAjax');
					Route::get('add','LiveTradeController@add')->name('add');
					Route::post('add','LiveTradeController@insert');
					Route::get('edit/{id}','LiveTradeController@edit');
					Route::post('edit/{id}','LiveTradeController@update');
					Route::post('delete/{id}','LiveTradeController@delete');
				});
				
				//News
				Route::group(['prefix' => 'news', 'as' => 'news.'], function () 
				{
					Route::get('list','NewsController@index')->name('list');
					Route::post('get-news-data-ajax','NewsController@getNewsDataAjax');
					Route::get('add','NewsController@add')->name('add');
					Route::post('add','NewsController@insert');
					Route::get('edit/{id}','NewsController@edit');
					Route::post('edit/{id}','NewsController@update');
					Route::post('delete/{id}','NewsController@delete');
				});
				
				//Investment Plan
				Route::group(['prefix' => 'investment-plan', 'as' => 'investment-plan.'], function () 
				{
					Route::get('list','InvestmentPlanController@index')->name('list');
					Route::post('get-investment-plan-data-ajax','InvestmentPlanController@getInvestmentPlanDataAjax');
					Route::get('add','InvestmentPlanController@add')->name('add');
					Route::post('add','InvestmentPlanController@insert');
					Route::get('edit/{id}','InvestmentPlanController@edit');
					Route::post('edit/{id}','InvestmentPlanController@update');
					Route::post('delete/{id}','InvestmentPlanController@delete');
					
					Route::get('structure','InvestmentPlanController@structure')->name('structure');
					Route::post('investment-structure','InvestmentPlanController@investmentStructure')->name('investment-structure');
				});
				
				//Stock - Buzz
				Route::group(['prefix' => 'stock-buzz', 'as' => 'stock-buzz.'], function () 
				{
					Route::get('list','StockBuzzController@index')->name('list');
					Route::post('get-stock-buzz-ajax','StockBuzzController@getStockBuzzAjax');
					Route::get('add','StockBuzzController@add')->name('add');
					Route::post('add','StockBuzzController@insert');
					Route::get('edit/{id}','StockBuzzController@edit');
					Route::post('edit/{id}','StockBuzzController@update');
					Route::post('delete/{id}','StockBuzzController@delete');
				});
				
				Route::group(['prefix' => 'top-category', 'as' => 'top-category.'], function () 
				{
					Route::get('list','TopCategoryController@index')->name('list');
					Route::post('get-top-category-ajax','TopCategoryController@getTopCategoryAjax');
					Route::get('add','TopCategoryController@add')->name('add');
					Route::post('add','TopCategoryController@insert');
					Route::get('edit/{id}','TopCategoryController@edit');
					Route::post('edit/{id}','TopCategoryController@update');
					Route::post('delete/{id}','TopCategoryController@delete');
				});
				
				//Trading
				Route::group(['prefix' => 'trading', 'as' => 'trading.'], function () 
				{
					Route::get('list','TradingController@index')->name('list');
					Route::post('get-trading-ajax','TradingController@getTradingAjax');
					Route::get('add','TradingController@add')->name('add');
					Route::post('add','TradingController@insert');
					Route::get('edit/{id}','TradingController@edit');
					Route::post('edit/{id}','TradingController@update');
					Route::post('delete/{id}','TradingController@delete');
				});
				
				//Rehab
				Route::group(['prefix' => 'rehab', 'as' => 'rehab.'], function () 
				{
					Route::get('list','RehabController@index')->name('list');
					Route::post('get-rehab-ajax','RehabController@getRehabAjax');
					Route::get('add','RehabController@add')->name('add');
					Route::post('add','RehabController@insert');
					Route::get('edit/{id}','RehabController@edit');
					Route::post('edit/{id}','RehabController@update');
					Route::post('delete/{id}','RehabController@delete');
				});
				
				//Business
				Route::group(['prefix' => 'business', 'as' => 'business.'], function () 
				{
					Route::get('list','BusinessController@index')->name('list');
					Route::post('get-business-ajax','BusinessController@getBusinessAjax');
					Route::get('add','BusinessController@add')->name('add');
					Route::post('add','BusinessController@insert');
					Route::get('edit/{id}','BusinessController@edit');
					Route::post('edit/{id}','BusinessController@update');
					Route::post('delete/{id}','BusinessController@delete');
				});
				
				//Ai & Bots
				Route::group(['prefix' => 'ai-bots', 'as' => 'ai-bots.'], function () 
				{
					Route::get('list','AiBotsController@index')->name('list');
					Route::post('get-ai-bots-ajax','AiBotsController@getAiBotsAjax');
					Route::get('add','AiBotsController@add')->name('add');
					Route::post('add','AiBotsController@insert');
					Route::get('edit/{id}','AiBotsController@edit');
					Route::post('edit/{id}','AiBotsController@update');
					Route::post('delete/{id}','AiBotsController@delete');
					
					//purchase
					Route::get('purchase/list','AiBotsController@aiBotPurchaseList')->name('ai-bot-purchase.list');
					Route::post('get-ai-bots-purchase-data-ajax','AiBotsController@getAiBotsPurchaseDataAjax');
					
					//strategy
					Route::get('strategy/{id}','AiBotsController@strategyListing');
					Route::post('get-ai-bots-strategy-ajax','AiBotsController@getAiBotsStrategyAjax');
					Route::get('add-strategy','AiBotsController@addStrategy');
					Route::post('add-strategy','AiBotsController@addStrategyInsert');
					Route::get('edit-strategy/{id}','AiBotsController@editStrategy');
					Route::post('edit-strategy/{id}','AiBotsController@updateStrategy');
					Route::post('delete-strategy/{id}','AiBotsController@deleteStrategy');
				});
			});
		});	
	});
	
	Auth::routes(['verify' => true]);
	
	Route::group(['namespace' => 'App\Http\Controllers\Auth'], function () 
	{
		Route::post('user-register', 'RegisterController@userRegister')->name('user-register');	
		Route::post('user-login', 'LoginController@userLogin')->name('user-login');	
		Route::post('user-otp-verification', 'LoginController@userOtpVerification')->name('user-otp-verification');	
		
	});
	
	Route::group(['namespace' => 'App\Http\Controllers\User'], function () 
	{
		Route::get('/home', 'HomeController@index')->name('home');
		Route::get('/view-portfolio-buzz', 'HomeController@viewPortfolioBuzz')->name('view-portfolio-buzz');
		Route::get('/view-health', 'HomeController@viewHealth')->name('view-health');
		Route::get('/view-basket', 'HomeController@viewBasket')->name('view-basket');
		
		//Profile
		Route::get('/profile', 'ProfileController@index')->name('index');
		Route::get('/personal-data', 'ProfileController@profileData')->name('personal-data');
		Route::post('/update-profile', 'ProfileController@updateProfile')->name('update-profile');
		
		Route::get('/kyc', 'ProfileController@userKYC')->name('kyc');
		Route::post('/update-profile-image', 'ProfileController@updateProfileImage')->name('update-profile-image');
		Route::post('/update-user-kyc', 'ProfileController@updateUserKyc')->name('update-user-kyc');
		Route::post('/update-bank-account-details', 'ProfileController@updateBankAccountDetails')->name('update-bank-account-details');
		
		Route::get('/referral-code', 'ProfileController@referralCode')->name('referral-code');
		
		Route::get('/change-password', 'ProfileController@changePassword')->name('change-password');
		Route::post('/update-password', 'ProfileController@updatePassword');
		
		//Investment
		Route::get('/investment-list', 'InvestmentController@index')->name('investment-list');
		Route::get('/get-return-of-interest/{id}', 'InvestmentController@getReturnOfInterest')->name('get-return-of-interest');
		
		//Wallet
		Route::get('/wallet-list', 'WalletController@index')->name('wallet-list');
		Route::get('/wallet-balance', 'WalletController@walletBalance')->name('wallet-balance');
		
		Route::get('/premium-subscription', 'WalletController@premiumSubscription')->name('premium-subscription');
		Route::post('/premium-subscription', 'WalletController@premiumSubscriptionAmountDetails')->name('premium-subscription');
		Route::post('/send-premium-subscription', 'WalletController@sendPremiumSubScription');
		
		//Deposit
		Route::get('/deposit-history', 'WalletController@depositHistory')->name('deposit-history');
		Route::post('/get-deposit-history-data-ajax', 'WalletController@getDepositHistoryDataAjax');
		Route::get('/view-deposit/{id}', 'WalletController@viewDeposit')->name('view-deposit');
		Route::get('/deposit', 'WalletController@depositMethod')->name('deposit');
		Route::match(['get', 'post'], '/send-deposit-method', 'WalletController@sendDepositMethod');
		Route::post('/send-deposit-request', 'WalletController@sendDepositRequest');
		
		//Withdrawal
		Route::get('/withdrawal-history', 'WalletController@withdrawalHistory')->name('withdrawal-history');
		Route::post('/get-withdrawal-history-data-ajax', 'WalletController@getWithdrawalHistoryDataAjax');
		Route::get('/edit-withdrawal/{id}', 'WalletController@editWithdrawal')->name('edit-withdrawal');
		Route::post('/update-withdrawal/{id}', 'WalletController@updateWithdrawal');
		Route::post('/delete-withdrawal/{id}', 'WalletController@deleteWithdrawal');
		Route::get('/withdrawal', 'WalletController@withdrawal')->name('withdrawal');
		Route::match(['get', 'post'], '/send-withdrawal-method', 'WalletController@sendWithdrawalMethod');
		Route::post('/send-withdrawal-request', 'WalletController@sendWithdrawalRequest');
		
		//Top Plan
		Route::get('/top-plan', 'WalletController@topPlan')->name('top-plan');
		Route::get('/investment-price', 'WalletController@investmentPrice')->name('investment-price');
		Route::post('/pay-investment-amount', 'WalletController@payInvestmentAmount');
		Route::get('/investment-history', 'WalletController@investmentHistory')->name('investment-history');
		Route::post('/get-investment-history-data-ajax', 'WalletController@getInvestmentHistoryDataAjax');
		
		//Education
		Route::get('/educations', 'EducationController@educationsList')->name('educations');
		Route::get('/education/trading', 'EducationController@educationsTrading')->name('education.trading');
		Route::get('/education/trading/course/{id}', 'EducationController@educationsTradingCourseView')->name('education.trading');
		
		Route::get('/education/rehab', 'EducationController@educationRehab')->name('education.rehab');
		Route::get('/education/rehab/course/{id}', 'EducationController@educationRehabCourseView');
		
		Route::get('/education/business', 'EducationController@educationsBusiness')->name('education.business');
		Route::get('/education/business/course/{id}', 'EducationController@educationsBusinessCourseView')->name('education.business');
		
		//Purchase History
		Route::get('/purchase-history', 'EducationController@purchaseHistory')->name('purchase-history');
		Route::post('/get-purchase-history-data-ajax', 'EducationController@getPurchaseHistoryDataAjax');
		Route::post('/purchase-education-course', 'EducationController@purchaseEducationCourse')->name('purchase-education-course');
		
		//Ai Bots
		Route::get('/ai-bots', 'AiBotsController@aiBotsList')->name('ai-bots');
		Route::get('/view-ai-boat/{currency_type}', 'AiBotsController@viewAiBoat')->name('view-ai-boat');
		Route::get('/view-strategy/{id}', 'AiBotsController@viewStrategy')->name('view-strategy');
		Route::post('/purchase-ai-bot', 'AiBotsController@purchaseAiBot')->name('purchase-ai-bot');
		
		Route::get('/ai-bot-purchase-history', 'AiBotsController@aiBotPurchaseHistory')->name('ai-bot-purchase-history');
		Route::post('/get-ai-bot-purchase-history-data-ajax', 'AiBotsController@getAiBoatPurchaseHistoryDataAjax');
	});
	
	Route::group(['namespace' => 'App\Http\Controllers'], function () 
	{
		Route::post('get-state-data', 'CommonController@getStateData')->name('get-state-data');	
		Route::post('get-city-data', 'CommonController@getCityData')->name('get-city-data');	
		
		Route::get('email/verify/{id}/{hash}', 'VerificationController@verify')->name('verification.verify');	
		Route::post('email/resend', 'VerificationController@resend')->name('verification.resend');	
	});
	
