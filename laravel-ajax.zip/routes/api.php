<?php
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Route;
	use App\Http\Controllers\Api\AuthenticationController;
	use App\Http\Controllers\Api\CommonController;
	use App\Http\Controllers\Api\HomeController;
	use App\Http\Controllers\Api\WalletController;
	use App\Http\Controllers\Api\EducationController;
	use App\Http\Controllers\Api\InvestmentController;
	/*
		|--------------------------------------------------------------------------
		| API Routes
		|--------------------------------------------------------------------------
		|
		| Here is where you can register API routes for your application. These
		| routes are loaded by the RouteServiceProvider and all of them will
		| be assigned to the "api" middleware group. Make something great!
		|
	*/
	
	Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
		return $request->user();
	});
	
	//Authentication
	Route::post('register', [AuthenticationController::class,'registerPost']);
	Route::post('login', [AuthenticationController::class,'loginPost']);
	Route::post('send-otp', [AuthenticationController::class,'sendOTP']);
	Route::post('verify-otp', [AuthenticationController::class,'verifyOTP']);
	Route::post('forgot-password', [AuthenticationController::class,'forgotPassword']);
	Route::post('check-user-name', [AuthenticationController::class,'checkUserName']);
	
	//Country, State & City
	Route::get('get-country', [CommonController::class, 'getCountry']);
	Route::post('get-state', [CommonController::class, 'getState']);
	Route::post('get-city', [CommonController::class, 'getCity']);
	
	Route::group(['middleware' => ['jwt.verify']], function() 
	{
		//Dashboard
		Route::get('get-dashboard-data', [HomeController::class, 'getDashboardData']);
		
		//Profile
		Route::get('get-profile', [HomeController::class, 'getProfile']);
		Route::post('update-profile', [HomeController::class, 'updateProfile']);
		Route::post('change-password', [HomeController::class, 'changePassword']);
		
		//Common API
		Route::get('get-wallet-details', [HomeController::class, 'getWalletDetails']);
		
		//User KYC
		Route::get('get-user-kyc', [HomeController::class, 'getUserKyc']);
		Route::post('user-kyc', [HomeController::class, 'userKYC']);
		
		//Deposite
		Route::get('get-deposit-history', [WalletController::class, 'getDepositHistory']);
		Route::post('deposit-amount', [WalletController::class, 'depositAmount']);
		
		//Withdrawal 
		Route::get('get-withdrawal-history', [WalletController::class, 'getWithdrawalHistory']);
		Route::post('withdrawal-amount-request', [WalletController::class, 'withdrawalAmountRequest']);
		Route::post('update-withdrawal-request/{id}', [WalletController::class, 'updateWithdrawalRequest']);
		Route::get('delete-withdrawal-request/{id}', [WalletController::class, 'deleteWithdrawalRequest']);
		
		//Education
		Route::get('get-education', [EducationController::class, 'getEducation']);
		Route::get('get-education-history', [EducationController::class, 'getEducationHistory']);
		Route::post('purchase-education-plan', [EducationController::class, 'purchaseEducationPlan']);
		
		//Investment APIS
		Route::get('get-investment-plans', [InvestmentController::class, 'getInvestmentPlans']);
		Route::get('get-investment-plans-history', [InvestmentController::class, 'getInvestmentPlansHistory']);
		Route::get('get-investment-return-of-interest', [InvestmentController::class, 'getInvestmentReturnOfInterest']);
		Route::post('pay-investment-amount', [InvestmentController::class, 'payInvestmentAmount']);
		
		//aibot
		Route::post('purchase-ai-bot', [WalletController::class, 'purchaseAiBot']);
		Route::get('get-ai-bot-purchase-history', [WalletController::class, 'getAiBotPurchaseHistory']);
	});